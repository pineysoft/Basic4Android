package pineysoft.squarepaddocks.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_startscreen{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("pnlstartscreen").vw.setTop((int)((0d * scale)));
views.get("pnlstartscreen").vw.setLeft((int)((0d * scale)));
views.get("pnlstartscreen").vw.setWidth((int)((100d / 100 * width)));
views.get("pnlstartscreen").vw.setHeight((int)((100d / 100 * height)));
views.get("titleimage").vw.setLeft((int)((75d * scale)));
views.get("titleimage").vw.setWidth((int)((100d / 100 * width)-(75d * scale) - ((75d * scale))));
views.get("titleimage").vw.setTop((int)((10d * scale)));
views.get("pnlshading").vw.setLeft((int)((5d / 100 * width)));
views.get("pnlshading").vw.setWidth((int)((95d / 100 * width) - ((5d / 100 * width))));
views.get("pnlselectionleft").vw.setTop((int)((0d * scale)));
views.get("pnlselectionleft").vw.setLeft((int)((0d * scale)));
views.get("pnlselectionleft").vw.setWidth((int)((50d / 100 * width)));
views.get("pnlselectionleft").vw.setHeight((int)((100d / 100 * height)));
views.get("pnlselectionright").vw.setTop((int)((0d * scale)));
views.get("pnlselectionright").vw.setLeft((int)((100d / 100 * width) - (views.get("pnlselectionright").vw.getWidth())));
views.get("pnlselectionright").vw.setWidth((int)((50d / 100 * width)));
views.get("pnlselectionright").vw.setHeight((int)((100d / 100 * height)));
views.get("lblplayers").vw.setTop((int)((views.get("titleimage").vw.getTop() + views.get("titleimage").vw.getHeight())+(10d * scale)));
views.get("lblplayers").vw.setWidth((int)((120d * scale)));
views.get("lblplayers").vw.setLeft((int)((views.get("pnlselectionleft").vw.getWidth()) - (views.get("lblplayers").vw.getWidth())));
views.get("lbldroids").vw.setTop((int)((views.get("lblplayers").vw.getTop() + views.get("lblplayers").vw.getHeight())+(15d * scale)));
views.get("lbldroids").vw.setWidth((int)((120d * scale)));
views.get("lbldroids").vw.setLeft((int)((views.get("pnlselectionleft").vw.getWidth()) - (views.get("lbldroids").vw.getWidth())));
views.get("lblrows").vw.setWidth((int)((120d * scale)));
views.get("lblrows").vw.setTop((int)((views.get("lbldroids").vw.getTop() + views.get("lbldroids").vw.getHeight())+(15d * scale)));
views.get("lblrows").vw.setLeft((int)((views.get("pnlselectionleft").vw.getWidth()) - (views.get("lblrows").vw.getWidth())));
views.get("lblcolumns").vw.setWidth((int)((120d * scale)));
views.get("lblcolumns").vw.setTop((int)((views.get("lblrows").vw.getTop() + views.get("lblrows").vw.getHeight())+(20d * scale)));
views.get("lblcolumns").vw.setLeft((int)((views.get("pnlselectionleft").vw.getWidth()) - (views.get("lblcolumns").vw.getWidth())));
views.get("lblsound").vw.setWidth((int)((120d * scale)));
//BA.debugLineNum = 35;BA.debugLine="lblSound.Top = lblColumns.Bottom + 15dip"[startscreen/General script]
views.get("lblsound").vw.setTop((int)((views.get("lblcolumns").vw.getTop() + views.get("lblcolumns").vw.getHeight())+(15d * scale)));
//BA.debugLineNum = 36;BA.debugLine="lblSound.Right = pnlSelectionLeft.Width"[startscreen/General script]
views.get("lblsound").vw.setLeft((int)((views.get("pnlselectionleft").vw.getWidth()) - (views.get("lblsound").vw.getWidth())));
//BA.debugLineNum = 37;BA.debugLine="lblDifficulty.Width = 120dip"[startscreen/General script]
views.get("lbldifficulty").vw.setWidth((int)((120d * scale)));
//BA.debugLineNum = 38;BA.debugLine="lblDifficulty.Top = lblSound.Bottom + 15dip"[startscreen/General script]
views.get("lbldifficulty").vw.setTop((int)((views.get("lblsound").vw.getTop() + views.get("lblsound").vw.getHeight())+(15d * scale)));
//BA.debugLineNum = 39;BA.debugLine="lblDifficulty.Right = pnlSelectionLeft.Width"[startscreen/General script]
views.get("lbldifficulty").vw.setLeft((int)((views.get("pnlselectionleft").vw.getWidth()) - (views.get("lbldifficulty").vw.getWidth())));
//BA.debugLineNum = 40;BA.debugLine="spnPlayers.Left = 0dip"[startscreen/General script]
views.get("spnplayers").vw.setLeft((int)((0d * scale)));
//BA.debugLineNum = 41;BA.debugLine="spnPlayers.Top = lblPlayers.Top"[startscreen/General script]
views.get("spnplayers").vw.setTop((int)((views.get("lblplayers").vw.getTop())));
//BA.debugLineNum = 42;BA.debugLine="spnPlayers.Width = lblPlayers.Width"[startscreen/General script]
views.get("spnplayers").vw.setWidth((int)((views.get("lblplayers").vw.getWidth())));
//BA.debugLineNum = 43;BA.debugLine="spnDroids.Top = lblDroids.Top"[startscreen/General script]
views.get("spndroids").vw.setTop((int)((views.get("lbldroids").vw.getTop())));
//BA.debugLineNum = 44;BA.debugLine="spnDroids.Left = 0dip"[startscreen/General script]
views.get("spndroids").vw.setLeft((int)((0d * scale)));
//BA.debugLineNum = 45;BA.debugLine="spnDroids.Width = lblRows.Width"[startscreen/General script]
views.get("spndroids").vw.setWidth((int)((views.get("lblrows").vw.getWidth())));
//BA.debugLineNum = 46;BA.debugLine="sbRows.Top = lblRows.Top"[startscreen/General script]
views.get("sbrows").vw.setTop((int)((views.get("lblrows").vw.getTop())));
//BA.debugLineNum = 47;BA.debugLine="sbRows.Left = 0dip"[startscreen/General script]
views.get("sbrows").vw.setLeft((int)((0d * scale)));
//BA.debugLineNum = 48;BA.debugLine="sbRows.Width = lblRows.Width"[startscreen/General script]
views.get("sbrows").vw.setWidth((int)((views.get("lblrows").vw.getWidth())));
//BA.debugLineNum = 49;BA.debugLine="sbColumns.Top = lblColumns.Top"[startscreen/General script]
views.get("sbcolumns").vw.setTop((int)((views.get("lblcolumns").vw.getTop())));
//BA.debugLineNum = 50;BA.debugLine="sbColumns.Left = 0dip"[startscreen/General script]
views.get("sbcolumns").vw.setLeft((int)((0d * scale)));
//BA.debugLineNum = 51;BA.debugLine="sbColumns.Width = lblColumns.Width"[startscreen/General script]
views.get("sbcolumns").vw.setWidth((int)((views.get("lblcolumns").vw.getWidth())));
//BA.debugLineNum = 52;BA.debugLine="chkSounds.Top = lblSound.Top"[startscreen/General script]
views.get("chksounds").vw.setTop((int)((views.get("lblsound").vw.getTop())));
//BA.debugLineNum = 53;BA.debugLine="chkSounds.Left = 0dip"[startscreen/General script]
views.get("chksounds").vw.setLeft((int)((0d * scale)));
//BA.debugLineNum = 54;BA.debugLine="chkSounds.Height = lblColumns.Height"[startscreen/General script]
views.get("chksounds").vw.setHeight((int)((views.get("lblcolumns").vw.getHeight())));
//BA.debugLineNum = 55;BA.debugLine="chkSounds.Width = lblSound.Width"[startscreen/General script]
views.get("chksounds").vw.setWidth((int)((views.get("lblsound").vw.getWidth())));
//BA.debugLineNum = 56;BA.debugLine="spnDifficulty.Top = lblDifficulty.Top"[startscreen/General script]
views.get("spndifficulty").vw.setTop((int)((views.get("lbldifficulty").vw.getTop())));
//BA.debugLineNum = 57;BA.debugLine="spnDifficulty.Height = lblDifficulty.Height"[startscreen/General script]
views.get("spndifficulty").vw.setHeight((int)((views.get("lbldifficulty").vw.getHeight())));
//BA.debugLineNum = 58;BA.debugLine="spnDifficulty.Width = lblDifficulty.Width"[startscreen/General script]
views.get("spndifficulty").vw.setWidth((int)((views.get("lbldifficulty").vw.getWidth())));
//BA.debugLineNum = 60;BA.debugLine="pnlShading.SetTopAndBottom(titleImage.Bottom + 10dip, lblDifficulty.Bottom + 5dip)"[startscreen/General script]
views.get("pnlshading").vw.setTop((int)((views.get("titleimage").vw.getTop() + views.get("titleimage").vw.getHeight())+(10d * scale)));
views.get("pnlshading").vw.setHeight((int)((views.get("lbldifficulty").vw.getTop() + views.get("lbldifficulty").vw.getHeight())+(5d * scale) - ((views.get("titleimage").vw.getTop() + views.get("titleimage").vw.getHeight())+(10d * scale))));
//BA.debugLineNum = 62;BA.debugLine="If 100%y - (pnlShading.Bottom + 10dip) > 80dip Then"[startscreen/General script]
if (((100d / 100 * height)-((views.get("pnlshading").vw.getTop() + views.get("pnlshading").vw.getHeight())+(10d * scale))>(80d * scale))) { 
;
//BA.debugLineNum = 63;BA.debugLine="btnContinue.Height = 80dip"[startscreen/General script]
views.get("btncontinue").vw.setHeight((int)((80d * scale)));
//BA.debugLineNum = 64;BA.debugLine="Else"[startscreen/General script]
;}else{ 
;
//BA.debugLineNum = 65;BA.debugLine="btnContinue.Height = 100%y - (pnlShading.Bottom + 10dip)"[startscreen/General script]
views.get("btncontinue").vw.setHeight((int)((100d / 100 * height)-((views.get("pnlshading").vw.getTop() + views.get("pnlshading").vw.getHeight())+(10d * scale))));
//BA.debugLineNum = 66;BA.debugLine="End If"[startscreen/General script]
;};
//BA.debugLineNum = 67;BA.debugLine="btnContinue.Width = 50%x"[startscreen/General script]
views.get("btncontinue").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 68;BA.debugLine="btnContinue.HorizontalCenter = 50%x"[startscreen/General script]
views.get("btncontinue").vw.setLeft((int)((50d / 100 * width) - (views.get("btncontinue").vw.getWidth() / 2)));
//BA.debugLineNum = 69;BA.debugLine="btnContinue.Bottom = 100%y"[startscreen/General script]
views.get("btncontinue").vw.setTop((int)((100d / 100 * height) - (views.get("btncontinue").vw.getHeight())));
//BA.debugLineNum = 71;BA.debugLine="icon1.Left = -100dip"[startscreen/General script]
views.get("icon1").vw.setLeft((int)(0-(100d * scale)));
//BA.debugLineNum = 72;BA.debugLine="icon2.Left = -100dip"[startscreen/General script]
views.get("icon2").vw.setLeft((int)(0-(100d * scale)));
//BA.debugLineNum = 73;BA.debugLine="icon3.Left = -100dip"[startscreen/General script]
views.get("icon3").vw.setLeft((int)(0-(100d * scale)));
//BA.debugLineNum = 74;BA.debugLine="icon4.Left = -100dip"[startscreen/General script]
views.get("icon4").vw.setLeft((int)(0-(100d * scale)));
//BA.debugLineNum = 75;BA.debugLine="icon5.Left = -120dip"[startscreen/General script]
views.get("icon5").vw.setLeft((int)(0-(120d * scale)));
//BA.debugLineNum = 76;BA.debugLine="icon6.Left = -120dip"[startscreen/General script]
views.get("icon6").vw.setLeft((int)(0-(120d * scale)));

}
}