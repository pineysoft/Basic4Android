package pineysoft.squarepaddocks;

import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (isFirst) {
			processBA = new anywheresoftware.b4a.ShellBA(this.getApplicationContext(), null, null, "pineysoft.squarepaddocks", "pineysoft.squarepaddocks.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		mostCurrent = this;
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
		BA.handler.postDelayed(new WaitForLayout(), 5);

	}
	private static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "pineysoft.squarepaddocks", "pineysoft.squarepaddocks.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "pineysoft.squarepaddocks.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
		return true;
	}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEvent(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
		this.setIntent(intent);
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null) //workaround for emulator bug (Issue 2423)
            return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
			if (mostCurrent == null || mostCurrent != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
		    processBA.raiseEvent(mostCurrent._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}



public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}
public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}

public static void killProgram() {
     {
            Activity __a = null;
            if (main.previousOne != null) {
				__a = main.previousOne.get();
			}
            else {
                BA ba = main.mostCurrent.processBA.sharedProcessBA.activityBA.get();
                if (ba != null) __a = ba.activity;
            }
            if (__a != null)
				__a.finish();}

}
public anywheresoftware.b4a.keywords.Common __c = null;
public static short _currentplayer = (short)0;
public static int _numberofplayers = 0;
public static int _numberofdroids = 0;
public static anywheresoftware.b4a.objects.collections.List _playercolours = null;
public static boolean _ingame = false;
public static int _gigglesound = 0;
public static anywheresoftware.b4a.audio.SoundPoolWrapper _sounds = null;
public static int _totalscore = 0;
public static pineysoft.squarepaddocks.constants _spconstants = null;
public pineysoft.squarepaddocks.gamesquare[][] _gamesquares = null;
public anywheresoftware.b4a.objects.collections.List _gameturns = null;
public static int _gamewidth = 0;
public static int _gameheight = 0;
public static int _columnspacing = 0;
public static int _rowspacing = 0;
public anywheresoftware.b4a.objects.PanelWrapper _panel1 = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _canv = null;
public anywheresoftware.b4a.objects.collections.List _players = null;
public anywheresoftware.b4a.objects.collections.List _playerimages = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer1image = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer2 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer2image = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer3 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer3image = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer4 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer4image = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncontinue = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spnplayers = null;
public anywheresoftware.b4a.objects.SeekBarWrapper _sbcolumns = null;
public anywheresoftware.b4a.objects.SeekBarWrapper _sbrows = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlstartscreen = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon1 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon2 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon3 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon4 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcolumns = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayers = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblrows = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbase = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncurrplayer = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon5 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon6 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnldisplay = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlouter = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _imageicon = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblwinner = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chksounds = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim1 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim2 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim3 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim4 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim5 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim6 = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spndroids = null;
public static String  _activity_create(boolean _firsttime) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
RDebugUtils.currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="SPConstants.Initialize";
_spconstants._initialize(null,processBA);
RDebugUtils.currentLine=131075;
 //BA.debugLineNum = 131075;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
RDebugUtils.currentLine=131076;
 //BA.debugLineNum = 131076;BA.debugLine="Activity.LoadLayout(\"StartScreen\")";
mostCurrent._activity.LoadLayout("StartScreen",mostCurrent.activityBA);
RDebugUtils.currentLine=131077;
 //BA.debugLineNum = 131077;BA.debugLine="ShowSplashScreen";
_showsplashscreen();
RDebugUtils.currentLine=131078;
 //BA.debugLineNum = 131078;BA.debugLine="CreateColours";
_createcolours();
RDebugUtils.currentLine=131079;
 //BA.debugLineNum = 131079;BA.debugLine="LoadImages";
_loadimages();
RDebugUtils.currentLine=131080;
 //BA.debugLineNum = 131080;BA.debugLine="LoadPlayerSpinner";
_loadplayerspinner();
RDebugUtils.currentLine=131081;
 //BA.debugLineNum = 131081;BA.debugLine="InitialiseSounds";
_initialisesounds();
 }else {
RDebugUtils.currentLine=131083;
 //BA.debugLineNum = 131083;BA.debugLine="Activity.LoadLayout(\"StartScreen\")";
mostCurrent._activity.LoadLayout("StartScreen",mostCurrent.activityBA);
RDebugUtils.currentLine=131084;
 //BA.debugLineNum = 131084;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
RDebugUtils.currentLine=131085;
 //BA.debugLineNum = 131085;BA.debugLine="ShowCharacters";
_showcharacters();
RDebugUtils.currentLine=131086;
 //BA.debugLineNum = 131086;BA.debugLine="CreateColours";
_createcolours();
RDebugUtils.currentLine=131087;
 //BA.debugLineNum = 131087;BA.debugLine="LoadImages";
_loadimages();
RDebugUtils.currentLine=131088;
 //BA.debugLineNum = 131088;BA.debugLine="LoadPlayerSpinner";
_loadplayerspinner();
RDebugUtils.currentLine=131089;
 //BA.debugLineNum = 131089;BA.debugLine="UpdateLabels";
_updatelabels();
 };
RDebugUtils.currentLine=131092;
 //BA.debugLineNum = 131092;BA.debugLine="End Sub";
return "";
}
public static String  _showsplashscreen() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Sub ShowSplashScreen";
RDebugUtils.currentLine=196609;
 //BA.debugLineNum = 196609;BA.debugLine="UpdateLabels";
_updatelabels();
RDebugUtils.currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="AnimateCharacters";
_animatecharacters();
RDebugUtils.currentLine=196611;
 //BA.debugLineNum = 196611;BA.debugLine="End Sub";
return "";
}
public static String  _createcolours() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=524288;
 //BA.debugLineNum = 524288;BA.debugLine="Sub CreateColours()";
RDebugUtils.currentLine=524289;
 //BA.debugLineNum = 524289;BA.debugLine="playerColours.Initialize";
_playercolours.Initialize();
RDebugUtils.currentLine=524290;
 //BA.debugLineNum = 524290;BA.debugLine="playerColours.Add(Colors.Yellow)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Yellow));
RDebugUtils.currentLine=524291;
 //BA.debugLineNum = 524291;BA.debugLine="playerColours.Add(Colors.Blue)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Blue));
RDebugUtils.currentLine=524292;
 //BA.debugLineNum = 524292;BA.debugLine="playerColours.Add(Colors.Green)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Green));
RDebugUtils.currentLine=524293;
 //BA.debugLineNum = 524293;BA.debugLine="playerColours.Add(Colors.Red)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Red));
RDebugUtils.currentLine=524294;
 //BA.debugLineNum = 524294;BA.debugLine="End Sub";
return "";
}
public static String  _loadimages() throws Exception{
RDebugUtils.currentModule="main";
boolean _moreimages = false;
int _imageloop = 0;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bm = null;
RDebugUtils.currentLine=589824;
 //BA.debugLineNum = 589824;BA.debugLine="Sub LoadImages";
RDebugUtils.currentLine=589825;
 //BA.debugLineNum = 589825;BA.debugLine="Dim moreImages As Boolean = True";
_moreimages = anywheresoftware.b4a.keywords.Common.True;
RDebugUtils.currentLine=589826;
 //BA.debugLineNum = 589826;BA.debugLine="Dim imageLoop As Int = 1";
_imageloop = (int) (1);
RDebugUtils.currentLine=589828;
 //BA.debugLineNum = 589828;BA.debugLine="playerImages.Initialize";
mostCurrent._playerimages.Initialize();
RDebugUtils.currentLine=589830;
 //BA.debugLineNum = 589830;BA.debugLine="Do While moreImages = True";
while (_moreimages==anywheresoftware.b4a.keywords.Common.True) {
RDebugUtils.currentLine=589831;
 //BA.debugLineNum = 589831;BA.debugLine="If File.Exists(File.DirAssets,\"cuteImage\" & imageLoop & \".png\") Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"cuteImage"+BA.NumberToString(_imageloop)+".png")) { 
RDebugUtils.currentLine=589832;
 //BA.debugLineNum = 589832;BA.debugLine="Dim bm As Bitmap";
_bm = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
RDebugUtils.currentLine=589833;
 //BA.debugLineNum = 589833;BA.debugLine="bm.Initialize(File.DirAssets, \"cuteImage\" & imageLoop & \".png\")";
_bm.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"cuteImage"+BA.NumberToString(_imageloop)+".png");
RDebugUtils.currentLine=589834;
 //BA.debugLineNum = 589834;BA.debugLine="playerImages.Add(bm)";
mostCurrent._playerimages.Add((Object)(_bm.getObject()));
RDebugUtils.currentLine=589835;
 //BA.debugLineNum = 589835;BA.debugLine="imageLoop = imageLoop + 1";
_imageloop = (int) (_imageloop+1);
 }else {
RDebugUtils.currentLine=589837;
 //BA.debugLineNum = 589837;BA.debugLine="moreImages = False";
_moreimages = anywheresoftware.b4a.keywords.Common.False;
 };
 }
;
RDebugUtils.currentLine=589840;
 //BA.debugLineNum = 589840;BA.debugLine="End Sub";
return "";
}
public static String  _loadplayerspinner() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=655360;
 //BA.debugLineNum = 655360;BA.debugLine="Sub LoadPlayerSpinner";
RDebugUtils.currentLine=655362;
 //BA.debugLineNum = 655362;BA.debugLine="spnPlayers.AddAll(Array As Int(2,3,4))";
mostCurrent._spnplayers.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new int[]{(int) (2),(int) (3),(int) (4)}));
RDebugUtils.currentLine=655363;
 //BA.debugLineNum = 655363;BA.debugLine="spnDroids.AddAll(Array As Int(0,1,2,3))";
mostCurrent._spndroids.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new int[]{(int) (0),(int) (1),(int) (2),(int) (3)}));
RDebugUtils.currentLine=655365;
 //BA.debugLineNum = 655365;BA.debugLine="End Sub";
return "";
}
public static String  _initialisesounds() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=786432;
 //BA.debugLineNum = 786432;BA.debugLine="Sub InitialiseSounds";
RDebugUtils.currentLine=786433;
 //BA.debugLineNum = 786433;BA.debugLine="sounds.Initialize(10)";
_sounds.Initialize((int) (10));
RDebugUtils.currentLine=786434;
 //BA.debugLineNum = 786434;BA.debugLine="giggleSound = sounds.Load(File.DirAssets, \"Giggle1.mp3\")";
_gigglesound = _sounds.Load(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Giggle1.mp3");
RDebugUtils.currentLine=786435;
 //BA.debugLineNum = 786435;BA.debugLine="End Sub";
return "";
}
public static String  _displayfrontscreen() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=2359296;
 //BA.debugLineNum = 2359296;BA.debugLine="Sub DisplayFrontScreen";
RDebugUtils.currentLine=2359297;
 //BA.debugLineNum = 2359297;BA.debugLine="If pnlBase.IsInitialized Then";
if (mostCurrent._pnlbase.IsInitialized()) { 
RDebugUtils.currentLine=2359298;
 //BA.debugLineNum = 2359298;BA.debugLine="pnlBase.Left = 200%x";
mostCurrent._pnlbase.setLeft(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (200),mostCurrent.activityBA));
 };
RDebugUtils.currentLine=2359300;
 //BA.debugLineNum = 2359300;BA.debugLine="pnlStartScreen.Left = 0dip";
mostCurrent._pnlstartscreen.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
RDebugUtils.currentLine=2359301;
 //BA.debugLineNum = 2359301;BA.debugLine="inGame = False";
_ingame = anywheresoftware.b4a.keywords.Common.False;
RDebugUtils.currentLine=2359302;
 //BA.debugLineNum = 2359302;BA.debugLine="ShowCharacters";
_showcharacters();
RDebugUtils.currentLine=2359303;
 //BA.debugLineNum = 2359303;BA.debugLine="End Sub";
return "";
}
public static String  _showcharacters() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=458752;
 //BA.debugLineNum = 458752;BA.debugLine="Sub ShowCharacters";
RDebugUtils.currentLine=458753;
 //BA.debugLineNum = 458753;BA.debugLine="icon1.Left = Activity.Left + 250dip";
mostCurrent._icon1.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))));
RDebugUtils.currentLine=458754;
 //BA.debugLineNum = 458754;BA.debugLine="icon1.Top = Activity.Top + 100dip";
mostCurrent._icon1.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=458755;
 //BA.debugLineNum = 458755;BA.debugLine="icon2.Left = Activity.Left + 50dip";
mostCurrent._icon2.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
RDebugUtils.currentLine=458756;
 //BA.debugLineNum = 458756;BA.debugLine="icon2.Top = Activity.Top + 200dip";
mostCurrent._icon2.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=458757;
 //BA.debugLineNum = 458757;BA.debugLine="icon3.Left = Activity.Left + 150dip";
mostCurrent._icon3.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))));
RDebugUtils.currentLine=458758;
 //BA.debugLineNum = 458758;BA.debugLine="icon3.Top = Activity.Top +  100dip";
mostCurrent._icon3.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=458759;
 //BA.debugLineNum = 458759;BA.debugLine="icon4.Left = Activity.Left + 150dip";
mostCurrent._icon4.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))));
RDebugUtils.currentLine=458760;
 //BA.debugLineNum = 458760;BA.debugLine="icon4.Top = Activity.Top +  200dip";
mostCurrent._icon4.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=458761;
 //BA.debugLineNum = 458761;BA.debugLine="icon5.Left = Activity.Left + 50dip";
mostCurrent._icon5.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
RDebugUtils.currentLine=458762;
 //BA.debugLineNum = 458762;BA.debugLine="icon5.Top = Activity.Top +  100dip";
mostCurrent._icon5.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=458763;
 //BA.debugLineNum = 458763;BA.debugLine="icon6.Left = Activity.Left + 250dip";
mostCurrent._icon6.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))));
RDebugUtils.currentLine=458764;
 //BA.debugLineNum = 458764;BA.debugLine="icon6.Top = Activity.Top +  200dip";
mostCurrent._icon6.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=458765;
 //BA.debugLineNum = 458765;BA.debugLine="End Sub";
return "";
}
public static String  _updatelabels() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=720896;
 //BA.debugLineNum = 720896;BA.debugLine="Sub UpdateLabels";
RDebugUtils.currentLine=720897;
 //BA.debugLineNum = 720897;BA.debugLine="lblRows.Text = \"Rows : \" & sbRows.Value";
mostCurrent._lblrows.setText((Object)("Rows : "+BA.NumberToString(mostCurrent._sbrows.getValue())));
RDebugUtils.currentLine=720898;
 //BA.debugLineNum = 720898;BA.debugLine="lblColumns.Text = \"Columns : \" & sbColumns.Value";
mostCurrent._lblcolumns.setText((Object)("Columns : "+BA.NumberToString(mostCurrent._sbcolumns.getValue())));
RDebugUtils.currentLine=720899;
 //BA.debugLineNum = 720899;BA.debugLine="End Sub";
return "";
}
public static boolean  _activity_keypress(int _keycode) throws Exception{
RDebugUtils.currentModule="main";
int _answ = 0;
RDebugUtils.currentLine=2686976;
 //BA.debugLineNum = 2686976;BA.debugLine="Sub Activity_KeyPress (KeyCode As Int) As Boolean 'Return True to consume the event";
RDebugUtils.currentLine=2686977;
 //BA.debugLineNum = 2686977;BA.debugLine="If KeyCode = KeyCodes.KEYCODE_BACK Then";
if (_keycode==anywheresoftware.b4a.keywords.Common.KeyCodes.KEYCODE_BACK) { 
RDebugUtils.currentLine=2686978;
 //BA.debugLineNum = 2686978;BA.debugLine="If inGame Then";
if (_ingame) { 
RDebugUtils.currentLine=2686979;
 //BA.debugLineNum = 2686979;BA.debugLine="Dim Answ As Int";
_answ = 0;
RDebugUtils.currentLine=2686980;
 //BA.debugLineNum = 2686980;BA.debugLine="Answ = Msgbox2(\"Do you want to quit this game, you will lose all progress.\", _ 		      \"W A R N I N G\", \"Yes\", \"\", \"No\", Null)";
_answ = anywheresoftware.b4a.keywords.Common.Msgbox2("Do you want to quit this game, you will lose all progress.","W A R N I N G","Yes","","No",(android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null),mostCurrent.activityBA);
RDebugUtils.currentLine=2686982;
 //BA.debugLineNum = 2686982;BA.debugLine="If Answ = DialogResponse.NEGATIVE Then";
if (_answ==anywheresoftware.b4a.keywords.Common.DialogResponse.NEGATIVE) { 
RDebugUtils.currentLine=2686983;
 //BA.debugLineNum = 2686983;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
RDebugUtils.currentLine=2686985;
 //BA.debugLineNum = 2686985;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
RDebugUtils.currentLine=2686986;
 //BA.debugLineNum = 2686986;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 };
 };
 };
RDebugUtils.currentLine=2686991;
 //BA.debugLineNum = 2686991;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
RDebugUtils.currentLine=2686992;
 //BA.debugLineNum = 2686992;BA.debugLine="End Sub";
return false;
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=1048576;
 //BA.debugLineNum = 1048576;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
RDebugUtils.currentLine=1048578;
 //BA.debugLineNum = 1048578;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=983040;
 //BA.debugLineNum = 983040;BA.debugLine="Sub Activity_Resume";
RDebugUtils.currentLine=983042;
 //BA.debugLineNum = 983042;BA.debugLine="End Sub";
return "";
}
public static String  _animatecharacters() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=262144;
 //BA.debugLineNum = 262144;BA.debugLine="Sub AnimateCharacters";
RDebugUtils.currentLine=262146;
 //BA.debugLineNum = 262146;BA.debugLine="anim1.InitializeTranslate(\"\", -120dip,100dip,350dip,100dip)";
mostCurrent._anim1.InitializeTranslate(mostCurrent.activityBA,"",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=262147;
 //BA.debugLineNum = 262147;BA.debugLine="anim1.Duration = 1500";
mostCurrent._anim1.setDuration((long) (1500));
RDebugUtils.currentLine=262148;
 //BA.debugLineNum = 262148;BA.debugLine="anim1.StartOffset = 250";
mostCurrent._anim1.setStartOffset((long) (250));
RDebugUtils.currentLine=262149;
 //BA.debugLineNum = 262149;BA.debugLine="anim1.PersistAfter = True";
mostCurrent._anim1.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=262150;
 //BA.debugLineNum = 262150;BA.debugLine="anim1.Start(icon1)";
mostCurrent._anim1.Start((android.view.View)(mostCurrent._icon1.getObject()));
RDebugUtils.currentLine=262151;
 //BA.debugLineNum = 262151;BA.debugLine="anim2.InitializeTranslate(\"\", 100%x + 120dip,200dip,150dip,200dip)";
mostCurrent._anim2.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=262152;
 //BA.debugLineNum = 262152;BA.debugLine="anim2.Duration = 1500";
mostCurrent._anim2.setDuration((long) (1500));
RDebugUtils.currentLine=262153;
 //BA.debugLineNum = 262153;BA.debugLine="anim2.StartOffset = 500";
mostCurrent._anim2.setStartOffset((long) (500));
RDebugUtils.currentLine=262154;
 //BA.debugLineNum = 262154;BA.debugLine="anim2.PersistAfter = True";
mostCurrent._anim2.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=262155;
 //BA.debugLineNum = 262155;BA.debugLine="anim2.Start(icon2)";
mostCurrent._anim2.Start((android.view.View)(mostCurrent._icon2.getObject()));
RDebugUtils.currentLine=262156;
 //BA.debugLineNum = 262156;BA.debugLine="anim3.InitializeTranslate(\"\", -120dip,100dip,250dip,100dip)";
mostCurrent._anim3.InitializeTranslate(mostCurrent.activityBA,"",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=262157;
 //BA.debugLineNum = 262157;BA.debugLine="anim3.Duration = 1500";
mostCurrent._anim3.setDuration((long) (1500));
RDebugUtils.currentLine=262158;
 //BA.debugLineNum = 262158;BA.debugLine="anim3.StartOffset = 750";
mostCurrent._anim3.setStartOffset((long) (750));
RDebugUtils.currentLine=262159;
 //BA.debugLineNum = 262159;BA.debugLine="anim3.PersistAfter = True";
mostCurrent._anim3.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=262160;
 //BA.debugLineNum = 262160;BA.debugLine="anim3.Start(icon3)";
mostCurrent._anim3.Start((android.view.View)(mostCurrent._icon3.getObject()));
RDebugUtils.currentLine=262161;
 //BA.debugLineNum = 262161;BA.debugLine="anim4.InitializeTranslate(\"\", 100%x + 120dip,200dip,250dip,200dip)";
mostCurrent._anim4.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=262162;
 //BA.debugLineNum = 262162;BA.debugLine="anim4.Duration = 1500";
mostCurrent._anim4.setDuration((long) (1500));
RDebugUtils.currentLine=262163;
 //BA.debugLineNum = 262163;BA.debugLine="anim4.StartOffset = 1000";
mostCurrent._anim4.setStartOffset((long) (1000));
RDebugUtils.currentLine=262164;
 //BA.debugLineNum = 262164;BA.debugLine="anim4.PersistAfter	 = True";
mostCurrent._anim4.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=262165;
 //BA.debugLineNum = 262165;BA.debugLine="anim4.Start(icon4)";
mostCurrent._anim4.Start((android.view.View)(mostCurrent._icon4.getObject()));
RDebugUtils.currentLine=262166;
 //BA.debugLineNum = 262166;BA.debugLine="anim5.InitializeTranslate(\"\", -120dip,100dip,150dip,100dip)";
mostCurrent._anim5.InitializeTranslate(mostCurrent.activityBA,"",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=262167;
 //BA.debugLineNum = 262167;BA.debugLine="anim5.Duration = 1500";
mostCurrent._anim5.setDuration((long) (1500));
RDebugUtils.currentLine=262168;
 //BA.debugLineNum = 262168;BA.debugLine="anim5.StartOffset = 750";
mostCurrent._anim5.setStartOffset((long) (750));
RDebugUtils.currentLine=262169;
 //BA.debugLineNum = 262169;BA.debugLine="anim5.PersistAfter = True";
mostCurrent._anim5.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=262170;
 //BA.debugLineNum = 262170;BA.debugLine="anim5.Start(icon5)";
mostCurrent._anim5.Start((android.view.View)(mostCurrent._icon5.getObject()));
RDebugUtils.currentLine=262171;
 //BA.debugLineNum = 262171;BA.debugLine="anim6.InitializeTranslate(\"\", 100%x + 120dip,200dip,350dip,200dip)";
mostCurrent._anim6.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=262172;
 //BA.debugLineNum = 262172;BA.debugLine="anim6.Duration = 1500";
mostCurrent._anim6.setDuration((long) (1500));
RDebugUtils.currentLine=262173;
 //BA.debugLineNum = 262173;BA.debugLine="anim6.StartOffset = 1000";
mostCurrent._anim6.setStartOffset((long) (1000));
RDebugUtils.currentLine=262174;
 //BA.debugLineNum = 262174;BA.debugLine="anim6.PersistAfter = True";
mostCurrent._anim6.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=262175;
 //BA.debugLineNum = 262175;BA.debugLine="anim6.Start(icon6)";
mostCurrent._anim6.Start((android.view.View)(mostCurrent._icon6.getObject()));
RDebugUtils.currentLine=262177;
 //BA.debugLineNum = 262177;BA.debugLine="End Sub";
return "";
}
public static String  _btncurrplayer_click() throws Exception{
RDebugUtils.currentModule="main";
pineysoft.squarepaddocks.turn _lastturn = null;
pineysoft.squarepaddocks.player _currplayer = null;
RDebugUtils.currentLine=2818048;
 //BA.debugLineNum = 2818048;BA.debugLine="Sub btnCurrPlayer_Click";
RDebugUtils.currentLine=2818049;
 //BA.debugLineNum = 2818049;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
RDebugUtils.currentLine=2818051;
 //BA.debugLineNum = 2818051;BA.debugLine="Dim lastTurn As Turn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
RDebugUtils.currentLine=2818052;
 //BA.debugLineNum = 2818052;BA.debugLine="Dim currPlayer As Player  = players.Get(lastTurn.PlayerNum)";
_currplayer = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get(_lastturn._playernum));
RDebugUtils.currentLine=2818054;
 //BA.debugLineNum = 2818054;BA.debugLine="RemoveTurn(lastTurn, currPlayer)";
_removeturn(_lastturn,_currplayer);
RDebugUtils.currentLine=2818056;
 //BA.debugLineNum = 2818056;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
RDebugUtils.currentLine=2818057;
 //BA.debugLineNum = 2818057;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
RDebugUtils.currentLine=2818058;
 //BA.debugLineNum = 2818058;BA.debugLine="currentPlayer = lastTurn.PlayerNum";
_currentplayer = (short) (_lastturn._playernum);
 }else {
RDebugUtils.currentLine=2818060;
 //BA.debugLineNum = 2818060;BA.debugLine="currentPlayer = 0";
_currentplayer = (short) (0);
 };
RDebugUtils.currentLine=2818063;
 //BA.debugLineNum = 2818063;BA.debugLine="btnCurrPlayer.SetBackgroundImage(playerImages.Get(currentPlayer))";
mostCurrent._btncurrplayer.SetBackgroundImage((android.graphics.Bitmap)(mostCurrent._playerimages.Get((int) (_currentplayer))));
RDebugUtils.currentLine=2818064;
 //BA.debugLineNum = 2818064;BA.debugLine="panel1.Invalidate";
mostCurrent._panel1.Invalidate();
 }else {
RDebugUtils.currentLine=2818066;
 //BA.debugLineNum = 2818066;BA.debugLine="ToastMessageShow(\"No More Undo's left\",False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow("No More Undo's left",anywheresoftware.b4a.keywords.Common.False);
 };
RDebugUtils.currentLine=2818069;
 //BA.debugLineNum = 2818069;BA.debugLine="End Sub";
return "";
}
public static String  _removeturn(pineysoft.squarepaddocks.turn _lastturn,pineysoft.squarepaddocks.player _currplayer) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=2752512;
 //BA.debugLineNum = 2752512;BA.debugLine="Public Sub RemoveTurn(lastTurn As Turn, currPlayer As Player)";
RDebugUtils.currentLine=2752515;
 //BA.debugLineNum = 2752515;BA.debugLine="If lastTurn.Square.sidesTaken = 4 Then";
if (_lastturn._square._sidestaken==4) { 
RDebugUtils.currentLine=2752516;
 //BA.debugLineNum = 2752516;BA.debugLine="currPlayer.Score = currPlayer.Score - 1";
_currplayer._score = (int) (_currplayer._score-1);
RDebugUtils.currentLine=2752517;
 //BA.debugLineNum = 2752517;BA.debugLine="EmptyTheSquare(lastTurn.Square)";
_emptythesquare(_lastturn._square);
 };
RDebugUtils.currentLine=2752521;
 //BA.debugLineNum = 2752521;BA.debugLine="lastTurn.Square.RemoveSide(canv, lastTurn.Edge)";
_lastturn._square._removeside(null,mostCurrent._canv,_lastturn._edge);
RDebugUtils.currentLine=2752522;
 //BA.debugLineNum = 2752522;BA.debugLine="MarkOtherSide(lastTurn.Square,lastTurn.Edge,False)";
_markotherside(_lastturn._square,_lastturn._edge,anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=2752525;
 //BA.debugLineNum = 2752525;BA.debugLine="gameTurns.RemoveAt(gameTurns.Size - 1)";
mostCurrent._gameturns.RemoveAt((int) (mostCurrent._gameturns.getSize()-1));
RDebugUtils.currentLine=2752528;
 //BA.debugLineNum = 2752528;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
RDebugUtils.currentLine=2752529;
 //BA.debugLineNum = 2752529;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
RDebugUtils.currentLine=2752530;
 //BA.debugLineNum = 2752530;BA.debugLine="lastTurn.Square.RedrawSide(canv, lastTurn.Edge)";
_lastturn._square._redrawside(null,mostCurrent._canv,_lastturn._edge);
 };
RDebugUtils.currentLine=2752532;
 //BA.debugLineNum = 2752532;BA.debugLine="End Sub";
return "";
}
public static String  _btnok_click() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=2883584;
 //BA.debugLineNum = 2883584;BA.debugLine="Sub btnOk_Click";
RDebugUtils.currentLine=2883585;
 //BA.debugLineNum = 2883585;BA.debugLine="pnlOuter.Left = -100%x";
mostCurrent._pnlouter.setLeft((int) (-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)));
RDebugUtils.currentLine=2883586;
 //BA.debugLineNum = 2883586;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
RDebugUtils.currentLine=2883587;
 //BA.debugLineNum = 2883587;BA.debugLine="End Sub";
return "";
}
public static String  _updateturn(anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,pineysoft.squarepaddocks.gamesquare _currentsquare,int _chosenside) throws Exception{
RDebugUtils.currentModule="main";
pineysoft.squarepaddocks.turn _lastturn = null;
pineysoft.squarepaddocks.turn _newturn = null;
RDebugUtils.currentLine=1376256;
 //BA.debugLineNum = 1376256;BA.debugLine="Sub UpdateTurn(cnv As Canvas, currentSquare As GameSquare, chosenSide As Int)";
RDebugUtils.currentLine=1376257;
 //BA.debugLineNum = 1376257;BA.debugLine="Dim lastTurn As Turn";
_lastturn = new pineysoft.squarepaddocks.turn();
RDebugUtils.currentLine=1376258;
 //BA.debugLineNum = 1376258;BA.debugLine="Dim newTurn As Turn";
_newturn = new pineysoft.squarepaddocks.turn();
RDebugUtils.currentLine=1376261;
 //BA.debugLineNum = 1376261;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
RDebugUtils.currentLine=1376262;
 //BA.debugLineNum = 1376262;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
RDebugUtils.currentLine=1376263;
 //BA.debugLineNum = 1376263;BA.debugLine="lastTurn.Square.DrawEdge2(canv,lastTurn.Edge,Colors.LightGray)";
_lastturn._square._drawedge2(null,mostCurrent._canv,_lastturn._edge,anywheresoftware.b4a.keywords.Common.Colors.LightGray);
 };
RDebugUtils.currentLine=1376267;
 //BA.debugLineNum = 1376267;BA.debugLine="newTurn.Initialize(currentSquare, chosenSide, currentPlayer)";
_newturn._initialize(null,mostCurrent.activityBA,_currentsquare,_chosenside,(int) (_currentplayer));
RDebugUtils.currentLine=1376270;
 //BA.debugLineNum = 1376270;BA.debugLine="gameTurns.Add(newTurn)";
mostCurrent._gameturns.Add((Object)(_newturn));
RDebugUtils.currentLine=1376271;
 //BA.debugLineNum = 1376271;BA.debugLine="End Sub";
return "";
}
public static String  _markotherside2(pineysoft.squarepaddocks.gamesquare _currentsquare,int _side) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=3932160;
 //BA.debugLineNum = 3932160;BA.debugLine="Public Sub MarkOtherSide2(currentSquare As GameSquare, side As Int)";
RDebugUtils.currentLine=3932161;
 //BA.debugLineNum = 3932161;BA.debugLine="MarkOtherSide(currentSquare, side, True)";
_markotherside(_currentsquare,_side,anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=3932162;
 //BA.debugLineNum = 3932162;BA.debugLine="End Sub";
return "";
}
public static String  _updateplayernumber() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=1441792;
 //BA.debugLineNum = 1441792;BA.debugLine="Sub UpdatePlayerNumber";
RDebugUtils.currentLine=1441793;
 //BA.debugLineNum = 1441793;BA.debugLine="currentPlayer = currentPlayer + 1";
_currentplayer = (short) (_currentplayer+1);
RDebugUtils.currentLine=1441794;
 //BA.debugLineNum = 1441794;BA.debugLine="If currentPlayer > numberOfPlayers - 1 Then currentPlayer = 0";
if (_currentplayer>_numberofplayers-1) { 
_currentplayer = (short) (0);};
RDebugUtils.currentLine=1441795;
 //BA.debugLineNum = 1441795;BA.debugLine="End Sub";
return "";
}
public static String  _fillthesquare(pineysoft.squarepaddocks.gamesquare _square,pineysoft.squarepaddocks.player _currplayer) throws Exception{
RDebugUtils.currentModule="main";
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _fillrect = null;
anywheresoftware.b4a.objects.LabelWrapper _lblnew = null;
RDebugUtils.currentLine=3670016;
 //BA.debugLineNum = 3670016;BA.debugLine="Sub FillTheSquare(square As GameSquare, currPlayer As Player)";
RDebugUtils.currentLine=3670017;
 //BA.debugLineNum = 3670017;BA.debugLine="Dim fillRect As Rect";
_fillrect = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
RDebugUtils.currentLine=3670019;
 //BA.debugLineNum = 3670019;BA.debugLine="If currPlayer.PlayerImage.IsInitialized Then";
if (_currplayer._playerimage.IsInitialized()) { 
RDebugUtils.currentLine=3670020;
 //BA.debugLineNum = 3670020;BA.debugLine="If square.fillLabel.IsInitialized Then";
if (_square._filllabel.IsInitialized()) { 
RDebugUtils.currentLine=3670021;
 //BA.debugLineNum = 3670021;BA.debugLine="square.fillLabel.SetBackgroundImage(currPlayer.PlayerImage)";
_square._filllabel.SetBackgroundImage((android.graphics.Bitmap)(_currplayer._playerimage.getObject()));
 }else {
RDebugUtils.currentLine=3670023;
 //BA.debugLineNum = 3670023;BA.debugLine="Dim lblNew As Label";
_lblnew = new anywheresoftware.b4a.objects.LabelWrapper();
RDebugUtils.currentLine=3670024;
 //BA.debugLineNum = 3670024;BA.debugLine="lblNew.Initialize(\"\")";
_lblnew.Initialize(mostCurrent.activityBA,"");
RDebugUtils.currentLine=3670025;
 //BA.debugLineNum = 3670025;BA.debugLine="lblNew.SetBackgroundImage(currPlayer.PlayerImage)";
_lblnew.SetBackgroundImage((android.graphics.Bitmap)(_currplayer._playerimage.getObject()));
RDebugUtils.currentLine=3670026;
 //BA.debugLineNum = 3670026;BA.debugLine="lblNew.Gravity = Gravity.FILL";
_lblnew.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
RDebugUtils.currentLine=3670027;
 //BA.debugLineNum = 3670027;BA.debugLine="square.fillLabel = lblNew";
_square._filllabel = _lblnew;
RDebugUtils.currentLine=3670028;
 //BA.debugLineNum = 3670028;BA.debugLine="panel1.AddView(lblNew, square.TopLeft.Pos1 + 4dip, square.TopLeft.Pos2  + 4dip, columnSpacing - 8dip, rowSpacing - 8dip)";
mostCurrent._panel1.AddView((android.view.View)(_lblnew.getObject()),(int) (_square._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_columnspacing-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8))),(int) (_rowspacing-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8))));
 };
 }else {
RDebugUtils.currentLine=3670031;
 //BA.debugLineNum = 3670031;BA.debugLine="fillRect.Initialize(square.TopLeft.Pos1 + 4dip, square.TopLeft.Pos2  + 4dip, square.BottomRight.Pos1  - 4dip, square.BottomRight.Pos2  - 4dip)";
_fillrect.Initialize((int) (_square._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
RDebugUtils.currentLine=3670032;
 //BA.debugLineNum = 3670032;BA.debugLine="canv.DrawRect(fillRect,currPlayer.colour,True,1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_fillrect.getObject()),_currplayer._colour,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 };
RDebugUtils.currentLine=3670034;
 //BA.debugLineNum = 3670034;BA.debugLine="End Sub";
return "";
}
public static String  _createboard() throws Exception{
RDebugUtils.currentModule="main";
int _colloop = 0;
int _rowloop = 0;
int _x = 0;
int _y = 0;
pineysoft.squarepaddocks.gamesquare _square = null;
RDebugUtils.currentLine=1179648;
 //BA.debugLineNum = 1179648;BA.debugLine="Sub CreateBoard";
RDebugUtils.currentLine=1179649;
 //BA.debugLineNum = 1179649;BA.debugLine="Dim colLoop As Int";
_colloop = 0;
RDebugUtils.currentLine=1179650;
 //BA.debugLineNum = 1179650;BA.debugLine="Dim rowLoop As Int";
_rowloop = 0;
RDebugUtils.currentLine=1179651;
 //BA.debugLineNum = 1179651;BA.debugLine="Dim x As Int = columnSpacing / 2";
_x = (int) (_columnspacing/(double)2);
RDebugUtils.currentLine=1179652;
 //BA.debugLineNum = 1179652;BA.debugLine="Dim y As Int = rowSpacing / 2";
_y = (int) (_rowspacing/(double)2);
RDebugUtils.currentLine=1179653;
 //BA.debugLineNum = 1179653;BA.debugLine="Dim gameSquares(gameHeight,gameWidth) As GameSquare";
mostCurrent._gamesquares = new pineysoft.squarepaddocks.gamesquare[_gameheight][];
{
int d0 = mostCurrent._gamesquares.length;
int d1 = _gamewidth;
for (int i0 = 0;i0 < d0;i0++) {
mostCurrent._gamesquares[i0] = new pineysoft.squarepaddocks.gamesquare[d1];
for (int i1 = 0;i1 < d1;i1++) {
mostCurrent._gamesquares[i0][i1] = new pineysoft.squarepaddocks.gamesquare();
}
}
}
;
RDebugUtils.currentLine=1179655;
 //BA.debugLineNum = 1179655;BA.debugLine="For rowLoop = 0 To gameHeight - 1";
{
final int step269 = 1;
final int limit269 = (int) (_gameheight-1);
for (_rowloop = (int) (0); (step269 > 0 && _rowloop <= limit269) || (step269 < 0 && _rowloop >= limit269); _rowloop = ((int)(0 + _rowloop + step269))) {
RDebugUtils.currentLine=1179656;
 //BA.debugLineNum = 1179656;BA.debugLine="For colLoop = 0 To gameWidth - 1";
{
final int step270 = 1;
final int limit270 = (int) (_gamewidth-1);
for (_colloop = (int) (0); (step270 > 0 && _colloop <= limit270) || (step270 < 0 && _colloop >= limit270); _colloop = ((int)(0 + _colloop + step270))) {
RDebugUtils.currentLine=1179657;
 //BA.debugLineNum = 1179657;BA.debugLine="Dim square As GameSquare";
_square = new pineysoft.squarepaddocks.gamesquare();
RDebugUtils.currentLine=1179658;
 //BA.debugLineNum = 1179658;BA.debugLine="square.Initialize(x,y,columnSpacing,rowSpacing,rowLoop,colLoop)";
_square._initialize(null,mostCurrent.activityBA,_x,_y,_columnspacing,_rowspacing,_rowloop,_colloop);
RDebugUtils.currentLine=1179659;
 //BA.debugLineNum = 1179659;BA.debugLine="gameSquares(rowLoop, colLoop) = square";
mostCurrent._gamesquares[_rowloop][_colloop] = _square;
RDebugUtils.currentLine=1179660;
 //BA.debugLineNum = 1179660;BA.debugLine="x = x + columnSpacing";
_x = (int) (_x+_columnspacing);
 }
};
RDebugUtils.currentLine=1179662;
 //BA.debugLineNum = 1179662;BA.debugLine="x = columnSpacing / 2";
_x = (int) (_columnspacing/(double)2);
RDebugUtils.currentLine=1179663;
 //BA.debugLineNum = 1179663;BA.debugLine="y = y + rowSpacing";
_y = (int) (_y+_rowspacing);
 }
};
RDebugUtils.currentLine=1179665;
 //BA.debugLineNum = 1179665;BA.debugLine="End Sub";
return "";
}
public static String  _drawboard() throws Exception{
RDebugUtils.currentModule="main";
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _square = null;
int _rowloop = 0;
int _colloop = 0;
pineysoft.squarepaddocks.gamesquare _gsquare = null;
RDebugUtils.currentLine=1245184;
 //BA.debugLineNum = 1245184;BA.debugLine="Sub DrawBoard";
RDebugUtils.currentLine=1245185;
 //BA.debugLineNum = 1245185;BA.debugLine="Dim square As Rect";
_square = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
RDebugUtils.currentLine=1245186;
 //BA.debugLineNum = 1245186;BA.debugLine="For rowLoop = 0 To gameHeight - 1";
{
final int step282 = 1;
final int limit282 = (int) (_gameheight-1);
for (_rowloop = (int) (0); (step282 > 0 && _rowloop <= limit282) || (step282 < 0 && _rowloop >= limit282); _rowloop = ((int)(0 + _rowloop + step282))) {
RDebugUtils.currentLine=1245187;
 //BA.debugLineNum = 1245187;BA.debugLine="For colLoop = 0 To gameWidth - 1";
{
final int step283 = 1;
final int limit283 = (int) (_gamewidth-1);
for (_colloop = (int) (0); (step283 > 0 && _colloop <= limit283) || (step283 < 0 && _colloop >= limit283); _colloop = ((int)(0 + _colloop + step283))) {
RDebugUtils.currentLine=1245188;
 //BA.debugLineNum = 1245188;BA.debugLine="Dim gSquare As GameSquare = gameSquares(rowLoop, colLoop)";
_gsquare = mostCurrent._gamesquares[_rowloop][_colloop];
RDebugUtils.currentLine=1245190;
 //BA.debugLineNum = 1245190;BA.debugLine="square.Initialize(gSquare.TopLeft.Pos1-4dip,gSquare.TopLeft.Pos2-4dip,gSquare.TopLeft.Pos1+4dip,gSquare.TopLeft.Pos2+4dip)";
_square.Initialize((int) (_gsquare._topleft._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topleft._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
RDebugUtils.currentLine=1245191;
 //BA.debugLineNum = 1245191;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
RDebugUtils.currentLine=1245192;
 //BA.debugLineNum = 1245192;BA.debugLine="square.Initialize(gSquare.TopRight.Pos1-4dip,gSquare.TopRight.Pos2-4dip,gSquare.TopRight.Pos1+4dip,gSquare.TopRight.Pos2+4dip)";
_square.Initialize((int) (_gsquare._topright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topright._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topright._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
RDebugUtils.currentLine=1245193;
 //BA.debugLineNum = 1245193;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
RDebugUtils.currentLine=1245194;
 //BA.debugLineNum = 1245194;BA.debugLine="square.Initialize(gSquare.BottomLeft.Pos1-4dip,gSquare.BottomLeft.Pos2-4dip,gSquare.BottomLeft.Pos1+4dip,gSquare.BottomLeft.Pos2+4dip)";
_square.Initialize((int) (_gsquare._bottomleft._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomleft._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
RDebugUtils.currentLine=1245195;
 //BA.debugLineNum = 1245195;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
RDebugUtils.currentLine=1245196;
 //BA.debugLineNum = 1245196;BA.debugLine="square.Initialize(gSquare.BottomRight.Pos1-4dip,gSquare.BottomRight.Pos2-4dip,gSquare.BottomRight.Pos1+4dip,gSquare.BottomRight.Pos2+4dip)";
_square.Initialize((int) (_gsquare._bottomright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomright._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomright._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
RDebugUtils.currentLine=1245197;
 //BA.debugLineNum = 1245197;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
RDebugUtils.currentLine=1245198;
 //BA.debugLineNum = 1245198;BA.debugLine="Log(\"Drawing \" & rowLoop & \", \" & colLoop)";
anywheresoftware.b4a.keywords.Common.Log("Drawing "+BA.NumberToString(_rowloop)+", "+BA.NumberToString(_colloop));
 }
};
 }
};
RDebugUtils.currentLine=1245201;
 //BA.debugLineNum = 1245201;BA.debugLine="End Sub";
return "";
}
public static String  _emptythesquare(pineysoft.squarepaddocks.gamesquare _square) throws Exception{
RDebugUtils.currentModule="main";
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _fillrect = null;
RDebugUtils.currentLine=1966080;
 //BA.debugLineNum = 1966080;BA.debugLine="Sub EmptyTheSquare(square As GameSquare)";
RDebugUtils.currentLine=1966081;
 //BA.debugLineNum = 1966081;BA.debugLine="Dim fillRect As Rect";
_fillrect = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
RDebugUtils.currentLine=1966083;
 //BA.debugLineNum = 1966083;BA.debugLine="If square.fillLabel.IsInitialized Then";
if (_square._filllabel.IsInitialized()) { 
RDebugUtils.currentLine=1966084;
 //BA.debugLineNum = 1966084;BA.debugLine="square.fillLabel.SetBackgroundImage(Null)";
_square._filllabel.SetBackgroundImage((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null));
 }else {
RDebugUtils.currentLine=1966086;
 //BA.debugLineNum = 1966086;BA.debugLine="fillRect.Initialize(square.TopLeft.Pos1 + 4dip, square.TopLeft.pos2  + 4dip, square.BottomRight.pos1  - 4dip, square.BottomRight.Pos2  - 4dip)";
_fillrect.Initialize((int) (_square._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
RDebugUtils.currentLine=1966087;
 //BA.debugLineNum = 1966087;BA.debugLine="canv.DrawRect(fillRect,SPConstants.BG_COLOUR,True,1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_fillrect.getObject()),_spconstants._bg_colour,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 };
RDebugUtils.currentLine=1966089;
 //BA.debugLineNum = 1966089;BA.debugLine="End Sub";
return "";
}
public static String  _takesingle(anywheresoftware.b4a.objects.collections.List _foundvalids) throws Exception{
RDebugUtils.currentModule="main";
int _rndnum = 0;
boolean _sideisavailable = false;
pineysoft.squarepaddocks.gamesquare _foundsquare = null;
int _rndside = 0;
RDebugUtils.currentLine=1703936;
 //BA.debugLineNum = 1703936;BA.debugLine="Sub TakeSingle(foundValids As List)";
RDebugUtils.currentLine=1703937;
 //BA.debugLineNum = 1703937;BA.debugLine="Dim rndnum As Int";
_rndnum = 0;
RDebugUtils.currentLine=1703938;
 //BA.debugLineNum = 1703938;BA.debugLine="Dim sideIsAvailable As Boolean = False";
_sideisavailable = anywheresoftware.b4a.keywords.Common.False;
RDebugUtils.currentLine=1703940;
 //BA.debugLineNum = 1703940;BA.debugLine="If foundValids.Size > 0 Then";
if (_foundvalids.getSize()>0) { 
RDebugUtils.currentLine=1703941;
 //BA.debugLineNum = 1703941;BA.debugLine="If foundValids.Size > 1 Then";
if (_foundvalids.getSize()>1) { 
RDebugUtils.currentLine=1703942;
 //BA.debugLineNum = 1703942;BA.debugLine="rndnum = Rnd(1, foundValids.Size)";
_rndnum = anywheresoftware.b4a.keywords.Common.Rnd((int) (1),_foundvalids.getSize());
 }else {
RDebugUtils.currentLine=1703944;
 //BA.debugLineNum = 1703944;BA.debugLine="rndnum = 1";
_rndnum = (int) (1);
 };
RDebugUtils.currentLine=1703947;
 //BA.debugLineNum = 1703947;BA.debugLine="Dim foundSquare As GameSquare = foundValids.Get(rndnum - 1)";
_foundsquare = (pineysoft.squarepaddocks.gamesquare)(_foundvalids.Get((int) (_rndnum-1)));
RDebugUtils.currentLine=1703949;
 //BA.debugLineNum = 1703949;BA.debugLine="Dim rndSide As Int = Rnd(1,4)";
_rndside = anywheresoftware.b4a.keywords.Common.Rnd((int) (1),(int) (4));
RDebugUtils.currentLine=1703951;
 //BA.debugLineNum = 1703951;BA.debugLine="Do While sideIsAvailable";
while (_sideisavailable) {
RDebugUtils.currentLine=1703952;
 //BA.debugLineNum = 1703952;BA.debugLine="If foundSquare.IsSideTaken(rndSide) = False Then";
if (_foundsquare._issidetaken(null,_rndside)==anywheresoftware.b4a.keywords.Common.False) { 
RDebugUtils.currentLine=1703953;
 //BA.debugLineNum = 1703953;BA.debugLine="sideIsAvailable = True";
_sideisavailable = anywheresoftware.b4a.keywords.Common.True;
 };
 }
;
RDebugUtils.currentLine=1703957;
 //BA.debugLineNum = 1703957;BA.debugLine="UpdateTurn(canv, foundSquare, rndSide)";
_updateturn(mostCurrent._canv,_foundsquare,_rndside);
RDebugUtils.currentLine=1703959;
 //BA.debugLineNum = 1703959;BA.debugLine="foundSquare.TakeSide(canv, rndSide)";
_foundsquare._takeside(null,mostCurrent._canv,_rndside);
RDebugUtils.currentLine=1703961;
 //BA.debugLineNum = 1703961;BA.debugLine="MarkOtherSide2(foundSquare, rndSide)";
_markotherside2(_foundsquare,_rndside);
 };
RDebugUtils.currentLine=1703964;
 //BA.debugLineNum = 1703964;BA.debugLine="End Sub";
return "";
}
public static String  _markotherside(pineysoft.squarepaddocks.gamesquare _currentsquare,int _side,boolean _marktaken) throws Exception{
RDebugUtils.currentModule="main";
int _foundcol = 0;
int _foundrow = 0;
int _updateside = 0;
RDebugUtils.currentLine=1507328;
 //BA.debugLineNum = 1507328;BA.debugLine="Public Sub MarkOtherSide(currentSquare As GameSquare, side As Int, markTaken As Boolean)";
RDebugUtils.currentLine=1507329;
 //BA.debugLineNum = 1507329;BA.debugLine="Dim foundCol As Int = -1";
_foundcol = (int) (-1);
RDebugUtils.currentLine=1507330;
 //BA.debugLineNum = 1507330;BA.debugLine="Dim foundRow As Int = -1";
_foundrow = (int) (-1);
RDebugUtils.currentLine=1507331;
 //BA.debugLineNum = 1507331;BA.debugLine="Dim updateSide As Int";
_updateside = 0;
RDebugUtils.currentLine=1507333;
 //BA.debugLineNum = 1507333;BA.debugLine="foundRow = currentSquare.RowPos";
_foundrow = _currentsquare._rowpos;
RDebugUtils.currentLine=1507334;
 //BA.debugLineNum = 1507334;BA.debugLine="foundCol = currentSquare.ColPos";
_foundcol = _currentsquare._colpos;
RDebugUtils.currentLine=1507337;
 //BA.debugLineNum = 1507337;BA.debugLine="Select side";
switch (BA.switchObjectToInt(_side,_spconstants._top_side,_spconstants._right_side,_spconstants._bottom_side,_spconstants._left_side)) {
case 0:
RDebugUtils.currentLine=1507339;
 //BA.debugLineNum = 1507339;BA.debugLine="If foundRow > 0 Then";
if (_foundrow>0) { 
RDebugUtils.currentLine=1507340;
 //BA.debugLineNum = 1507340;BA.debugLine="foundRow = foundRow - 1";
_foundrow = (int) (_foundrow-1);
RDebugUtils.currentLine=1507341;
 //BA.debugLineNum = 1507341;BA.debugLine="updateSide = SPConstants.BOTTOM_SIDE";
_updateside = _spconstants._bottom_side;
 }else {
RDebugUtils.currentLine=1507343;
 //BA.debugLineNum = 1507343;BA.debugLine="foundRow = -1";
_foundrow = (int) (-1);
 };
 break;
case 1:
RDebugUtils.currentLine=1507346;
 //BA.debugLineNum = 1507346;BA.debugLine="If foundCol < gameWidth - 1 Then";
if (_foundcol<_gamewidth-1) { 
RDebugUtils.currentLine=1507347;
 //BA.debugLineNum = 1507347;BA.debugLine="foundCol = foundCol + 1";
_foundcol = (int) (_foundcol+1);
RDebugUtils.currentLine=1507348;
 //BA.debugLineNum = 1507348;BA.debugLine="updateSide = SPConstants.LEFT_SIDE";
_updateside = _spconstants._left_side;
 }else {
RDebugUtils.currentLine=1507350;
 //BA.debugLineNum = 1507350;BA.debugLine="foundCol = -1";
_foundcol = (int) (-1);
 };
 break;
case 2:
RDebugUtils.currentLine=1507353;
 //BA.debugLineNum = 1507353;BA.debugLine="If foundRow < gameHeight - 1 Then";
if (_foundrow<_gameheight-1) { 
RDebugUtils.currentLine=1507354;
 //BA.debugLineNum = 1507354;BA.debugLine="foundRow = foundRow + 1";
_foundrow = (int) (_foundrow+1);
RDebugUtils.currentLine=1507355;
 //BA.debugLineNum = 1507355;BA.debugLine="updateSide = SPConstants.TOP_SIDE";
_updateside = _spconstants._top_side;
 }else {
RDebugUtils.currentLine=1507357;
 //BA.debugLineNum = 1507357;BA.debugLine="foundRow = -1";
_foundrow = (int) (-1);
 };
 break;
case 3:
RDebugUtils.currentLine=1507360;
 //BA.debugLineNum = 1507360;BA.debugLine="If foundCol > 0 Then";
if (_foundcol>0) { 
RDebugUtils.currentLine=1507361;
 //BA.debugLineNum = 1507361;BA.debugLine="foundCol = foundCol - 1";
_foundcol = (int) (_foundcol-1);
RDebugUtils.currentLine=1507362;
 //BA.debugLineNum = 1507362;BA.debugLine="updateSide = SPConstants.RIGHT_SIDE";
_updateside = _spconstants._right_side;
 }else {
RDebugUtils.currentLine=1507364;
 //BA.debugLineNum = 1507364;BA.debugLine="foundCol = -1";
_foundcol = (int) (-1);
 };
 break;
}
;
RDebugUtils.currentLine=1507368;
 //BA.debugLineNum = 1507368;BA.debugLine="If foundRow <> -1 AND foundCol <> -1 Then";
if (_foundrow!=-1 && _foundcol!=-1) { 
RDebugUtils.currentLine=1507369;
 //BA.debugLineNum = 1507369;BA.debugLine="gameSquares(foundRow,foundCol).MarkSideTaken(updateSide, markTaken)";
mostCurrent._gamesquares[_foundrow][_foundcol]._marksidetaken(null,_updateside,_marktaken);
 };
RDebugUtils.currentLine=1507371;
 //BA.debugLineNum = 1507371;BA.debugLine="End Sub";
return "";
}
public static String  _reverseanimate() throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=327680;
 //BA.debugLineNum = 327680;BA.debugLine="Sub ReverseAnimate";
RDebugUtils.currentLine=327688;
 //BA.debugLineNum = 327688;BA.debugLine="anim1.InitializeTranslate(\"\", 350dip,100dip,-120dip,100dip)";
mostCurrent._anim1.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=327689;
 //BA.debugLineNum = 327689;BA.debugLine="anim1.Duration = 1000";
mostCurrent._anim1.setDuration((long) (1000));
RDebugUtils.currentLine=327690;
 //BA.debugLineNum = 327690;BA.debugLine="anim1.PersistAfter = True";
mostCurrent._anim1.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=327691;
 //BA.debugLineNum = 327691;BA.debugLine="anim1.Start(icon1)";
mostCurrent._anim1.Start((android.view.View)(mostCurrent._icon1.getObject()));
RDebugUtils.currentLine=327692;
 //BA.debugLineNum = 327692;BA.debugLine="anim2.InitializeTranslate(\"\", 150dip,200dip,100%x + 120dip,200dip)";
mostCurrent._anim2.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
RDebugUtils.currentLine=327693;
 //BA.debugLineNum = 327693;BA.debugLine="anim2.Duration = 1000";
mostCurrent._anim2.setDuration((long) (1000));
RDebugUtils.currentLine=327694;
 //BA.debugLineNum = 327694;BA.debugLine="anim2.StartOffset = 150";
mostCurrent._anim2.setStartOffset((long) (150));
RDebugUtils.currentLine=327695;
 //BA.debugLineNum = 327695;BA.debugLine="anim2.PersistAfter = True";
mostCurrent._anim2.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=327696;
 //BA.debugLineNum = 327696;BA.debugLine="anim2.Start(icon2)";
mostCurrent._anim2.Start((android.view.View)(mostCurrent._icon2.getObject()));
RDebugUtils.currentLine=327697;
 //BA.debugLineNum = 327697;BA.debugLine="anim3.InitializeTranslate(\"\", 250dip,100dip,-120dip,100dip)";
mostCurrent._anim3.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=327698;
 //BA.debugLineNum = 327698;BA.debugLine="anim3.Duration = 1000";
mostCurrent._anim3.setDuration((long) (1000));
RDebugUtils.currentLine=327699;
 //BA.debugLineNum = 327699;BA.debugLine="anim3.StartOffset = 300";
mostCurrent._anim3.setStartOffset((long) (300));
RDebugUtils.currentLine=327700;
 //BA.debugLineNum = 327700;BA.debugLine="anim3.PersistAfter = True";
mostCurrent._anim3.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=327701;
 //BA.debugLineNum = 327701;BA.debugLine="anim3.Start(icon3)";
mostCurrent._anim3.Start((android.view.View)(mostCurrent._icon3.getObject()));
RDebugUtils.currentLine=327702;
 //BA.debugLineNum = 327702;BA.debugLine="anim4.InitializeTranslate(\"\", 200dip,250dip,200dip,100%x + 120dip)";
mostCurrent._anim4.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))));
RDebugUtils.currentLine=327703;
 //BA.debugLineNum = 327703;BA.debugLine="anim4.Duration = 1000";
mostCurrent._anim4.setDuration((long) (1000));
RDebugUtils.currentLine=327704;
 //BA.debugLineNum = 327704;BA.debugLine="anim4.StartOffset = 450";
mostCurrent._anim4.setStartOffset((long) (450));
RDebugUtils.currentLine=327705;
 //BA.debugLineNum = 327705;BA.debugLine="anim4.PersistAfter	 = True";
mostCurrent._anim4.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=327706;
 //BA.debugLineNum = 327706;BA.debugLine="anim4.Start(icon4)";
mostCurrent._anim4.Start((android.view.View)(mostCurrent._icon4.getObject()));
RDebugUtils.currentLine=327707;
 //BA.debugLineNum = 327707;BA.debugLine="anim5.InitializeTranslate(\"\", 150dip,100dip,-120dip,100dip)";
mostCurrent._anim5.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
RDebugUtils.currentLine=327708;
 //BA.debugLineNum = 327708;BA.debugLine="anim5.Duration = 1000";
mostCurrent._anim5.setDuration((long) (1000));
RDebugUtils.currentLine=327709;
 //BA.debugLineNum = 327709;BA.debugLine="anim5.StartOffset = 600";
mostCurrent._anim5.setStartOffset((long) (600));
RDebugUtils.currentLine=327710;
 //BA.debugLineNum = 327710;BA.debugLine="anim5.PersistAfter = True";
mostCurrent._anim5.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=327711;
 //BA.debugLineNum = 327711;BA.debugLine="anim5.Start(icon5)";
mostCurrent._anim5.Start((android.view.View)(mostCurrent._icon5.getObject()));
RDebugUtils.currentLine=327712;
 //BA.debugLineNum = 327712;BA.debugLine="anim6.InitializeTranslate(\"anim6\", 200dip,350dip,200dip,100%x + 120dip)";
mostCurrent._anim6.InitializeTranslate(mostCurrent.activityBA,"anim6",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))));
RDebugUtils.currentLine=327713;
 //BA.debugLineNum = 327713;BA.debugLine="anim6.Duration = 1000";
mostCurrent._anim6.setDuration((long) (1000));
RDebugUtils.currentLine=327714;
 //BA.debugLineNum = 327714;BA.debugLine="anim6.StartOffset = 750";
mostCurrent._anim6.setStartOffset((long) (750));
RDebugUtils.currentLine=327715;
 //BA.debugLineNum = 327715;BA.debugLine="anim6.PersistAfter = True";
mostCurrent._anim6.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=327716;
 //BA.debugLineNum = 327716;BA.debugLine="anim6.Start(icon6)";
mostCurrent._anim6.Start((android.view.View)(mostCurrent._icon6.getObject()));
RDebugUtils.currentLine=327717;
 //BA.debugLineNum = 327717;BA.debugLine="End Sub";
return "";
}
public static String  _sbcolumns_valuechanged(int _value,boolean _userchanged) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=2621440;
 //BA.debugLineNum = 2621440;BA.debugLine="Sub sbColumns_ValueChanged (Value As Int, UserChanged As Boolean)";
RDebugUtils.currentLine=2621441;
 //BA.debugLineNum = 2621441;BA.debugLine="If Value < 4 AND UserChanged = True Then";
if (_value<4 && _userchanged==anywheresoftware.b4a.keywords.Common.True) { 
RDebugUtils.currentLine=2621442;
 //BA.debugLineNum = 2621442;BA.debugLine="sbColumns.Value = 4";
mostCurrent._sbcolumns.setValue((int) (4));
 };
RDebugUtils.currentLine=2621444;
 //BA.debugLineNum = 2621444;BA.debugLine="gameWidth = Value";
_gamewidth = _value;
RDebugUtils.currentLine=2621445;
 //BA.debugLineNum = 2621445;BA.debugLine="lblColumns.Text = \"Columns : \" & Value";
mostCurrent._lblcolumns.setText((Object)("Columns : "+BA.NumberToString(_value)));
RDebugUtils.currentLine=2621446;
 //BA.debugLineNum = 2621446;BA.debugLine="End Sub";
return "";
}
public static String  _sbrows_valuechanged(int _value,boolean _userchanged) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=2555904;
 //BA.debugLineNum = 2555904;BA.debugLine="Sub sbRows_ValueChanged (Value As Int, UserChanged As Boolean)";
RDebugUtils.currentLine=2555905;
 //BA.debugLineNum = 2555905;BA.debugLine="If Value < 4 AND UserChanged = True Then";
if (_value<4 && _userchanged==anywheresoftware.b4a.keywords.Common.True) { 
RDebugUtils.currentLine=2555906;
 //BA.debugLineNum = 2555906;BA.debugLine="sbRows.Value = 4";
mostCurrent._sbrows.setValue((int) (4));
 };
RDebugUtils.currentLine=2555908;
 //BA.debugLineNum = 2555908;BA.debugLine="gameHeight = Value";
_gameheight = _value;
RDebugUtils.currentLine=2555909;
 //BA.debugLineNum = 2555909;BA.debugLine="lblRows.Text = \"Rows : \" & Value";
mostCurrent._lblrows.setText((Object)("Rows : "+BA.NumberToString(_value)));
RDebugUtils.currentLine=2555910;
 //BA.debugLineNum = 2555910;BA.debugLine="End Sub";
return "";
}
}