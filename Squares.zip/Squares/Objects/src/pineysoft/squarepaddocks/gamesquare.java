package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class gamesquare extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new anywheresoftware.b4a.ShellBA(_ba, this, htSubs, "pineysoft.squarepaddocks.gamesquare");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            if (BA.isShellModeRuntimeCheck(ba)) {
			    ba.raiseEvent2(null, true, "CREATE", true, "pineysoft.squarepaddocks.gamesquare",
                    ba);
                return;
		    }
        }
        ba.raiseEvent2(null, true, "class_globals", false);
    }

 
    public void  innerInitializeHelper(anywheresoftware.b4a.BA _ba) throws Exception{
        innerInitialize(_ba);
    }
    public Object callSub(String sub, Object sender, Object[] args) throws Exception {
        return BA.SubDelegator.SubNotFound;
    }
public anywheresoftware.b4a.keywords.Common __c = null;
public int _colpos = 0;
public int _rowpos = 0;
public pineysoft.squarepaddocks.point _topleft = null;
public pineysoft.squarepaddocks.point _topright = null;
public pineysoft.squarepaddocks.point _bottomleft = null;
public pineysoft.squarepaddocks.point _bottomright = null;
public char[] _sides = null;
public boolean _occupied = false;
public pineysoft.squarepaddocks.constants _spconstants = null;
public int _sidestaken = 0;
public anywheresoftware.b4a.objects.LabelWrapper _filllabel = null;
public pineysoft.squarepaddocks.main _main = null;
public int  _calculateclosestedge(pineysoft.squarepaddocks.gamesquare __ref,pineysoft.squarepaddocks.point _xypos) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
double _deltax = 0;
double _deltay = 0;
double _deg = 0;
RDebugUtils.currentLine=3145728;
 //BA.debugLineNum = 3145728;BA.debugLine="Public Sub CalculateClosestEdge(xypos As Point) As Int";
RDebugUtils.currentLine=3145729;
 //BA.debugLineNum = 3145729;BA.debugLine="Dim deltax As Double";
_deltax = 0;
RDebugUtils.currentLine=3145730;
 //BA.debugLineNum = 3145730;BA.debugLine="Dim deltaY As Double";
_deltay = 0;
RDebugUtils.currentLine=3145731;
 //BA.debugLineNum = 3145731;BA.debugLine="Dim deg As Double";
_deg = 0;
RDebugUtils.currentLine=3145734;
 //BA.debugLineNum = 3145734;BA.debugLine="If xypos.Pos1 < TopLeft.Pos1 + (TopRight.Pos1 - TopLeft.Pos1) / 2 Then";
if (_xypos._pos1<__ref._topleft._pos1+(__ref._topright._pos1-__ref._topleft._pos1)/(double)2) { 
RDebugUtils.currentLine=3145735;
 //BA.debugLineNum = 3145735;BA.debugLine="If xypos.Pos2 < (TopLeft.Pos2 + (BottomLeft.Pos2 - TopLeft.Pos2) / 2) Then";
if (_xypos._pos2<(__ref._topleft._pos2+(__ref._bottomleft._pos2-__ref._topleft._pos2)/(double)2)) { 
RDebugUtils.currentLine=3145736;
 //BA.debugLineNum = 3145736;BA.debugLine="deltax = TopLeft.Pos1 - xypos.Pos1";
_deltax = __ref._topleft._pos1-_xypos._pos1;
RDebugUtils.currentLine=3145737;
 //BA.debugLineNum = 3145737;BA.debugLine="deltaY = TopLeft.Pos2 - xypos.Pos2";
_deltay = __ref._topleft._pos2-_xypos._pos2;
RDebugUtils.currentLine=3145738;
 //BA.debugLineNum = 3145738;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
_deg = __c.ATan2(_deltay,_deltax)*(180/(double)3.14159265359);
RDebugUtils.currentLine=3145739;
 //BA.debugLineNum = 3145739;BA.debugLine="Log(\"Top Left Deg = \" & deg)";
__c.Log("Top Left Deg = "+BA.NumberToString(_deg));
RDebugUtils.currentLine=3145740;
 //BA.debugLineNum = 3145740;BA.debugLine="If deg > -135 Then";
if (_deg>-135) { 
RDebugUtils.currentLine=3145741;
 //BA.debugLineNum = 3145741;BA.debugLine="Return SpConstants.LEFT_SIDE";
if (true) return __ref._spconstants._left_side;
 }else {
RDebugUtils.currentLine=3145743;
 //BA.debugLineNum = 3145743;BA.debugLine="Return SpConstants.TOP_SIDE";
if (true) return __ref._spconstants._top_side;
 };
 }else {
RDebugUtils.currentLine=3145746;
 //BA.debugLineNum = 3145746;BA.debugLine="deltax = BottomLeft.Pos1 - xypos.Pos1";
_deltax = __ref._bottomleft._pos1-_xypos._pos1;
RDebugUtils.currentLine=3145747;
 //BA.debugLineNum = 3145747;BA.debugLine="deltaY = BottomLeft.Pos2 - xypos.Pos2";
_deltay = __ref._bottomleft._pos2-_xypos._pos2;
RDebugUtils.currentLine=3145748;
 //BA.debugLineNum = 3145748;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
_deg = __c.ATan2(_deltay,_deltax)*(180/(double)3.14159265359);
RDebugUtils.currentLine=3145749;
 //BA.debugLineNum = 3145749;BA.debugLine="Log(\"Bottom Left Deg = \" & deg)";
__c.Log("Bottom Left Deg = "+BA.NumberToString(_deg));
RDebugUtils.currentLine=3145750;
 //BA.debugLineNum = 3145750;BA.debugLine="If deg > 135 Then";
if (_deg>135) { 
RDebugUtils.currentLine=3145751;
 //BA.debugLineNum = 3145751;BA.debugLine="Return SpConstants.BOTTOM_SIDE";
if (true) return __ref._spconstants._bottom_side;
 }else {
RDebugUtils.currentLine=3145753;
 //BA.debugLineNum = 3145753;BA.debugLine="Return SpConstants.LEFT_SIDE";
if (true) return __ref._spconstants._left_side;
 };
 };
 }else {
RDebugUtils.currentLine=3145757;
 //BA.debugLineNum = 3145757;BA.debugLine="If xypos.Pos2 < (TopLeft.Pos2 + (BottomLeft.Pos2 - TopLeft.Pos2) / 2) Then";
if (_xypos._pos2<(__ref._topleft._pos2+(__ref._bottomleft._pos2-__ref._topleft._pos2)/(double)2)) { 
RDebugUtils.currentLine=3145758;
 //BA.debugLineNum = 3145758;BA.debugLine="deltax = TopRight.Pos1 - xypos.Pos1";
_deltax = __ref._topright._pos1-_xypos._pos1;
RDebugUtils.currentLine=3145759;
 //BA.debugLineNum = 3145759;BA.debugLine="deltaY = TopRight.Pos2 - xypos.Pos2";
_deltay = __ref._topright._pos2-_xypos._pos2;
RDebugUtils.currentLine=3145760;
 //BA.debugLineNum = 3145760;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
_deg = __c.ATan2(_deltay,_deltax)*(180/(double)3.14159265359);
RDebugUtils.currentLine=3145761;
 //BA.debugLineNum = 3145761;BA.debugLine="Log(\"Top Right Deg = \" & deg)";
__c.Log("Top Right Deg = "+BA.NumberToString(_deg));
RDebugUtils.currentLine=3145762;
 //BA.debugLineNum = 3145762;BA.debugLine="If deg < -45 Then";
if (_deg<-45) { 
RDebugUtils.currentLine=3145763;
 //BA.debugLineNum = 3145763;BA.debugLine="Return SpConstants.RIGHT_SIDE";
if (true) return __ref._spconstants._right_side;
 }else {
RDebugUtils.currentLine=3145765;
 //BA.debugLineNum = 3145765;BA.debugLine="Return SpConstants.TOP_SIDE";
if (true) return __ref._spconstants._top_side;
 };
 }else {
RDebugUtils.currentLine=3145768;
 //BA.debugLineNum = 3145768;BA.debugLine="deltax = BottomRight.Pos1 - xypos.Pos1";
_deltax = __ref._bottomright._pos1-_xypos._pos1;
RDebugUtils.currentLine=3145769;
 //BA.debugLineNum = 3145769;BA.debugLine="deltaY = BottomRight.Pos2 - xypos.Pos2";
_deltay = __ref._bottomright._pos2-_xypos._pos2;
RDebugUtils.currentLine=3145770;
 //BA.debugLineNum = 3145770;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
_deg = __c.ATan2(_deltay,_deltax)*(180/(double)3.14159265359);
RDebugUtils.currentLine=3145771;
 //BA.debugLineNum = 3145771;BA.debugLine="Log(\"Bottom Right Deg = \" & deg)";
__c.Log("Bottom Right Deg = "+BA.NumberToString(_deg));
RDebugUtils.currentLine=3145772;
 //BA.debugLineNum = 3145772;BA.debugLine="If deg < 45 Then";
if (_deg<45) { 
RDebugUtils.currentLine=3145773;
 //BA.debugLineNum = 3145773;BA.debugLine="Return SpConstants.BOTTOM_SIDE";
if (true) return __ref._spconstants._bottom_side;
 }else {
RDebugUtils.currentLine=3145775;
 //BA.debugLineNum = 3145775;BA.debugLine="Return SpConstants.RIGHT_SIDE";
if (true) return __ref._spconstants._right_side;
 };
 };
 };
RDebugUtils.currentLine=3145780;
 //BA.debugLineNum = 3145780;BA.debugLine="End Sub";
return 0;
}
public boolean  _issidetaken(pineysoft.squarepaddocks.gamesquare __ref,int _side) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
RDebugUtils.currentLine=3211264;
 //BA.debugLineNum = 3211264;BA.debugLine="Public Sub IsSideTaken(side As Int) As Boolean";
RDebugUtils.currentLine=3211266;
 //BA.debugLineNum = 3211266;BA.debugLine="Return sides(side) = SpConstants.SIDE_TAKEN";
if (true) return __ref._sides[_side]==__ref._spconstants._side_taken;
RDebugUtils.currentLine=3211268;
 //BA.debugLineNum = 3211268;BA.debugLine="End Sub";
return false;
}
public String  _takeside(pineysoft.squarepaddocks.gamesquare __ref,anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,int _side) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
RDebugUtils.currentLine=3342336;
 //BA.debugLineNum = 3342336;BA.debugLine="Public Sub TakeSide(cnv As Canvas, side As Int)";
RDebugUtils.currentLine=3342337;
 //BA.debugLineNum = 3342337;BA.debugLine="DrawEdge2(cnv,side,Colors.Red)";
__ref._drawedge2(null,_cnv,_side,__c.Colors.Red);
RDebugUtils.currentLine=3342338;
 //BA.debugLineNum = 3342338;BA.debugLine="MarkSideTaken(side,True)";
__ref._marksidetaken(null,_side,__c.True);
RDebugUtils.currentLine=3342339;
 //BA.debugLineNum = 3342339;BA.debugLine="End Sub";
return "";
}
public String  _initialize(pineysoft.squarepaddocks.gamesquare __ref,anywheresoftware.b4a.BA _ba,int _x,int _y,int _width,int _height,int _row,int _col) throws Exception{
__ref = this;
innerInitialize(_ba);
RDebugUtils.currentModule="gamesquare";
RDebugUtils.currentLine=3014656;
 //BA.debugLineNum = 3014656;BA.debugLine="Public Sub Initialize(x As Int, y As Int, width As Int, height As Int, row As Int, col As Int)";
RDebugUtils.currentLine=3014657;
 //BA.debugLineNum = 3014657;BA.debugLine="TopLeft.Initialize(x,y)";
__ref._topleft._initialize(null,ba,_x,_y);
RDebugUtils.currentLine=3014658;
 //BA.debugLineNum = 3014658;BA.debugLine="TopRight.Initialize(x+width,y)";
__ref._topright._initialize(null,ba,(int) (_x+_width),_y);
RDebugUtils.currentLine=3014659;
 //BA.debugLineNum = 3014659;BA.debugLine="BottomLeft.Initialize(x,y+height)";
__ref._bottomleft._initialize(null,ba,_x,(int) (_y+_height));
RDebugUtils.currentLine=3014660;
 //BA.debugLineNum = 3014660;BA.debugLine="BottomRight.Initialize(x+width,y+height)";
__ref._bottomright._initialize(null,ba,(int) (_x+_width),(int) (_y+_height));
RDebugUtils.currentLine=3014661;
 //BA.debugLineNum = 3014661;BA.debugLine="SpConstants.Initialize";
__ref._spconstants._initialize(null,ba);
RDebugUtils.currentLine=3014662;
 //BA.debugLineNum = 3014662;BA.debugLine="ColPos = col";
__ref._colpos = _col;
RDebugUtils.currentLine=3014663;
 //BA.debugLineNum = 3014663;BA.debugLine="RowPos = row";
__ref._rowpos = _row;
RDebugUtils.currentLine=3014664;
 //BA.debugLineNum = 3014664;BA.debugLine="sides(0) = \"O\"";
__ref._sides[(int) (0)] = BA.ObjectToChar("O");
RDebugUtils.currentLine=3014665;
 //BA.debugLineNum = 3014665;BA.debugLine="sides(1) = \"O\"";
__ref._sides[(int) (1)] = BA.ObjectToChar("O");
RDebugUtils.currentLine=3014666;
 //BA.debugLineNum = 3014666;BA.debugLine="sides(2) = \"O\"";
__ref._sides[(int) (2)] = BA.ObjectToChar("O");
RDebugUtils.currentLine=3014667;
 //BA.debugLineNum = 3014667;BA.debugLine="sides(3) = \"O\"";
__ref._sides[(int) (3)] = BA.ObjectToChar("O");
RDebugUtils.currentLine=3014669;
 //BA.debugLineNum = 3014669;BA.debugLine="End Sub";
return "";
}
public String  _marksidetaken(pineysoft.squarepaddocks.gamesquare __ref,int _side,boolean _marktaken) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
RDebugUtils.currentLine=3276800;
 //BA.debugLineNum = 3276800;BA.debugLine="Public Sub MarkSideTaken(side As Int, markTaken As Boolean)";
RDebugUtils.currentLine=3276802;
 //BA.debugLineNum = 3276802;BA.debugLine="If markTaken Then";
if (_marktaken) { 
RDebugUtils.currentLine=3276803;
 //BA.debugLineNum = 3276803;BA.debugLine="sides(side) = SpConstants.SIDE_TAKEN";
__ref._sides[_side] = __ref._spconstants._side_taken;
RDebugUtils.currentLine=3276804;
 //BA.debugLineNum = 3276804;BA.debugLine="sidesTaken = sidesTaken + 1";
__ref._sidestaken = (int) (__ref._sidestaken+1);
 }else {
RDebugUtils.currentLine=3276806;
 //BA.debugLineNum = 3276806;BA.debugLine="sides(side) = SpConstants.SIDE_AVAILABLE";
__ref._sides[_side] = __ref._spconstants._side_available;
RDebugUtils.currentLine=3276807;
 //BA.debugLineNum = 3276807;BA.debugLine="sidesTaken = sidesTaken - 1";
__ref._sidestaken = (int) (__ref._sidestaken-1);
 };
RDebugUtils.currentLine=3276809;
 //BA.debugLineNum = 3276809;BA.debugLine="End Sub";
return "";
}
public String  _removeside(pineysoft.squarepaddocks.gamesquare __ref,anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,int _side) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
RDebugUtils.currentLine=3538944;
 //BA.debugLineNum = 3538944;BA.debugLine="Public Sub RemoveSide(cnv As Canvas, side As Int)";
RDebugUtils.currentLine=3538945;
 //BA.debugLineNum = 3538945;BA.debugLine="DrawEdge2(cnv, side, SpConstants.BG_COLOUR)";
__ref._drawedge2(null,_cnv,_side,__ref._spconstants._bg_colour);
RDebugUtils.currentLine=3538946;
 //BA.debugLineNum = 3538946;BA.debugLine="MarkSideTaken(side,False)";
__ref._marksidetaken(null,_side,__c.False);
RDebugUtils.currentLine=3538947;
 //BA.debugLineNum = 3538947;BA.debugLine="End Sub";
return "";
}
public String  _redrawside(pineysoft.squarepaddocks.gamesquare __ref,anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,int _side) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
RDebugUtils.currentLine=3604480;
 //BA.debugLineNum = 3604480;BA.debugLine="Public Sub RedrawSide(cnv As Canvas, side As Int)";
RDebugUtils.currentLine=3604481;
 //BA.debugLineNum = 3604481;BA.debugLine="DrawEdge2(cnv, side, SpConstants.CURRENT_SIDE_COLOUR)";
__ref._drawedge2(null,_cnv,_side,__ref._spconstants._current_side_colour);
RDebugUtils.currentLine=3604482;
 //BA.debugLineNum = 3604482;BA.debugLine="End Sub";
return "";
}
public String  _drawedge2(pineysoft.squarepaddocks.gamesquare __ref,anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,int _side,int _color) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
pineysoft.squarepaddocks.point _startpoint = null;
pineysoft.squarepaddocks.point _endpoint = null;
int _direction = 0;
RDebugUtils.currentLine=3473408;
 //BA.debugLineNum = 3473408;BA.debugLine="Public Sub DrawEdge2(cnv As Canvas, side As Int, color As Int)";
RDebugUtils.currentLine=3473409;
 //BA.debugLineNum = 3473409;BA.debugLine="Dim startPoint As Point";
_startpoint = new pineysoft.squarepaddocks.point();
RDebugUtils.currentLine=3473410;
 //BA.debugLineNum = 3473410;BA.debugLine="Dim endPoint As Point";
_endpoint = new pineysoft.squarepaddocks.point();
RDebugUtils.currentLine=3473411;
 //BA.debugLineNum = 3473411;BA.debugLine="Dim direction As Int";
_direction = 0;
RDebugUtils.currentLine=3473412;
 //BA.debugLineNum = 3473412;BA.debugLine="Select side";
switch (BA.switchObjectToInt(_side,__ref._spconstants._top_side,__ref._spconstants._right_side,__ref._spconstants._bottom_side,__ref._spconstants._left_side)) {
case 0:
RDebugUtils.currentLine=3473414;
 //BA.debugLineNum = 3473414;BA.debugLine="startPoint = TopLeft";
_startpoint = __ref._topleft;
RDebugUtils.currentLine=3473415;
 //BA.debugLineNum = 3473415;BA.debugLine="endPoint = TopRight";
_endpoint = __ref._topright;
RDebugUtils.currentLine=3473416;
 //BA.debugLineNum = 3473416;BA.debugLine="direction = SpConstants.HORIZONTAL";
_direction = __ref._spconstants._horizontal;
 break;
case 1:
RDebugUtils.currentLine=3473418;
 //BA.debugLineNum = 3473418;BA.debugLine="startPoint = TopRight";
_startpoint = __ref._topright;
RDebugUtils.currentLine=3473419;
 //BA.debugLineNum = 3473419;BA.debugLine="endPoint = BottomRight";
_endpoint = __ref._bottomright;
RDebugUtils.currentLine=3473420;
 //BA.debugLineNum = 3473420;BA.debugLine="direction = SpConstants.VERTICAL";
_direction = __ref._spconstants._vertical;
 break;
case 2:
RDebugUtils.currentLine=3473422;
 //BA.debugLineNum = 3473422;BA.debugLine="startPoint = BottomLeft";
_startpoint = __ref._bottomleft;
RDebugUtils.currentLine=3473423;
 //BA.debugLineNum = 3473423;BA.debugLine="endPoint = BottomRight";
_endpoint = __ref._bottomright;
RDebugUtils.currentLine=3473424;
 //BA.debugLineNum = 3473424;BA.debugLine="direction = SpConstants.HORIZONTAL";
_direction = __ref._spconstants._horizontal;
 break;
case 3:
RDebugUtils.currentLine=3473426;
 //BA.debugLineNum = 3473426;BA.debugLine="startPoint = TopLeft";
_startpoint = __ref._topleft;
RDebugUtils.currentLine=3473427;
 //BA.debugLineNum = 3473427;BA.debugLine="endPoint = BottomLeft";
_endpoint = __ref._bottomleft;
RDebugUtils.currentLine=3473428;
 //BA.debugLineNum = 3473428;BA.debugLine="direction = SpConstants.VERTICAL";
_direction = __ref._spconstants._vertical;
 break;
}
;
RDebugUtils.currentLine=3473431;
 //BA.debugLineNum = 3473431;BA.debugLine="DrawEdge(cnv,startPoint, endPoint, color, direction)";
__ref._drawedge(null,_cnv,_startpoint,_endpoint,_color,_direction);
RDebugUtils.currentLine=3473432;
 //BA.debugLineNum = 3473432;BA.debugLine="End Sub";
return "";
}
public String  _drawedge(pineysoft.squarepaddocks.gamesquare __ref,anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,pineysoft.squarepaddocks.point _startpoint,pineysoft.squarepaddocks.point _endpoint,int _color,int _direction) throws Exception{
__ref = this;
RDebugUtils.currentModule="gamesquare";
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _line = null;
RDebugUtils.currentLine=3407872;
 //BA.debugLineNum = 3407872;BA.debugLine="Public Sub DrawEdge(cnv As Canvas, startPoint As Point, endPoint As Point, color As Int, direction As Int)";
RDebugUtils.currentLine=3407874;
 //BA.debugLineNum = 3407874;BA.debugLine="Dim line As Rect";
_line = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
RDebugUtils.currentLine=3407875;
 //BA.debugLineNum = 3407875;BA.debugLine="If direction = SpConstants.VERTICAL Then";
if (_direction==__ref._spconstants._vertical) { 
RDebugUtils.currentLine=3407876;
 //BA.debugLineNum = 3407876;BA.debugLine="line.Initialize(startPoint.Pos1-2dip, startPoint.Pos2+4dip, endPoint.Pos1+2dip, endPoint.Pos2-4dip)";
_line.Initialize((int) (_startpoint._pos1-__c.DipToCurrent((int) (2))),(int) (_startpoint._pos2+__c.DipToCurrent((int) (4))),(int) (_endpoint._pos1+__c.DipToCurrent((int) (2))),(int) (_endpoint._pos2-__c.DipToCurrent((int) (4))));
 }else {
RDebugUtils.currentLine=3407878;
 //BA.debugLineNum = 3407878;BA.debugLine="line.Initialize(startPoint.Pos1+4dip, startPoint.Pos2-2dip, endPoint.Pos1-4dip, endPoint.Pos2+2dip)";
_line.Initialize((int) (_startpoint._pos1+__c.DipToCurrent((int) (4))),(int) (_startpoint._pos2-__c.DipToCurrent((int) (2))),(int) (_endpoint._pos1-__c.DipToCurrent((int) (4))),(int) (_endpoint._pos2+__c.DipToCurrent((int) (2))));
 };
RDebugUtils.currentLine=3407881;
 //BA.debugLineNum = 3407881;BA.debugLine="cnv.DrawRect(line,color,True,2dip)";
_cnv.DrawRect((android.graphics.Rect)(_line.getObject()),_color,__c.True,(float) (__c.DipToCurrent((int) (2))));
RDebugUtils.currentLine=3407882;
 //BA.debugLineNum = 3407882;BA.debugLine="End Sub";
return "";
}
}