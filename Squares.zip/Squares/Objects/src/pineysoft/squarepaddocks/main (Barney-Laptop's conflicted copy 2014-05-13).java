package pineysoft.squarepaddocks;

import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (isFirst) {
			processBA = new BA(this.getApplicationContext(), null, null, "pineysoft.squarepaddocks", "pineysoft.squarepaddocks.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		mostCurrent = this;
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
		BA.handler.postDelayed(new WaitForLayout(), 5);

	}
	private static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "pineysoft.squarepaddocks", "pineysoft.squarepaddocks.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "pineysoft.squarepaddocks.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
		return true;
	}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEvent(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
		this.setIntent(intent);
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null) //workaround for emulator bug (Issue 2423)
            return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
			if (mostCurrent == null || mostCurrent != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
		    processBA.raiseEvent(mostCurrent._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}

public anywheresoftware.b4a.keywords.Common __c = null;
public static short _currentplayer = (short)0;
public static int _numberofplayers = 0;
public static int _numberofdroids = 0;
public static anywheresoftware.b4a.objects.collections.List _playercolours = null;
public static boolean _ingame = false;
public static int _gigglesound = 0;
public static anywheresoftware.b4a.audio.SoundPoolWrapper _sounds = null;
public static int _totalscore = 0;
public static pineysoft.squarepaddocks.constants _spconstants = null;
public static String _difficulty = "";
public static anywheresoftware.b4a.phone.Phone.PhoneVibrate _vibrate = null;
public pineysoft.squarepaddocks.gamesquare[][] _gamesquares = null;
public anywheresoftware.b4a.objects.collections.List _gameturns = null;
public static int _gamewidth = 0;
public static int _gameheight = 0;
public static int _columnspacing = 0;
public static int _rowspacing = 0;
public anywheresoftware.b4a.objects.PanelWrapper _panel1 = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _canv = null;
public anywheresoftware.b4a.objects.collections.List _players = null;
public anywheresoftware.b4a.objects.collections.List _playerimages = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer1image = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer2 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer2image = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer3 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer3image = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer4 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayer4image = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncontinue = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spnplayers = null;
public anywheresoftware.b4a.objects.SeekBarWrapper _sbcolumns = null;
public anywheresoftware.b4a.objects.SeekBarWrapper _sbrows = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlstartscreen = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon1 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon2 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon3 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon4 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblcolumns = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblplayers = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblrows = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlbase = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btncurrplayer = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon5 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _icon6 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnldisplay = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlouter = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _imageicon = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblwinner = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper _chksounds = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim1 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim2 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim3 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim4 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim5 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _anim6 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _animshading = null;
public flm.b4a.animationplus.AnimationPlusWrapper _animpanel1 = null;
public flm.b4a.animationplus.AnimationPlusWrapper _animpanel2 = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spndroids = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblscores = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spndifficulty = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlselectionleft = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlselectionright = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlshading = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldifficulty = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldroids = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblsound = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 96;BA.debugLine="SPConstants.Initialize";
_spconstants._initialize(processBA);
 //BA.debugLineNum = 97;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 //BA.debugLineNum = 98;BA.debugLine="Activity.LoadLayout(\"StartScreen\")";
mostCurrent._activity.LoadLayout("StartScreen",mostCurrent.activityBA);
 //BA.debugLineNum = 99;BA.debugLine="ShowSplashScreen";
_showsplashscreen();
 //BA.debugLineNum = 100;BA.debugLine="CreateColours";
_createcolours();
 //BA.debugLineNum = 101;BA.debugLine="LoadImages";
_loadimages();
 //BA.debugLineNum = 102;BA.debugLine="LoadSpinners";
_loadspinners();
 //BA.debugLineNum = 103;BA.debugLine="InitialiseSounds";
_initialisesounds();
 }else {
 //BA.debugLineNum = 105;BA.debugLine="Activity.LoadLayout(\"StartScreen\")";
mostCurrent._activity.LoadLayout("StartScreen",mostCurrent.activityBA);
 //BA.debugLineNum = 106;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
 //BA.debugLineNum = 107;BA.debugLine="ShowCharacters";
_showcharacters();
 //BA.debugLineNum = 108;BA.debugLine="CreateColours";
_createcolours();
 //BA.debugLineNum = 109;BA.debugLine="LoadImages";
_loadimages();
 //BA.debugLineNum = 110;BA.debugLine="LoadSpinners";
_loadspinners();
 //BA.debugLineNum = 111;BA.debugLine="UpdateLabels";
_updatelabels();
 };
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
public static boolean  _activity_keypress(int _keycode) throws Exception{
int _answ = 0;
 //BA.debugLineNum = 989;BA.debugLine="Sub Activity_KeyPress (KeyCode As Int) As Boolean 'Return True to consume the event";
 //BA.debugLineNum = 990;BA.debugLine="If KeyCode = KeyCodes.KEYCODE_BACK Then";
if (_keycode==anywheresoftware.b4a.keywords.Common.KeyCodes.KEYCODE_BACK) { 
 //BA.debugLineNum = 991;BA.debugLine="If inGame Then";
if (_ingame) { 
 //BA.debugLineNum = 992;BA.debugLine="If pnlOuter.Left = 0dip Then";
if (mostCurrent._pnlouter.getLeft()==anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0))) { 
 //BA.debugLineNum = 993;BA.debugLine="pnlOuter.Left = -100%x";
mostCurrent._pnlouter.setLeft((int) (-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)));
 //BA.debugLineNum = 994;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
 //BA.debugLineNum = 995;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 997;BA.debugLine="Dim Answ As Int";
_answ = 0;
 //BA.debugLineNum = 998;BA.debugLine="Answ = Msgbox2(\"Do you want to quit this game, you will lose all progress.\", _ 			      \"W A R N I N G\", \"Yes\", \"\", \"No\", Null)";
_answ = anywheresoftware.b4a.keywords.Common.Msgbox2("Do you want to quit this game, you will lose all progress.","W A R N I N G","Yes","","No",(android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null),mostCurrent.activityBA);
 //BA.debugLineNum = 1000;BA.debugLine="If Answ = DialogResponse.NEGATIVE Then";
if (_answ==anywheresoftware.b4a.keywords.Common.DialogResponse.NEGATIVE) { 
 //BA.debugLineNum = 1001;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 1003;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
 //BA.debugLineNum = 1004;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 };
 };
 };
 };
 //BA.debugLineNum = 1010;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 1011;BA.debugLine="End Sub";
return false;
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 375;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 377;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 371;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 373;BA.debugLine="End Sub";
return "";
}
public static String  _animatecharacters() throws Exception{
 //BA.debugLineNum = 124;BA.debugLine="Sub AnimateCharacters";
 //BA.debugLineNum = 126;BA.debugLine="anim1.InitializeTranslate(\"\", -120dip,100dip,350dip,100dip)";
mostCurrent._anim1.InitializeTranslate(mostCurrent.activityBA,"",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 127;BA.debugLine="anim1.Duration = 1000";
mostCurrent._anim1.setDuration((long) (1000));
 //BA.debugLineNum = 128;BA.debugLine="anim1.StartOffset = 0";
mostCurrent._anim1.setStartOffset((long) (0));
 //BA.debugLineNum = 129;BA.debugLine="anim1.PersistAfter = True";
mostCurrent._anim1.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 130;BA.debugLine="anim1.Start(icon1)";
mostCurrent._anim1.Start((android.view.View)(mostCurrent._icon1.getObject()));
 //BA.debugLineNum = 131;BA.debugLine="anim2.InitializeTranslate(\"\", 100%x + 120dip,200dip,150dip,200dip)";
mostCurrent._anim2.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 132;BA.debugLine="anim2.Duration = 1000";
mostCurrent._anim2.setDuration((long) (1000));
 //BA.debugLineNum = 133;BA.debugLine="anim2.StartOffset = 250";
mostCurrent._anim2.setStartOffset((long) (250));
 //BA.debugLineNum = 134;BA.debugLine="anim2.PersistAfter = True";
mostCurrent._anim2.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 135;BA.debugLine="anim2.Start(icon2)";
mostCurrent._anim2.Start((android.view.View)(mostCurrent._icon2.getObject()));
 //BA.debugLineNum = 136;BA.debugLine="anim3.InitializeTranslate(\"\", -120dip,100dip,250dip,100dip)";
mostCurrent._anim3.InitializeTranslate(mostCurrent.activityBA,"",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 137;BA.debugLine="anim3.Duration = 1000";
mostCurrent._anim3.setDuration((long) (1000));
 //BA.debugLineNum = 138;BA.debugLine="anim3.StartOffset = 500";
mostCurrent._anim3.setStartOffset((long) (500));
 //BA.debugLineNum = 139;BA.debugLine="anim3.PersistAfter = True";
mostCurrent._anim3.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 140;BA.debugLine="anim3.Start(icon3)";
mostCurrent._anim3.Start((android.view.View)(mostCurrent._icon3.getObject()));
 //BA.debugLineNum = 141;BA.debugLine="anim4.InitializeTranslate(\"\", 100%x + 120dip,200dip,250dip,200dip)";
mostCurrent._anim4.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 142;BA.debugLine="anim4.Duration = 1000";
mostCurrent._anim4.setDuration((long) (1000));
 //BA.debugLineNum = 143;BA.debugLine="anim4.StartOffset = 750";
mostCurrent._anim4.setStartOffset((long) (750));
 //BA.debugLineNum = 144;BA.debugLine="anim4.PersistAfter	 = True";
mostCurrent._anim4.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 145;BA.debugLine="anim4.Start(icon4)";
mostCurrent._anim4.Start((android.view.View)(mostCurrent._icon4.getObject()));
 //BA.debugLineNum = 146;BA.debugLine="anim5.InitializeTranslate(\"\", -120dip,100dip,150dip,100dip)";
mostCurrent._anim5.InitializeTranslate(mostCurrent.activityBA,"",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 147;BA.debugLine="anim5.Duration = 1000";
mostCurrent._anim5.setDuration((long) (1000));
 //BA.debugLineNum = 148;BA.debugLine="anim5.StartOffset = 500";
mostCurrent._anim5.setStartOffset((long) (500));
 //BA.debugLineNum = 149;BA.debugLine="anim5.PersistAfter = True";
mostCurrent._anim5.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 150;BA.debugLine="anim5.Start(icon5)";
mostCurrent._anim5.Start((android.view.View)(mostCurrent._icon5.getObject()));
 //BA.debugLineNum = 151;BA.debugLine="anim6.InitializeTranslate(\"LastIcon\", 100%x + 120dip,200dip,350dip,200dip)";
mostCurrent._anim6.InitializeTranslate(mostCurrent.activityBA,"LastIcon",(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 152;BA.debugLine="anim6.Duration = 1000";
mostCurrent._anim6.setDuration((long) (1000));
 //BA.debugLineNum = 153;BA.debugLine="anim6.StartOffset = 750";
mostCurrent._anim6.setStartOffset((long) (750));
 //BA.debugLineNum = 154;BA.debugLine="anim6.PersistAfter = True";
mostCurrent._anim6.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 155;BA.debugLine="anim6.Start(icon6)";
mostCurrent._anim6.Start((android.view.View)(mostCurrent._icon6.getObject()));
 //BA.debugLineNum = 157;BA.debugLine="End Sub";
return "";
}
public static String  _animatepanelleft() throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Sub AnimatePanelLeft";
 //BA.debugLineNum = 177;BA.debugLine="animPanel1.InitializeTranslate(\"LeftPanel\",-120dip,pnlSelectionLeft.Top,pnlSelectionLeft.width,pnlSelectionLeft.Top)";
mostCurrent._animpanel1.InitializeTranslate(mostCurrent.activityBA,"LeftPanel",(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (mostCurrent._pnlselectionleft.getTop()),(float) (mostCurrent._pnlselectionleft.getWidth()),(float) (mostCurrent._pnlselectionleft.getTop()));
 //BA.debugLineNum = 178;BA.debugLine="animPanel1.PersistAfter = True";
mostCurrent._animpanel1.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 179;BA.debugLine="animPanel1.Duration = 500";
mostCurrent._animpanel1.setDuration((long) (500));
 //BA.debugLineNum = 180;BA.debugLine="animPanel1.Start(pnlSelectionLeft)";
mostCurrent._animpanel1.Start((android.view.View)(mostCurrent._pnlselectionleft.getObject()));
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
return "";
}
public static String  _animatepanelright() throws Exception{
 //BA.debugLineNum = 187;BA.debugLine="Sub AnimatePanelRight";
 //BA.debugLineNum = 188;BA.debugLine="Log(100%x & \" \" & pnlSelectionRight.Width & \" \" & pnlSelectionRight.Top)";
anywheresoftware.b4a.keywords.Common.Log(BA.NumberToString(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA))+" "+BA.NumberToString(mostCurrent._pnlselectionright.getWidth())+" "+BA.NumberToString(mostCurrent._pnlselectionright.getTop()));
 //BA.debugLineNum = 189;BA.debugLine="animPanel2.InitializeTranslate(\"RightPanel\",200dip,pnlSelectionRight.Top,-180dip,pnlSelectionRight.Top)";
mostCurrent._animpanel2.InitializeTranslate(mostCurrent.activityBA,"RightPanel",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (mostCurrent._pnlselectionright.getTop()),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (180))),(float) (mostCurrent._pnlselectionright.getTop()));
 //BA.debugLineNum = 190;BA.debugLine="animPanel2.PersistAfter = True";
mostCurrent._animpanel2.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 191;BA.debugLine="animPanel2.Duration = 500";
mostCurrent._animpanel2.setDuration((long) (500));
 //BA.debugLineNum = 192;BA.debugLine="animPanel2.Start(pnlSelectionRight)";
mostCurrent._animpanel2.Start((android.view.View)(mostCurrent._pnlselectionright.getObject()));
 //BA.debugLineNum = 193;BA.debugLine="End Sub";
return "";
}
public static String  _animateshading() throws Exception{
 //BA.debugLineNum = 162;BA.debugLine="Sub AnimateShading";
 //BA.debugLineNum = 163;BA.debugLine="Log(\"StartShading Anim\")";
anywheresoftware.b4a.keywords.Common.Log("StartShading Anim");
 //BA.debugLineNum = 164;BA.debugLine="animShading.InitializeScaleCenter(\"Shading\", 0.1,0.1,1,1, pnlShading)";
mostCurrent._animshading.InitializeScaleCenter(mostCurrent.activityBA,"Shading",(float) (0.1),(float) (0.1),(float) (1),(float) (1),(android.view.View)(mostCurrent._pnlshading.getObject()));
 //BA.debugLineNum = 165;BA.debugLine="animShading.Duration = 750";
mostCurrent._animshading.setDuration((long) (750));
 //BA.debugLineNum = 166;BA.debugLine="animShading.PersistAfter = True";
mostCurrent._animshading.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 167;BA.debugLine="pnlShading.Visible = True";
mostCurrent._pnlshading.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 168;BA.debugLine="animShading.Start(pnlShading)";
mostCurrent._animshading.Start((android.view.View)(mostCurrent._pnlshading.getObject()));
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public static String  _btncontinue_click() throws Exception{
 //BA.debugLineNum = 972;BA.debugLine="Sub btnContinue_Click";
 //BA.debugLineNum = 973;BA.debugLine="vibrate.Vibrate(25)";
_vibrate.Vibrate(processBA,(long) (25));
 //BA.debugLineNum = 974;BA.debugLine="pnlStartScreen.Left = 200%x";
mostCurrent._pnlstartscreen.setLeft(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (200),mostCurrent.activityBA));
 //BA.debugLineNum = 975;BA.debugLine="Activity.LoadLayout(\"layout1\")";
mostCurrent._activity.LoadLayout("layout1",mostCurrent.activityBA);
 //BA.debugLineNum = 976;BA.debugLine="Activity.LoadLayout(\"winnerScreen\")";
mostCurrent._activity.LoadLayout("winnerScreen",mostCurrent.activityBA);
 //BA.debugLineNum = 977;BA.debugLine="pnlOuter.Left = -100%x";
mostCurrent._pnlouter.setLeft((int) (-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)));
 //BA.debugLineNum = 978;BA.debugLine="inGame = True";
_ingame = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 979;BA.debugLine="InitGamePlay";
_initgameplay();
 //BA.debugLineNum = 980;BA.debugLine="End Sub";
return "";
}
public static String  _btncurrplayer_click() throws Exception{
pineysoft.squarepaddocks.turn _lastturn = null;
pineysoft.squarepaddocks.player _currplayer = null;
 //BA.debugLineNum = 1035;BA.debugLine="Sub btnCurrPlayer_Click";
 //BA.debugLineNum = 1036;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
 //BA.debugLineNum = 1038;BA.debugLine="Dim lastTurn As Turn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
 //BA.debugLineNum = 1039;BA.debugLine="Dim currPlayer As Player  = players.Get(lastTurn.PlayerNum)";
_currplayer = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get(_lastturn._playernum));
 //BA.debugLineNum = 1041;BA.debugLine="RemoveTurn(lastTurn, currPlayer)";
_removeturn(_lastturn,_currplayer);
 //BA.debugLineNum = 1043;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
 //BA.debugLineNum = 1044;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
 //BA.debugLineNum = 1045;BA.debugLine="currentPlayer = lastTurn.PlayerNum";
_currentplayer = (short) (_lastturn._playernum);
 }else {
 //BA.debugLineNum = 1047;BA.debugLine="currentPlayer = 0";
_currentplayer = (short) (0);
 };
 //BA.debugLineNum = 1050;BA.debugLine="btnCurrPlayer.SetBackgroundImage(playerImages.Get(currentPlayer))";
mostCurrent._btncurrplayer.SetBackgroundImage((android.graphics.Bitmap)(mostCurrent._playerimages.Get((int) (_currentplayer))));
 //BA.debugLineNum = 1051;BA.debugLine="panel1.Invalidate";
mostCurrent._panel1.Invalidate();
 }else {
 //BA.debugLineNum = 1053;BA.debugLine="ToastMessageShow(\"No More Undo's left\",False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow("No More Undo's left",anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 1056;BA.debugLine="End Sub";
return "";
}
public static String  _btnok_click() throws Exception{
 //BA.debugLineNum = 1057;BA.debugLine="Sub btnOk_Click";
 //BA.debugLineNum = 1058;BA.debugLine="pnlOuter.Left = -100%x";
mostCurrent._pnlouter.setLeft((int) (-anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)));
 //BA.debugLineNum = 1059;BA.debugLine="DisplayFrontScreen";
_displayfrontscreen();
 //BA.debugLineNum = 1060;BA.debugLine="End Sub";
return "";
}
public static String  _calculatemove(int _xcoord,int _ycoord) throws Exception{
pineysoft.squarepaddocks.point _touchpoint = null;
int _chosenside = 0;
pineysoft.squarepaddocks.gamesquare _currentsquare = null;
pineysoft.squarepaddocks.player _currplayer = null;
int _numberclosed = 0;
 //BA.debugLineNum = 426;BA.debugLine="Sub CalculateMove(xCoord As Int, yCoord As Int)";
 //BA.debugLineNum = 429;BA.debugLine="Dim touchPoint As Point";
_touchpoint = new pineysoft.squarepaddocks.point();
 //BA.debugLineNum = 430;BA.debugLine="Dim chosenSide As Int";
_chosenside = 0;
 //BA.debugLineNum = 431;BA.debugLine="touchPoint.Initialize(xCoord, yCoord)";
_touchpoint._initialize(processBA,_xcoord,_ycoord);
 //BA.debugLineNum = 432;BA.debugLine="Dim currentSquare As GameSquare = FindSelectedSquare(xCoord, yCoord)";
_currentsquare = _findselectedsquare(_xcoord,_ycoord);
 //BA.debugLineNum = 433;BA.debugLine="Dim currPlayer As Player = players.Get(currentPlayer)";
_currplayer = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get((int) (_currentplayer)));
 //BA.debugLineNum = 435;BA.debugLine="chosenSide = currentSquare.CalculateClosestEdge(touchPoint)";
_chosenside = _currentsquare._calculateclosestedge(_touchpoint);
 //BA.debugLineNum = 436;BA.debugLine="Log(chosenSide)";
anywheresoftware.b4a.keywords.Common.Log(BA.NumberToString(_chosenside));
 //BA.debugLineNum = 439;BA.debugLine="If currentSquare.IsSideTaken(chosenSide) Then Return";
if (_currentsquare._issidetaken(_chosenside)) { 
if (true) return "";};
 //BA.debugLineNum = 441;BA.debugLine="UpdateTurn(canv, currentSquare, chosenSide)";
_updateturn(mostCurrent._canv,_currentsquare,_chosenside);
 //BA.debugLineNum = 444;BA.debugLine="currentSquare.TakeSide(canv,chosenSide)";
_currentsquare._takeside(mostCurrent._canv,_chosenside);
 //BA.debugLineNum = 447;BA.debugLine="MarkOtherSide2(currentSquare, chosenSide)";
_markotherside2(_currentsquare,_chosenside);
 //BA.debugLineNum = 450;BA.debugLine="Dim numberClosed As Int = CloseCompletedSquares(currPlayer)";
_numberclosed = _closecompletedsquares(_currplayer);
 //BA.debugLineNum = 452;BA.debugLine="If numberClosed = 0 Then";
if (_numberclosed==0) { 
 //BA.debugLineNum = 453;BA.debugLine="UpdatePlayerNumber";
_updateplayernumber();
 //BA.debugLineNum = 454;BA.debugLine="currPlayer = players.Get(currentPlayer)";
_currplayer = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get((int) (_currentplayer)));
 //BA.debugLineNum = 455;BA.debugLine="btnCurrPlayer.SetBackgroundImage(currPlayer.PlayerImage)";
mostCurrent._btncurrplayer.SetBackgroundImage((android.graphics.Bitmap)(_currplayer._playerimage.getObject()));
 //BA.debugLineNum = 456;BA.debugLine="Do While currPlayer.PlayerType = SPConstants.PLAYER_TYPE_DROID";
while (_currplayer._playertype==_spconstants._player_type_droid) {
 //BA.debugLineNum = 457;BA.debugLine="btnCurrPlayer.Text = \"D\"";
mostCurrent._btncurrplayer.setText((Object)("D"));
 //BA.debugLineNum = 458;BA.debugLine="MakeDroidMove(currPlayer)";
_makedroidmove(_currplayer);
 //BA.debugLineNum = 459;BA.debugLine="UpdatePlayerNumber";
_updateplayernumber();
 //BA.debugLineNum = 460;BA.debugLine="currPlayer = players.Get(currentPlayer)";
_currplayer = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get((int) (_currentplayer)));
 }
;
 //BA.debugLineNum = 462;BA.debugLine="btnCurrPlayer.Text = \"\"";
mostCurrent._btncurrplayer.setText((Object)(""));
 //BA.debugLineNum = 463;BA.debugLine="btnCurrPlayer.SetBackgroundImage(currPlayer.PlayerImage)";
mostCurrent._btncurrplayer.SetBackgroundImage((android.graphics.Bitmap)(_currplayer._playerimage.getObject()));
 }else {
 //BA.debugLineNum = 465;BA.debugLine="currPlayer.Score = currPlayer.Score + numberClosed";
_currplayer._score = (int) (_currplayer._score+_numberclosed);
 //BA.debugLineNum = 466;BA.debugLine="totalScore = totalScore + numberClosed";
_totalscore = (int) (_totalscore+_numberclosed);
 //BA.debugLineNum = 467;BA.debugLine="If chkSounds.Checked Then sounds.Play(giggleSound,1,1,1,1,0)";
if (mostCurrent._chksounds.getChecked()) { 
_sounds.Play(_gigglesound,(float) (1),(float) (1),(int) (1),(int) (1),(float) (0));};
 //BA.debugLineNum = 468;BA.debugLine="UpdateScore(currPlayer)";
_updatescore(_currplayer);
 //BA.debugLineNum = 469;BA.debugLine="CheckAndDisplayWinnerScreen";
_checkanddisplaywinnerscreen();
 };
 //BA.debugLineNum = 472;BA.debugLine="End Sub";
return "";
}
public static boolean  _checkanddisplaywinnerscreen() throws Exception{
int _iloop = 0;
String _scoretext = "";
pineysoft.squarepaddocks.player _temp = null;
int _winnernum = 0;
int _bestscore = 0;
pineysoft.squarepaddocks.player _p = null;
 //BA.debugLineNum = 557;BA.debugLine="Sub CheckAndDisplayWinnerScreen() As Boolean";
 //BA.debugLineNum = 558;BA.debugLine="Dim iLoop As Int";
_iloop = 0;
 //BA.debugLineNum = 559;BA.debugLine="Dim scoreText As String";
_scoretext = "";
 //BA.debugLineNum = 560;BA.debugLine="Dim temp As Player";
_temp = new pineysoft.squarepaddocks.player();
 //BA.debugLineNum = 561;BA.debugLine="Dim winnerNum As Int";
_winnernum = 0;
 //BA.debugLineNum = 562;BA.debugLine="Dim bestScore As Int = 0";
_bestscore = (int) (0);
 //BA.debugLineNum = 563;BA.debugLine="For iLoop = 0 To players.Size - 1";
{
final int step468 = 1;
final int limit468 = (int) (mostCurrent._players.getSize()-1);
for (_iloop = (int) (0); (step468 > 0 && _iloop <= limit468) || (step468 < 0 && _iloop >= limit468); _iloop = ((int)(0 + _iloop + step468))) {
 //BA.debugLineNum = 564;BA.debugLine="temp = players.Get(iLoop)";
_temp = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get(_iloop));
 //BA.debugLineNum = 565;BA.debugLine="If temp.Score > bestScore Then";
if (_temp._score>_bestscore) { 
 //BA.debugLineNum = 566;BA.debugLine="winnerNum = iLoop";
_winnernum = _iloop;
 //BA.debugLineNum = 567;BA.debugLine="bestScore = temp.Score";
_bestscore = _temp._score;
 }else if(_temp._score==_bestscore) { 
 //BA.debugLineNum = 569;BA.debugLine="winnerNum = -1";
_winnernum = (int) (-1);
 };
 }
};
 //BA.debugLineNum = 572;BA.debugLine="If totalScore = gameWidth  * gameHeight Then";
if (_totalscore==_gamewidth*_gameheight) { 
 //BA.debugLineNum = 573;BA.debugLine="If pnlOuter.IsInitialized Then";
if (mostCurrent._pnlouter.IsInitialized()) { 
 //BA.debugLineNum = 574;BA.debugLine="If winnerNum <> -1 Then";
if (_winnernum!=-1) { 
 //BA.debugLineNum = 575;BA.debugLine="lblWinner.Text = \"Player \" & (winnerNum + 1) & \" is the winner!!!\"";
mostCurrent._lblwinner.setText((Object)("Player "+BA.NumberToString((_winnernum+1))+" is the winner!!!"));
 //BA.debugLineNum = 576;BA.debugLine="imageIcon.Bitmap = playerImages.Get(winnerNum)";
mostCurrent._imageicon.setBitmap((android.graphics.Bitmap)(mostCurrent._playerimages.Get(_winnernum)));
 //BA.debugLineNum = 577;BA.debugLine="pnlOuter.Left = 0dip";
mostCurrent._pnlouter.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 }else {
 //BA.debugLineNum = 579;BA.debugLine="lblWinner.Text = \"IT'S A TIE\"";
mostCurrent._lblwinner.setText((Object)("IT'S A TIE"));
 };
 };
 //BA.debugLineNum = 582;BA.debugLine="For iLoop = 1 To players.Size";
{
final int step487 = 1;
final int limit487 = mostCurrent._players.getSize();
for (_iloop = (int) (1); (step487 > 0 && _iloop <= limit487) || (step487 < 0 && _iloop >= limit487); _iloop = ((int)(0 + _iloop + step487))) {
 //BA.debugLineNum = 583;BA.debugLine="Dim p As Player = players.Get(iLoop - 1)";
_p = (pineysoft.squarepaddocks.player)(mostCurrent._players.Get((int) (_iloop-1)));
 //BA.debugLineNum = 584;BA.debugLine="scoreText = scoreText & \"Player \" & iLoop & \": \" & p.Score & \" \"";
_scoretext = _scoretext+"Player "+BA.NumberToString(_iloop)+": "+BA.NumberToString(_p._score)+" ";
 }
};
 //BA.debugLineNum = 586;BA.debugLine="lblScores.Text = scoreText";
mostCurrent._lblscores.setText((Object)(_scoretext));
 //BA.debugLineNum = 587;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 589;BA.debugLine="Return False";
if (true) return anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 591;BA.debugLine="End Sub";
return false;
}
public static int  _closecompletedsquares(pineysoft.squarepaddocks.player _currplayer) throws Exception{
anywheresoftware.b4a.objects.collections.List _allclosed = null;
int _closed = 0;
pineysoft.squarepaddocks.gamesquare _item = null;
 //BA.debugLineNum = 833;BA.debugLine="Sub CloseCompletedSquares(currPlayer As Player) As Int";
 //BA.debugLineNum = 834;BA.debugLine="Dim allClosed As List = FindAllForSides(4)";
_allclosed = new anywheresoftware.b4a.objects.collections.List();
_allclosed = _findallforsides((int) (4));
 //BA.debugLineNum = 835;BA.debugLine="Dim closed As Int";
_closed = 0;
 //BA.debugLineNum = 837;BA.debugLine="For Each item As GameSquare In allClosed";
final anywheresoftware.b4a.BA.IterableList group695 = _allclosed;
final int groupLen695 = group695.getSize();
for (int index695 = 0;index695 < groupLen695 ;index695++){
_item = (pineysoft.squarepaddocks.gamesquare)(group695.Get(index695));
 //BA.debugLineNum = 838;BA.debugLine="If item.Occupied = False Then";
if (_item._occupied==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 839;BA.debugLine="FillTheSquare(item, currPlayer)";
_fillthesquare(_item,_currplayer);
 //BA.debugLineNum = 840;BA.debugLine="closed = closed + 1";
_closed = (int) (_closed+1);
 //BA.debugLineNum = 841;BA.debugLine="item.Occupied = True";
_item._occupied = anywheresoftware.b4a.keywords.Common.True;
 };
 }
;
 //BA.debugLineNum = 845;BA.debugLine="Return closed";
if (true) return _closed;
 //BA.debugLineNum = 846;BA.debugLine="End Sub";
return 0;
}
public static String  _createboard() throws Exception{
int _colloop = 0;
int _rowloop = 0;
int _x = 0;
int _y = 0;
pineysoft.squarepaddocks.gamesquare _square = null;
 //BA.debugLineNum = 388;BA.debugLine="Sub CreateBoard";
 //BA.debugLineNum = 389;BA.debugLine="Dim colLoop As Int";
_colloop = 0;
 //BA.debugLineNum = 390;BA.debugLine="Dim rowLoop As Int";
_rowloop = 0;
 //BA.debugLineNum = 391;BA.debugLine="Dim x As Int = columnSpacing / 2";
_x = (int) (_columnspacing/(double)2);
 //BA.debugLineNum = 392;BA.debugLine="Dim y As Int = rowSpacing / 2";
_y = (int) (_rowspacing/(double)2);
 //BA.debugLineNum = 393;BA.debugLine="Dim gameSquares(gameHeight,gameWidth) As GameSquare";
mostCurrent._gamesquares = new pineysoft.squarepaddocks.gamesquare[_gameheight][];
{
int d0 = mostCurrent._gamesquares.length;
int d1 = _gamewidth;
for (int i0 = 0;i0 < d0;i0++) {
mostCurrent._gamesquares[i0] = new pineysoft.squarepaddocks.gamesquare[d1];
for (int i1 = 0;i1 < d1;i1++) {
mostCurrent._gamesquares[i0][i1] = new pineysoft.squarepaddocks.gamesquare();
}
}
}
;
 //BA.debugLineNum = 395;BA.debugLine="For rowLoop = 0 To gameHeight - 1";
{
final int step333 = 1;
final int limit333 = (int) (_gameheight-1);
for (_rowloop = (int) (0); (step333 > 0 && _rowloop <= limit333) || (step333 < 0 && _rowloop >= limit333); _rowloop = ((int)(0 + _rowloop + step333))) {
 //BA.debugLineNum = 396;BA.debugLine="For colLoop = 0 To gameWidth - 1";
{
final int step334 = 1;
final int limit334 = (int) (_gamewidth-1);
for (_colloop = (int) (0); (step334 > 0 && _colloop <= limit334) || (step334 < 0 && _colloop >= limit334); _colloop = ((int)(0 + _colloop + step334))) {
 //BA.debugLineNum = 397;BA.debugLine="Dim square As GameSquare";
_square = new pineysoft.squarepaddocks.gamesquare();
 //BA.debugLineNum = 398;BA.debugLine="square.Initialize(x,y,columnSpacing,rowSpacing,rowLoop,colLoop)";
_square._initialize(mostCurrent.activityBA,_x,_y,_columnspacing,_rowspacing,_rowloop,_colloop);
 //BA.debugLineNum = 399;BA.debugLine="gameSquares(rowLoop, colLoop) = square";
mostCurrent._gamesquares[_rowloop][_colloop] = _square;
 //BA.debugLineNum = 400;BA.debugLine="x = x + columnSpacing";
_x = (int) (_x+_columnspacing);
 }
};
 //BA.debugLineNum = 402;BA.debugLine="x = columnSpacing / 2";
_x = (int) (_columnspacing/(double)2);
 //BA.debugLineNum = 403;BA.debugLine="y = y + rowSpacing";
_y = (int) (_y+_rowspacing);
 }
};
 //BA.debugLineNum = 405;BA.debugLine="End Sub";
return "";
}
public static String  _createcolours() throws Exception{
 //BA.debugLineNum = 262;BA.debugLine="Sub CreateColours()";
 //BA.debugLineNum = 263;BA.debugLine="playerColours.Initialize";
_playercolours.Initialize();
 //BA.debugLineNum = 264;BA.debugLine="playerColours.Add(Colors.Yellow)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Yellow));
 //BA.debugLineNum = 265;BA.debugLine="playerColours.Add(Colors.Blue)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Blue));
 //BA.debugLineNum = 266;BA.debugLine="playerColours.Add(Colors.Green)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Green));
 //BA.debugLineNum = 267;BA.debugLine="playerColours.Add(Colors.Red)";
_playercolours.Add((Object)(anywheresoftware.b4a.keywords.Common.Colors.Red));
 //BA.debugLineNum = 268;BA.debugLine="End Sub";
return "";
}
public static String  _createplayers() throws Exception{
int _iloop = 0;
pineysoft.squarepaddocks.player _playerval = null;
anywheresoftware.b4a.objects.ConcreteViewWrapper _v = null;
anywheresoftware.b4a.objects.LabelWrapper _lbl = null;
anywheresoftware.b4a.objects.ConcreteViewWrapper _vimage = null;
anywheresoftware.b4a.objects.LabelWrapper _lblimage = null;
 //BA.debugLineNum = 305;BA.debugLine="Sub CreatePlayers";
 //BA.debugLineNum = 306;BA.debugLine="Dim iLoop As Int";
_iloop = 0;
 //BA.debugLineNum = 307;BA.debugLine="players.Initialize";
mostCurrent._players.Initialize();
 //BA.debugLineNum = 309;BA.debugLine="For iLoop = 1 To numberOfPlayers";
{
final int step257 = 1;
final int limit257 = _numberofplayers;
for (_iloop = (int) (1); (step257 > 0 && _iloop <= limit257) || (step257 < 0 && _iloop >= limit257); _iloop = ((int)(0 + _iloop + step257))) {
 //BA.debugLineNum = 310;BA.debugLine="Dim playerVal As Player";
_playerval = new pineysoft.squarepaddocks.player();
 //BA.debugLineNum = 311;BA.debugLine="playerVal.Initialize(\"Player \" & iLoop, playerColours.Get(iLoop - 1))";
_playerval._initialize(processBA,"Player "+BA.NumberToString(_iloop),(int)(BA.ObjectToNumber(_playercolours.Get((int) (_iloop-1)))));
 //BA.debugLineNum = 312;BA.debugLine="If iLoop <= numberOfPlayers - numberOfDroids Then";
if (_iloop<=_numberofplayers-_numberofdroids) { 
 //BA.debugLineNum = 313;BA.debugLine="playerVal.PlayerType = SPConstants.PLAYER_TYPE_HUMAN";
_playerval._playertype = _spconstants._player_type_human;
 }else {
 //BA.debugLineNum = 315;BA.debugLine="playerVal.PlayerType = SPConstants.PLAYER_TYPE_DROID";
_playerval._playertype = _spconstants._player_type_droid;
 };
 //BA.debugLineNum = 317;BA.debugLine="Dim v As View = GetViewByTag1(pnlBase, \"P\" & iLoop)";
_v = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
_v = _getviewbytag1((anywheresoftware.b4a.objects.ActivityWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ActivityWrapper(), (anywheresoftware.b4a.BALayout)(mostCurrent._pnlbase.getObject())),"P"+BA.NumberToString(_iloop));
 //BA.debugLineNum = 318;BA.debugLine="If v Is Label Then";
if (_v.getObjectOrNull() instanceof android.widget.TextView) { 
 //BA.debugLineNum = 319;BA.debugLine="Dim lbl As Label = v";
_lbl = new anywheresoftware.b4a.objects.LabelWrapper();
_lbl.setObject((android.widget.TextView)(_v.getObject()));
 //BA.debugLineNum = 320;BA.debugLine="If playerVal.PlayerType = SPConstants.PLAYER_TYPE_HUMAN Then";
if (_playerval._playertype==_spconstants._player_type_human) { 
 //BA.debugLineNum = 321;BA.debugLine="lbl.Text = \"Player \" & iLoop";
_lbl.setText((Object)("Player "+BA.NumberToString(_iloop)));
 }else {
 //BA.debugLineNum = 323;BA.debugLine="lbl.Text = \"Droid \" & iLoop";
_lbl.setText((Object)("Droid "+BA.NumberToString(_iloop)));
 };
 //BA.debugLineNum = 325;BA.debugLine="If iLoop <= playerImages.Size Then";
if (_iloop<=mostCurrent._playerimages.getSize()) { 
 //BA.debugLineNum = 326;BA.debugLine="Dim vImage As View = GetViewByTag1(pnlBase, \"I\" & iLoop)";
_vimage = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
_vimage = _getviewbytag1((anywheresoftware.b4a.objects.ActivityWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ActivityWrapper(), (anywheresoftware.b4a.BALayout)(mostCurrent._pnlbase.getObject())),"I"+BA.NumberToString(_iloop));
 //BA.debugLineNum = 327;BA.debugLine="If vImage Is Label Then";
if (_vimage.getObjectOrNull() instanceof android.widget.TextView) { 
 //BA.debugLineNum = 328;BA.debugLine="Dim lblImage As Label = vImage";
_lblimage = new anywheresoftware.b4a.objects.LabelWrapper();
_lblimage.setObject((android.widget.TextView)(_vimage.getObject()));
 //BA.debugLineNum = 329;BA.debugLine="playerVal.PlayerImage = playerImages.Get(iLoop - 1)";
_playerval._playerimage.setObject((android.graphics.Bitmap)(mostCurrent._playerimages.Get((int) (_iloop-1))));
 //BA.debugLineNum = 330;BA.debugLine="lblImage.SetBackgroundImage(playerVal.PlayerImage)";
_lblimage.SetBackgroundImage((android.graphics.Bitmap)(_playerval._playerimage.getObject()));
 //BA.debugLineNum = 331;BA.debugLine="If playerVal.PlayerType = SPConstants.PLAYER_TYPE_DROID Then";
if (_playerval._playertype==_spconstants._player_type_droid) { 
 //BA.debugLineNum = 332;BA.debugLine="lblImage.Text = \"D\"";
_lblimage.setText((Object)("D"));
 };
 };
 };
 };
 //BA.debugLineNum = 337;BA.debugLine="players.Add(playerVal)";
mostCurrent._players.Add((Object)(_playerval));
 }
};
 //BA.debugLineNum = 339;BA.debugLine="currentPlayer = 0";
_currentplayer = (short) (0);
 //BA.debugLineNum = 340;BA.debugLine="btnCurrPlayer.SetBackgroundImage(playerImages.Get(0))";
mostCurrent._btncurrplayer.SetBackgroundImage((android.graphics.Bitmap)(mostCurrent._playerimages.Get((int) (0))));
 //BA.debugLineNum = 342;BA.debugLine="End Sub";
return "";
}
public static String  _displayfrontscreen() throws Exception{
 //BA.debugLineNum = 945;BA.debugLine="Sub DisplayFrontScreen";
 //BA.debugLineNum = 946;BA.debugLine="If pnlBase.IsInitialized Then";
if (mostCurrent._pnlbase.IsInitialized()) { 
 //BA.debugLineNum = 947;BA.debugLine="pnlBase.Left = 200%x";
mostCurrent._pnlbase.setLeft(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (200),mostCurrent.activityBA));
 };
 //BA.debugLineNum = 949;BA.debugLine="pnlStartScreen.Left = 0dip";
mostCurrent._pnlstartscreen.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 950;BA.debugLine="inGame = False";
_ingame = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 951;BA.debugLine="ShowCharacters";
_showcharacters();
 //BA.debugLineNum = 952;BA.debugLine="End Sub";
return "";
}
public static String  _drawboard() throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _square = null;
int _rowloop = 0;
int _colloop = 0;
pineysoft.squarepaddocks.gamesquare _gsquare = null;
 //BA.debugLineNum = 407;BA.debugLine="Sub DrawBoard";
 //BA.debugLineNum = 408;BA.debugLine="Dim square As Rect";
_square = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
 //BA.debugLineNum = 409;BA.debugLine="For rowLoop = 0 To gameHeight - 1";
{
final int step346 = 1;
final int limit346 = (int) (_gameheight-1);
for (_rowloop = (int) (0); (step346 > 0 && _rowloop <= limit346) || (step346 < 0 && _rowloop >= limit346); _rowloop = ((int)(0 + _rowloop + step346))) {
 //BA.debugLineNum = 410;BA.debugLine="For colLoop = 0 To gameWidth - 1";
{
final int step347 = 1;
final int limit347 = (int) (_gamewidth-1);
for (_colloop = (int) (0); (step347 > 0 && _colloop <= limit347) || (step347 < 0 && _colloop >= limit347); _colloop = ((int)(0 + _colloop + step347))) {
 //BA.debugLineNum = 411;BA.debugLine="Dim gSquare As GameSquare = gameSquares(rowLoop, colLoop)";
_gsquare = mostCurrent._gamesquares[_rowloop][_colloop];
 //BA.debugLineNum = 413;BA.debugLine="square.Initialize(gSquare.TopLeft.Pos1-4dip,gSquare.TopLeft.Pos2-4dip,gSquare.TopLeft.Pos1+4dip,gSquare.TopLeft.Pos2+4dip)";
_square.Initialize((int) (_gsquare._topleft._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topleft._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
 //BA.debugLineNum = 414;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 415;BA.debugLine="square.Initialize(gSquare.TopRight.Pos1-4dip,gSquare.TopRight.Pos2-4dip,gSquare.TopRight.Pos1+4dip,gSquare.TopRight.Pos2+4dip)";
_square.Initialize((int) (_gsquare._topright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topright._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._topright._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
 //BA.debugLineNum = 416;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 417;BA.debugLine="square.Initialize(gSquare.BottomLeft.Pos1-4dip,gSquare.BottomLeft.Pos2-4dip,gSquare.BottomLeft.Pos1+4dip,gSquare.BottomLeft.Pos2+4dip)";
_square.Initialize((int) (_gsquare._bottomleft._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomleft._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
 //BA.debugLineNum = 418;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 419;BA.debugLine="square.Initialize(gSquare.BottomRight.Pos1-4dip,gSquare.BottomRight.Pos2-4dip,gSquare.BottomRight.Pos1+4dip,gSquare.BottomRight.Pos2+4dip)";
_square.Initialize((int) (_gsquare._bottomright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomright._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_gsquare._bottomright._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
 //BA.debugLineNum = 420;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_square.getObject()),anywheresoftware.b4a.keywords.Common.Colors.LightGray,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 //BA.debugLineNum = 421;BA.debugLine="Log(\"Drawing \" & rowLoop & \", \" & colLoop)";
anywheresoftware.b4a.keywords.Common.Log("Drawing "+BA.NumberToString(_rowloop)+", "+BA.NumberToString(_colloop));
 }
};
 }
};
 //BA.debugLineNum = 424;BA.debugLine="End Sub";
return "";
}
public static String  _emptythesquare(pineysoft.squarepaddocks.gamesquare _square) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _fillrect = null;
 //BA.debugLineNum = 868;BA.debugLine="Sub EmptyTheSquare(square As GameSquare)";
 //BA.debugLineNum = 869;BA.debugLine="Dim fillRect As Rect";
_fillrect = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
 //BA.debugLineNum = 871;BA.debugLine="If square.fillLabel.IsInitialized Then";
if (_square._filllabel.IsInitialized()) { 
 //BA.debugLineNum = 872;BA.debugLine="square.fillLabel.SetBackgroundImage(Null)";
_square._filllabel.SetBackgroundImage((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null));
 }else {
 //BA.debugLineNum = 874;BA.debugLine="fillRect.Initialize(square.TopLeft.Pos1 + 4dip, square.TopLeft.pos2  + 4dip, square.BottomRight.pos1  - 4dip, square.BottomRight.Pos2  - 4dip)";
_fillrect.Initialize((int) (_square._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
 //BA.debugLineNum = 875;BA.debugLine="canv.DrawRect(fillRect,SPConstants.BG_COLOUR,True,1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_fillrect.getObject()),_spconstants._bg_colour,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 };
 //BA.debugLineNum = 877;BA.debugLine="End Sub";
return "";
}
public static String  _fillthesquare(pineysoft.squarepaddocks.gamesquare _square,pineysoft.squarepaddocks.player _currplayer) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _fillrect = null;
anywheresoftware.b4a.objects.LabelWrapper _lblnew = null;
 //BA.debugLineNum = 848;BA.debugLine="Sub FillTheSquare(square As GameSquare, currPlayer As Player)";
 //BA.debugLineNum = 849;BA.debugLine="Dim fillRect As Rect";
_fillrect = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
 //BA.debugLineNum = 851;BA.debugLine="If currPlayer.PlayerImage.IsInitialized Then";
if (_currplayer._playerimage.IsInitialized()) { 
 //BA.debugLineNum = 852;BA.debugLine="If square.fillLabel.IsInitialized Then";
if (_square._filllabel.IsInitialized()) { 
 //BA.debugLineNum = 853;BA.debugLine="square.fillLabel.SetBackgroundImage(currPlayer.PlayerImage)";
_square._filllabel.SetBackgroundImage((android.graphics.Bitmap)(_currplayer._playerimage.getObject()));
 }else {
 //BA.debugLineNum = 855;BA.debugLine="Dim lblNew As Label";
_lblnew = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 856;BA.debugLine="lblNew.Initialize(\"\")";
_lblnew.Initialize(mostCurrent.activityBA,"");
 //BA.debugLineNum = 857;BA.debugLine="lblNew.SetBackgroundImage(currPlayer.PlayerImage)";
_lblnew.SetBackgroundImage((android.graphics.Bitmap)(_currplayer._playerimage.getObject()));
 //BA.debugLineNum = 858;BA.debugLine="lblNew.Gravity = Gravity.FILL";
_lblnew.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 859;BA.debugLine="square.fillLabel = lblNew";
_square._filllabel = _lblnew;
 //BA.debugLineNum = 860;BA.debugLine="panel1.AddView(lblNew, square.TopLeft.Pos1 + 4dip, square.TopLeft.Pos2  + 4dip, columnSpacing - 8dip, rowSpacing - 8dip)";
mostCurrent._panel1.AddView((android.view.View)(_lblnew.getObject()),(int) (_square._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_columnspacing-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8))),(int) (_rowspacing-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (8))));
 };
 }else {
 //BA.debugLineNum = 863;BA.debugLine="fillRect.Initialize(square.TopLeft.Pos1 + 4dip, square.TopLeft.Pos2  + 4dip, square.BottomRight.Pos1  - 4dip, square.BottomRight.Pos2  - 4dip)";
_fillrect.Initialize((int) (_square._topleft._pos1+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._topleft._pos2+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos1-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))),(int) (_square._bottomright._pos2-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4))));
 //BA.debugLineNum = 864;BA.debugLine="canv.DrawRect(fillRect,currPlayer.colour,True,1dip)";
mostCurrent._canv.DrawRect((android.graphics.Rect)(_fillrect.getObject()),_currplayer._colour,anywheresoftware.b4a.keywords.Common.True,(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (1))));
 };
 //BA.debugLineNum = 866;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.collections.List  _findallforsides(int _checksides) throws Exception{
anywheresoftware.b4a.objects.collections.List _foundsquares = null;
int _row = 0;
int _col = 0;
 //BA.debugLineNum = 931;BA.debugLine="Sub FindAllForSides(checkSides As Int) As List";
 //BA.debugLineNum = 932;BA.debugLine="Dim foundSquares As List";
_foundsquares = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 933;BA.debugLine="foundSquares.Initialize";
_foundsquares.Initialize();
 //BA.debugLineNum = 934;BA.debugLine="For row = 0 To gameHeight - 1";
{
final int step777 = 1;
final int limit777 = (int) (_gameheight-1);
for (_row = (int) (0); (step777 > 0 && _row <= limit777) || (step777 < 0 && _row >= limit777); _row = ((int)(0 + _row + step777))) {
 //BA.debugLineNum = 935;BA.debugLine="For col = 0 To gameWidth - 1";
{
final int step778 = 1;
final int limit778 = (int) (_gamewidth-1);
for (_col = (int) (0); (step778 > 0 && _col <= limit778) || (step778 < 0 && _col >= limit778); _col = ((int)(0 + _col + step778))) {
 //BA.debugLineNum = 936;BA.debugLine="If gameSquares(row,col).sidesTaken = checkSides Then";
if (mostCurrent._gamesquares[_row][_col]._sidestaken==_checksides) { 
 //BA.debugLineNum = 937;BA.debugLine="foundSquares.Add(gameSquares(row,col))";
_foundsquares.Add((Object)(mostCurrent._gamesquares[_row][_col]));
 };
 }
};
 }
};
 //BA.debugLineNum = 942;BA.debugLine="Return foundSquares";
if (true) return _foundsquares;
 //BA.debugLineNum = 943;BA.debugLine="End Sub";
return null;
}
public static pineysoft.squarepaddocks.gamesquare  _findselectedsquare(int _xpos,int _ypos) throws Exception{
int _colloop = 0;
int _rowloop = 0;
int _foundrow = 0;
int _foundcol = 0;
pineysoft.squarepaddocks.gamesquare _square = null;
 //BA.debugLineNum = 879;BA.debugLine="Sub FindSelectedSquare(xpos As Int, ypos As Int) As GameSquare";
 //BA.debugLineNum = 880;BA.debugLine="Dim colLoop As Int = 0";
_colloop = (int) (0);
 //BA.debugLineNum = 881;BA.debugLine="Dim rowloop As Int = 0";
_rowloop = (int) (0);
 //BA.debugLineNum = 882;BA.debugLine="Dim foundRow As Int = -1";
_foundrow = (int) (-1);
 //BA.debugLineNum = 883;BA.debugLine="Dim foundCol As Int = -1";
_foundcol = (int) (-1);
 //BA.debugLineNum = 884;BA.debugLine="Dim square As GameSquare";
_square = new pineysoft.squarepaddocks.gamesquare();
 //BA.debugLineNum = 886;BA.debugLine="For rowloop = 0 To gameHeight - 1";
{
final int step737 = 1;
final int limit737 = (int) (_gameheight-1);
for (_rowloop = (int) (0); (step737 > 0 && _rowloop <= limit737) || (step737 < 0 && _rowloop >= limit737); _rowloop = ((int)(0 + _rowloop + step737))) {
 //BA.debugLineNum = 887;BA.debugLine="square = gameSquares(rowloop, 0)";
_square = mostCurrent._gamesquares[_rowloop][(int) (0)];
 //BA.debugLineNum = 888;BA.debugLine="If square.TopLeft.pos2 > ypos Then";
if (_square._topleft._pos2>_ypos) { 
 //BA.debugLineNum = 889;BA.debugLine="If rowloop = 0 Then";
if (_rowloop==0) { 
 //BA.debugLineNum = 890;BA.debugLine="foundRow = 0";
_foundrow = (int) (0);
 }else {
 //BA.debugLineNum = 892;BA.debugLine="foundRow = rowloop - 1";
_foundrow = (int) (_rowloop-1);
 };
 //BA.debugLineNum = 894;BA.debugLine="rowloop = gameHeight -1";
_rowloop = (int) (_gameheight-1);
 };
 }
};
 //BA.debugLineNum = 898;BA.debugLine="If foundRow = -1 Then foundRow = gameHeight-1";
if (_foundrow==-1) { 
_foundrow = (int) (_gameheight-1);};
 //BA.debugLineNum = 900;BA.debugLine="For colLoop = 0 To gameWidth - 1";
{
final int step749 = 1;
final int limit749 = (int) (_gamewidth-1);
for (_colloop = (int) (0); (step749 > 0 && _colloop <= limit749) || (step749 < 0 && _colloop >= limit749); _colloop = ((int)(0 + _colloop + step749))) {
 //BA.debugLineNum = 901;BA.debugLine="square = gameSquares(foundRow, colLoop)";
_square = mostCurrent._gamesquares[_foundrow][_colloop];
 //BA.debugLineNum = 902;BA.debugLine="If square.TopLeft.pos1 > xpos  Then";
if (_square._topleft._pos1>_xpos) { 
 //BA.debugLineNum = 903;BA.debugLine="If colLoop = 0 Then";
if (_colloop==0) { 
 //BA.debugLineNum = 904;BA.debugLine="foundCol = 0";
_foundcol = (int) (0);
 }else {
 //BA.debugLineNum = 906;BA.debugLine="foundCol = colLoop - 1";
_foundcol = (int) (_colloop-1);
 };
 //BA.debugLineNum = 908;BA.debugLine="colLoop = gameWidth - 1";
_colloop = (int) (_gamewidth-1);
 };
 }
};
 //BA.debugLineNum = 912;BA.debugLine="If foundCol = -1 Then foundCol = gameWidth - 1";
if (_foundcol==-1) { 
_foundcol = (int) (_gamewidth-1);};
 //BA.debugLineNum = 914;BA.debugLine="Return gameSquares(foundRow,foundCol)";
if (true) return mostCurrent._gamesquares[_foundrow][_foundcol];
 //BA.debugLineNum = 915;BA.debugLine="End Sub";
return null;
}
public static int  _getothersidesquaresides(pineysoft.squarepaddocks.gamesquare _currentsquare,int _side) throws Exception{
pineysoft.squarepaddocks.gamesquare _checksquare = null;
 //BA.debugLineNum = 797;BA.debugLine="Sub GetOtherSideSquareSides(currentSquare As GameSquare, side As Int) As Int";
 //BA.debugLineNum = 799;BA.debugLine="Dim checkSquare As GameSquare = SubGetOppositeSquare(currentSquare, side)";
_checksquare = _subgetoppositesquare(_currentsquare,_side);
 //BA.debugLineNum = 801;BA.debugLine="If checkSquare.IsInitialized Then";
if (_checksquare.IsInitialized()) { 
 //BA.debugLineNum = 802;BA.debugLine="Return checkSquare.sidesTaken";
if (true) return _checksquare._sidestaken;
 }else {
 //BA.debugLineNum = 804;BA.debugLine="Return -1";
if (true) return (int) (-1);
 };
 //BA.debugLineNum = 807;BA.debugLine="End Sub";
return 0;
}
public static anywheresoftware.b4a.objects.ConcreteViewWrapper  _getviewbytag1(anywheresoftware.b4a.objects.ActivityWrapper _searchview,String _tag) throws Exception{
anywheresoftware.b4a.objects.ConcreteViewWrapper _tempview = null;
int _vwloop = 0;
 //BA.debugLineNum = 918;BA.debugLine="Sub GetViewByTag1(searchView As Activity, tag As String) As View";
 //BA.debugLineNum = 920;BA.debugLine="Dim tempView As View";
_tempview = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
 //BA.debugLineNum = 921;BA.debugLine="Dim vwloop As Int";
_vwloop = 0;
 //BA.debugLineNum = 922;BA.debugLine="For vwloop = 0 To searchView.NumberOfViews - 1";
{
final int step766 = 1;
final int limit766 = (int) (_searchview.getNumberOfViews()-1);
for (_vwloop = (int) (0); (step766 > 0 && _vwloop <= limit766) || (step766 < 0 && _vwloop >= limit766); _vwloop = ((int)(0 + _vwloop + step766))) {
 //BA.debugLineNum = 923;BA.debugLine="tempView = searchView.GetView(vwloop)";
_tempview = _searchview.GetView(_vwloop);
 //BA.debugLineNum = 924;BA.debugLine="If tempView.tag = tag Then";
if ((_tempview.getTag()).equals((Object)(_tag))) { 
 //BA.debugLineNum = 925;BA.debugLine="Return tempView";
if (true) return _tempview;
 };
 }
};
 //BA.debugLineNum = 928;BA.debugLine="Return tempView";
if (true) return _tempview;
 //BA.debugLineNum = 929;BA.debugLine="End Sub";
return null;
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _globals() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 35;BA.debugLine="Private gameSquares(,) As GameSquare";
mostCurrent._gamesquares = new pineysoft.squarepaddocks.gamesquare[(int) (0)][];
{
int d0 = mostCurrent._gamesquares.length;
int d1 = (int) (0);
for (int i0 = 0;i0 < d0;i0++) {
mostCurrent._gamesquares[i0] = new pineysoft.squarepaddocks.gamesquare[d1];
for (int i1 = 0;i1 < d1;i1++) {
mostCurrent._gamesquares[i0][i1] = new pineysoft.squarepaddocks.gamesquare();
}
}
}
;
 //BA.debugLineNum = 36;BA.debugLine="Dim gameTurns As List";
mostCurrent._gameturns = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 37;BA.debugLine="Private gameWidth As Int = 7";
_gamewidth = (int) (7);
 //BA.debugLineNum = 38;BA.debugLine="Private gameHeight As Int = 9";
_gameheight = (int) (9);
 //BA.debugLineNum = 39;BA.debugLine="Private columnSpacing As Int";
_columnspacing = 0;
 //BA.debugLineNum = 40;BA.debugLine="Private rowSpacing As Int";
_rowspacing = 0;
 //BA.debugLineNum = 41;BA.debugLine="Private panel1 As Panel";
mostCurrent._panel1 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private canv As Canvas";
mostCurrent._canv = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private players As List";
mostCurrent._players = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 44;BA.debugLine="Private playerImages As List";
mostCurrent._playerimages = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 45;BA.debugLine="Private lblPlayer1 As Label";
mostCurrent._lblplayer1 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private lblPlayer1Image As Label";
mostCurrent._lblplayer1image = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private lblPlayer2 As Label";
mostCurrent._lblplayer2 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 48;BA.debugLine="Private lblPlayer2Image As Label";
mostCurrent._lblplayer2image = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private lblPlayer3 As Label";
mostCurrent._lblplayer3 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 50;BA.debugLine="Private lblPlayer3Image As Label";
mostCurrent._lblplayer3image = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Private lblPlayer4 As Label";
mostCurrent._lblplayer4 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 52;BA.debugLine="Private lblPlayer4Image As Label";
mostCurrent._lblplayer4image = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 53;BA.debugLine="Private btnContinue As Button";
mostCurrent._btncontinue = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 54;BA.debugLine="Private spnPlayers As Spinner";
mostCurrent._spnplayers = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 55;BA.debugLine="Private sbColumns As SeekBar";
mostCurrent._sbcolumns = new anywheresoftware.b4a.objects.SeekBarWrapper();
 //BA.debugLineNum = 56;BA.debugLine="Private sbRows As SeekBar";
mostCurrent._sbrows = new anywheresoftware.b4a.objects.SeekBarWrapper();
 //BA.debugLineNum = 57;BA.debugLine="Private pnlStartScreen As Panel";
mostCurrent._pnlstartscreen = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 58;BA.debugLine="Private icon1 As ImageView";
mostCurrent._icon1 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 59;BA.debugLine="Private icon2 As ImageView";
mostCurrent._icon2 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 60;BA.debugLine="Private icon3 As ImageView";
mostCurrent._icon3 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 61;BA.debugLine="Private icon4 As ImageView";
mostCurrent._icon4 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 62;BA.debugLine="Private lblColumns As Label";
mostCurrent._lblcolumns = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 63;BA.debugLine="Private lblPlayers As Label";
mostCurrent._lblplayers = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 64;BA.debugLine="Private lblRows As Label";
mostCurrent._lblrows = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 65;BA.debugLine="Private pnlBase As Panel";
mostCurrent._pnlbase = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 66;BA.debugLine="Private btnCurrPlayer As Button";
mostCurrent._btncurrplayer = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 67;BA.debugLine="Private icon5 As ImageView";
mostCurrent._icon5 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 68;BA.debugLine="Private icon6 As ImageView";
mostCurrent._icon6 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 69;BA.debugLine="Private pnlDisplay As Panel";
mostCurrent._pnldisplay = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 70;BA.debugLine="Private pnlOuter As Panel";
mostCurrent._pnlouter = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 71;BA.debugLine="Private imageIcon As ImageView";
mostCurrent._imageicon = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 72;BA.debugLine="Private lblWinner As Label";
mostCurrent._lblwinner = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 73;BA.debugLine="Private chkSounds As CheckBox";
mostCurrent._chksounds = new anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper();
 //BA.debugLineNum = 74;BA.debugLine="Dim anim1 As AnimationPlus";
mostCurrent._anim1 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 75;BA.debugLine="Dim anim2 As AnimationPlus";
mostCurrent._anim2 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 76;BA.debugLine="Dim anim3 As AnimationPlus";
mostCurrent._anim3 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 77;BA.debugLine="Dim anim4 As AnimationPlus";
mostCurrent._anim4 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 78;BA.debugLine="Dim anim5 As AnimationPlus";
mostCurrent._anim5 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 79;BA.debugLine="Dim anim6 As AnimationPlus";
mostCurrent._anim6 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 80;BA.debugLine="Dim animShading As AnimationPlus";
mostCurrent._animshading = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 81;BA.debugLine="Dim animPanel1 As AnimationPlus";
mostCurrent._animpanel1 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 82;BA.debugLine="Dim animPanel2 As AnimationPlus";
mostCurrent._animpanel2 = new flm.b4a.animationplus.AnimationPlusWrapper();
 //BA.debugLineNum = 83;BA.debugLine="Private spnDroids As Spinner";
mostCurrent._spndroids = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 84;BA.debugLine="Private lblScores As Label";
mostCurrent._lblscores = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 85;BA.debugLine="Private spnDifficulty As Spinner";
mostCurrent._spndifficulty = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 86;BA.debugLine="Private pnlSelectionLeft As Panel";
mostCurrent._pnlselectionleft = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 87;BA.debugLine="Private pnlSelectionRight As Panel";
mostCurrent._pnlselectionright = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 88;BA.debugLine="Private pnlShading As Panel";
mostCurrent._pnlshading = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 89;BA.debugLine="Private lblDifficulty As Label";
mostCurrent._lbldifficulty = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 90;BA.debugLine="Private lblDroids As Label";
mostCurrent._lbldroids = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 91;BA.debugLine="Private lblSound As Label";
mostCurrent._lblsound = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public static String  _initgameplay() throws Exception{
 //BA.debugLineNum = 344;BA.debugLine="Public Sub InitGamePlay";
 //BA.debugLineNum = 345;BA.debugLine="numberOfPlayers = spnPlayers.SelectedItem";
_numberofplayers = (int)(Double.parseDouble(mostCurrent._spnplayers.getSelectedItem()));
 //BA.debugLineNum = 346;BA.debugLine="numberOfDroids = spnDroids.SelectedItem";
_numberofdroids = (int)(Double.parseDouble(mostCurrent._spndroids.getSelectedItem()));
 //BA.debugLineNum = 347;BA.debugLine="gameHeight = sbRows.Value + 4";
_gameheight = (int) (mostCurrent._sbrows.getValue()+4);
 //BA.debugLineNum = 348;BA.debugLine="gameWidth = sbColumns.Value + 4";
_gamewidth = (int) (mostCurrent._sbcolumns.getValue()+4);
 //BA.debugLineNum = 349;BA.debugLine="columnSpacing = panel1.Width / (gameWidth + 1)";
_columnspacing = (int) (mostCurrent._panel1.getWidth()/(double)(_gamewidth+1));
 //BA.debugLineNum = 350;BA.debugLine="rowSpacing = panel1.Height / (gameHeight + 1)";
_rowspacing = (int) (mostCurrent._panel1.getHeight()/(double)(_gameheight+1));
 //BA.debugLineNum = 351;BA.debugLine="canv.Initialize(panel1)";
mostCurrent._canv.Initialize((android.view.View)(mostCurrent._panel1.getObject()));
 //BA.debugLineNum = 352;BA.debugLine="totalScore = 0";
_totalscore = (int) (0);
 //BA.debugLineNum = 353;BA.debugLine="gameTurns.Initialize";
mostCurrent._gameturns.Initialize();
 //BA.debugLineNum = 355;BA.debugLine="CreateBoard";
_createboard();
 //BA.debugLineNum = 356;BA.debugLine="DrawBoard";
_drawboard();
 //BA.debugLineNum = 357;BA.debugLine="CreatePlayers";
_createplayers();
 //BA.debugLineNum = 358;BA.debugLine="SetDifficulty";
_setdifficulty();
 //BA.debugLineNum = 359;BA.debugLine="End Sub";
return "";
}
public static String  _initialisesounds() throws Exception{
 //BA.debugLineNum = 301;BA.debugLine="Sub InitialiseSounds";
 //BA.debugLineNum = 302;BA.debugLine="sounds.Initialize(10)";
_sounds.Initialize((int) (10));
 //BA.debugLineNum = 303;BA.debugLine="giggleSound = sounds.Load(File.DirAssets, \"Giggle1.mp3\")";
_gigglesound = _sounds.Load(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Giggle1.mp3");
 //BA.debugLineNum = 304;BA.debugLine="End Sub";
return "";
}
public static String  _lasticon_animationend() throws Exception{
 //BA.debugLineNum = 159;BA.debugLine="Sub LastIcon_AnimationEnd";
 //BA.debugLineNum = 160;BA.debugLine="AnimateShading";
_animateshading();
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return "";
}
public static String  _leftpanel_animationend() throws Exception{
 //BA.debugLineNum = 183;BA.debugLine="Sub LeftPanel_AnimationEnd";
 //BA.debugLineNum = 184;BA.debugLine="Log(\"Start Right Panel Anim\")";
anywheresoftware.b4a.keywords.Common.Log("Start Right Panel Anim");
 //BA.debugLineNum = 185;BA.debugLine="AnimatePanelRight";
_animatepanelright();
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return "";
}
public static String  _loadimages() throws Exception{
boolean _moreimages = false;
int _imageloop = 0;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _bm = null;
 //BA.debugLineNum = 270;BA.debugLine="Sub LoadImages";
 //BA.debugLineNum = 271;BA.debugLine="Dim moreImages As Boolean = True";
_moreimages = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 272;BA.debugLine="Dim imageLoop As Int = 1";
_imageloop = (int) (1);
 //BA.debugLineNum = 274;BA.debugLine="playerImages.Initialize";
mostCurrent._playerimages.Initialize();
 //BA.debugLineNum = 276;BA.debugLine="Do While moreImages = True";
while (_moreimages==anywheresoftware.b4a.keywords.Common.True) {
 //BA.debugLineNum = 277;BA.debugLine="If File.Exists(File.DirAssets,\"cuteImage\" & imageLoop & \".png\") Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"cuteImage"+BA.NumberToString(_imageloop)+".png")) { 
 //BA.debugLineNum = 278;BA.debugLine="Dim bm As Bitmap";
_bm = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 279;BA.debugLine="bm.Initialize(File.DirAssets, \"cuteImage\" & imageLoop & \".png\")";
_bm.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"cuteImage"+BA.NumberToString(_imageloop)+".png");
 //BA.debugLineNum = 280;BA.debugLine="playerImages.Add(bm)";
mostCurrent._playerimages.Add((Object)(_bm.getObject()));
 //BA.debugLineNum = 281;BA.debugLine="imageLoop = imageLoop + 1";
_imageloop = (int) (_imageloop+1);
 }else {
 //BA.debugLineNum = 283;BA.debugLine="moreImages = False";
_moreimages = anywheresoftware.b4a.keywords.Common.False;
 };
 }
;
 //BA.debugLineNum = 286;BA.debugLine="End Sub";
return "";
}
public static String  _loadspinners() throws Exception{
 //BA.debugLineNum = 288;BA.debugLine="Sub LoadSpinners";
 //BA.debugLineNum = 290;BA.debugLine="spnPlayers.AddAll(Array As Int(2,3,4))";
mostCurrent._spnplayers.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new int[]{(int) (2),(int) (3),(int) (4)}));
 //BA.debugLineNum = 291;BA.debugLine="spnDroids.AddAll(Array As Int(0,1))";
mostCurrent._spndroids.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new int[]{(int) (0),(int) (1)}));
 //BA.debugLineNum = 292;BA.debugLine="spnDifficulty.AddAll(Array As String(\"Easy\",\"Medium\",\"Hard\"))";
mostCurrent._spndifficulty.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"Easy","Medium","Hard"}));
 //BA.debugLineNum = 294;BA.debugLine="End Sub";
return "";
}
public static String  _makedroidmove(pineysoft.squarepaddocks.player _currplayer) throws Exception{
anywheresoftware.b4a.objects.collections.List _found3s = null;
anywheresoftware.b4a.objects.collections.List _found2s = null;
anywheresoftware.b4a.objects.collections.List _found1s = null;
anywheresoftware.b4a.objects.collections.List _found0s = null;
boolean _sideclaimed = false;
int _numberclosed = 0;
boolean _exitloop = false;
boolean _forceanyalways = false;
 //BA.debugLineNum = 592;BA.debugLine="Sub MakeDroidMove(currPlayer As Player)";
 //BA.debugLineNum = 593;BA.debugLine="Dim found3s As List";
_found3s = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 594;BA.debugLine="Dim found2s As List = FindAllForSides(2)";
_found2s = new anywheresoftware.b4a.objects.collections.List();
_found2s = _findallforsides((int) (2));
 //BA.debugLineNum = 595;BA.debugLine="Dim found1s As List = FindAllForSides(1)";
_found1s = new anywheresoftware.b4a.objects.collections.List();
_found1s = _findallforsides((int) (1));
 //BA.debugLineNum = 596;BA.debugLine="Dim found0s As List = FindAllForSides(0)";
_found0s = new anywheresoftware.b4a.objects.collections.List();
_found0s = _findallforsides((int) (0));
 //BA.debugLineNum = 597;BA.debugLine="Dim sideClaimed As Boolean";
_sideclaimed = false;
 //BA.debugLineNum = 598;BA.debugLine="Dim numberClosed As Int = 1";
_numberclosed = (int) (1);
 //BA.debugLineNum = 599;BA.debugLine="Dim exitLoop As Boolean";
_exitloop = false;
 //BA.debugLineNum = 600;BA.debugLine="Dim forceAnyAlways As Boolean";
_forceanyalways = false;
 //BA.debugLineNum = 602;BA.debugLine="If difficulty = SPConstants.DIFFICULTY_EASY Then";
if ((_difficulty).equals(_spconstants._difficulty_easy)) { 
 //BA.debugLineNum = 603;BA.debugLine="forceAnyAlways = True";
_forceanyalways = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 606;BA.debugLine="Do While exitLoop = False";
while (_exitloop==anywheresoftware.b4a.keywords.Common.False) {
 //BA.debugLineNum = 607;BA.debugLine="found3s = FindAllForSides(3)";
_found3s = _findallforsides((int) (3));
 //BA.debugLineNum = 608;BA.debugLine="If found3s.Size > 0 Then";
if (_found3s.getSize()>0) { 
 //BA.debugLineNum = 609;BA.debugLine="TakeEasy3s(found3s, currPlayer)";
_takeeasy3s(_found3s,_currplayer);
 //BA.debugLineNum = 610;BA.debugLine="Log(\"Checking Doubles\")";
anywheresoftware.b4a.keywords.Common.Log("Checking Doubles");
 //BA.debugLineNum = 611;BA.debugLine="TakeDoubles";
_takedoubles();
 //BA.debugLineNum = 614;BA.debugLine="Dim numberClosed As Int = CloseCompletedSquares(currPlayer)";
_numberclosed = _closecompletedsquares(_currplayer);
 //BA.debugLineNum = 615;BA.debugLine="If numberClosed > 0 Then";
if (_numberclosed>0) { 
 //BA.debugLineNum = 616;BA.debugLine="currPlayer.Score = currPlayer.Score + numberClosed";
_currplayer._score = (int) (_currplayer._score+_numberclosed);
 //BA.debugLineNum = 617;BA.debugLine="totalScore = totalScore + numberClosed";
_totalscore = (int) (_totalscore+_numberclosed);
 }else {
 //BA.debugLineNum = 619;BA.debugLine="exitLoop = True";
_exitloop = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 623;BA.debugLine="If CheckAndDisplayWinnerScreen Then";
if (_checkanddisplaywinnerscreen()) { 
 //BA.debugLineNum = 624;BA.debugLine="exitLoop = True";
_exitloop = anywheresoftware.b4a.keywords.Common.True;
 };
 }else {
 //BA.debugLineNum = 627;BA.debugLine="exitLoop = True";
_exitloop = anywheresoftware.b4a.keywords.Common.True;
 };
 }
;
 //BA.debugLineNum = 631;BA.debugLine="If found0s.Size > 0 Then";
if (_found0s.getSize()>0) { 
 //BA.debugLineNum = 632;BA.debugLine="Log(\"Checking 0's\")";
anywheresoftware.b4a.keywords.Common.Log("Checking 0's");
 //BA.debugLineNum = 633;BA.debugLine="If TakeSingle(found0s, forceAnyAlways) = False Then";
if (_takesingle(_found0s,_forceanyalways)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 634;BA.debugLine="Log(\"Checking 0's forced\")";
anywheresoftware.b4a.keywords.Common.Log("Checking 0's forced");
 //BA.debugLineNum = 635;BA.debugLine="sideClaimed = TakeSingle(found0s, True)";
_sideclaimed = _takesingle(_found0s,anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 637;BA.debugLine="sideClaimed = True";
_sideclaimed = anywheresoftware.b4a.keywords.Common.True;
 };
 };
 //BA.debugLineNum = 640;BA.debugLine="If sideClaimed = False AND found1s.Size > 0 Then";
if (_sideclaimed==anywheresoftware.b4a.keywords.Common.False && _found1s.getSize()>0) { 
 //BA.debugLineNum = 641;BA.debugLine="Log(\"Checking 1's\")";
anywheresoftware.b4a.keywords.Common.Log("Checking 1's");
 //BA.debugLineNum = 642;BA.debugLine="If TakeSingle(found1s , forceAnyAlways) = False Then";
if (_takesingle(_found1s,_forceanyalways)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 643;BA.debugLine="Log(\"Checking 1's forced\")";
anywheresoftware.b4a.keywords.Common.Log("Checking 1's forced");
 //BA.debugLineNum = 644;BA.debugLine="sideClaimed = TakeSingle(found0s, True)";
_sideclaimed = _takesingle(_found0s,anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 646;BA.debugLine="sideClaimed = True";
_sideclaimed = anywheresoftware.b4a.keywords.Common.True;
 };
 };
 //BA.debugLineNum = 649;BA.debugLine="If sideClaimed = False Then";
if (_sideclaimed==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 650;BA.debugLine="Log(\"Checking 2's\")";
anywheresoftware.b4a.keywords.Common.Log("Checking 2's");
 //BA.debugLineNum = 651;BA.debugLine="If TakeSingle(found2s, forceAnyAlways) = False Then";
if (_takesingle(_found2s,_forceanyalways)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 652;BA.debugLine="Log(\"Checking 2's forced\")";
anywheresoftware.b4a.keywords.Common.Log("Checking 2's forced");
 //BA.debugLineNum = 653;BA.debugLine="TakeSingle(found2s, True)";
_takesingle(_found2s,anywheresoftware.b4a.keywords.Common.True);
 };
 };
 //BA.debugLineNum = 657;BA.debugLine="Dim numberClosed As Int = CloseCompletedSquares(currPlayer)";
_numberclosed = _closecompletedsquares(_currplayer);
 //BA.debugLineNum = 658;BA.debugLine="If numberClosed > 0 Then";
if (_numberclosed>0) { 
 //BA.debugLineNum = 659;BA.debugLine="currPlayer.Score = currPlayer.Score + numberClosed";
_currplayer._score = (int) (_currplayer._score+_numberclosed);
 //BA.debugLineNum = 660;BA.debugLine="totalScore = totalScore + numberClosed";
_totalscore = (int) (_totalscore+_numberclosed);
 //BA.debugLineNum = 661;BA.debugLine="CheckAndDisplayWinnerScreen";
_checkanddisplaywinnerscreen();
 };
 //BA.debugLineNum = 664;BA.debugLine="UpdateScore(currPlayer)";
_updatescore(_currplayer);
 //BA.debugLineNum = 665;BA.debugLine="End Sub";
return "";
}
public static String  _markotherside(pineysoft.squarepaddocks.gamesquare _currentsquare,int _side,boolean _marktaken) throws Exception{
int _foundcol = 0;
int _foundrow = 0;
int _updateside = 0;
 //BA.debugLineNum = 506;BA.debugLine="Public Sub MarkOtherSide(currentSquare As GameSquare, side As Int, markTaken As Boolean)";
 //BA.debugLineNum = 507;BA.debugLine="Dim foundCol As Int = -1";
_foundcol = (int) (-1);
 //BA.debugLineNum = 508;BA.debugLine="Dim foundRow As Int = -1";
_foundrow = (int) (-1);
 //BA.debugLineNum = 509;BA.debugLine="Dim updateSide As Int";
_updateside = 0;
 //BA.debugLineNum = 511;BA.debugLine="foundRow = currentSquare.RowPos";
_foundrow = _currentsquare._rowpos;
 //BA.debugLineNum = 512;BA.debugLine="foundCol = currentSquare.ColPos";
_foundcol = _currentsquare._colpos;
 //BA.debugLineNum = 515;BA.debugLine="Select side";
switch (BA.switchObjectToInt(_side,_spconstants._top_side,_spconstants._right_side,_spconstants._bottom_side,_spconstants._left_side)) {
case 0:
 //BA.debugLineNum = 517;BA.debugLine="If foundRow > 0 Then";
if (_foundrow>0) { 
 //BA.debugLineNum = 518;BA.debugLine="foundRow = foundRow - 1";
_foundrow = (int) (_foundrow-1);
 //BA.debugLineNum = 519;BA.debugLine="updateSide = SPConstants.BOTTOM_SIDE";
_updateside = _spconstants._bottom_side;
 }else {
 //BA.debugLineNum = 521;BA.debugLine="foundRow = -1";
_foundrow = (int) (-1);
 };
 break;
case 1:
 //BA.debugLineNum = 524;BA.debugLine="If foundCol < gameWidth - 1 Then";
if (_foundcol<_gamewidth-1) { 
 //BA.debugLineNum = 525;BA.debugLine="foundCol = foundCol + 1";
_foundcol = (int) (_foundcol+1);
 //BA.debugLineNum = 526;BA.debugLine="updateSide = SPConstants.LEFT_SIDE";
_updateside = _spconstants._left_side;
 }else {
 //BA.debugLineNum = 528;BA.debugLine="foundCol = -1";
_foundcol = (int) (-1);
 };
 break;
case 2:
 //BA.debugLineNum = 532;BA.debugLine="If foundRow < gameHeight - 1 Then";
if (_foundrow<_gameheight-1) { 
 //BA.debugLineNum = 533;BA.debugLine="foundRow = foundRow + 1";
_foundrow = (int) (_foundrow+1);
 //BA.debugLineNum = 534;BA.debugLine="updateSide = SPConstants.TOP_SIDE";
_updateside = _spconstants._top_side;
 }else {
 //BA.debugLineNum = 536;BA.debugLine="foundRow = -1";
_foundrow = (int) (-1);
 };
 break;
case 3:
 //BA.debugLineNum = 539;BA.debugLine="If foundCol > 0 Then";
if (_foundcol>0) { 
 //BA.debugLineNum = 540;BA.debugLine="foundCol = foundCol - 1";
_foundcol = (int) (_foundcol-1);
 //BA.debugLineNum = 541;BA.debugLine="updateSide = SPConstants.RIGHT_SIDE";
_updateside = _spconstants._right_side;
 }else {
 //BA.debugLineNum = 543;BA.debugLine="foundCol = -1";
_foundcol = (int) (-1);
 };
 break;
}
;
 //BA.debugLineNum = 547;BA.debugLine="If foundRow <> -1 AND foundCol <> -1 Then";
if (_foundrow!=-1 && _foundcol!=-1) { 
 //BA.debugLineNum = 548;BA.debugLine="gameSquares(foundRow,foundCol).MarkSideTaken(updateSide, markTaken)";
mostCurrent._gamesquares[_foundrow][_foundcol]._marksidetaken(_updateside,_marktaken);
 //BA.debugLineNum = 550;BA.debugLine="Log(\"Took \" & currentSquare.RowPos & \",\" & currentSquare.ColPos & \" - side : \" & side)";
anywheresoftware.b4a.keywords.Common.Log("Took "+BA.NumberToString(_currentsquare._rowpos)+","+BA.NumberToString(_currentsquare._colpos)+" - side : "+BA.NumberToString(_side));
 //BA.debugLineNum = 551;BA.debugLine="Log(\"Sides Taken = \" & currentSquare.sidesTaken)";
anywheresoftware.b4a.keywords.Common.Log("Sides Taken = "+BA.NumberToString(_currentsquare._sidestaken));
 //BA.debugLineNum = 552;BA.debugLine="Log(\"Second Square \" & gameSquares(foundRow,foundCol).RowPos & \",\" & gameSquares(foundRow,foundCol).ColPos & \" - side : \" & updateSide)";
anywheresoftware.b4a.keywords.Common.Log("Second Square "+BA.NumberToString(mostCurrent._gamesquares[_foundrow][_foundcol]._rowpos)+","+BA.NumberToString(mostCurrent._gamesquares[_foundrow][_foundcol]._colpos)+" - side : "+BA.NumberToString(_updateside));
 //BA.debugLineNum = 553;BA.debugLine="Log(\"Sides Taken = \" & gameSquares(foundRow,foundCol).sidesTaken)";
anywheresoftware.b4a.keywords.Common.Log("Sides Taken = "+BA.NumberToString(mostCurrent._gamesquares[_foundrow][_foundcol]._sidestaken));
 };
 //BA.debugLineNum = 555;BA.debugLine="End Sub";
return "";
}
public static String  _markotherside2(pineysoft.squarepaddocks.gamesquare _currentsquare,int _side) throws Exception{
 //BA.debugLineNum = 503;BA.debugLine="Public Sub MarkOtherSide2(currentSquare As GameSquare, side As Int)";
 //BA.debugLineNum = 504;BA.debugLine="MarkOtherSide(currentSquare, side, True)";
_markotherside(_currentsquare,_side,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 505;BA.debugLine="End Sub";
return "";
}
public static String  _panel1_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 379;BA.debugLine="Sub Panel1_Touch (Action As Int, X As Float, Y As Float)";
 //BA.debugLineNum = 380;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,mostCurrent._activity.ACTION_UP)) {
case 0:
 //BA.debugLineNum = 382;BA.debugLine="Log (\"X,Y = \" & X & \",\" & Y)";
anywheresoftware.b4a.keywords.Common.Log("X,Y = "+BA.NumberToString(_x)+","+BA.NumberToString(_y));
 //BA.debugLineNum = 383;BA.debugLine="CalculateMove(X,Y)";
_calculatemove((int) (_x),(int) (_y));
 //BA.debugLineNum = 384;BA.debugLine="panel1.Invalidate";
mostCurrent._panel1.Invalidate();
 break;
}
;
 //BA.debugLineNum = 386;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 18;BA.debugLine="Private currentPlayer As Short";
_currentplayer = (short)0;
 //BA.debugLineNum = 19;BA.debugLine="Private numberOfPlayers As Int";
_numberofplayers = 0;
 //BA.debugLineNum = 20;BA.debugLine="Private numberOfDroids As Int";
_numberofdroids = 0;
 //BA.debugLineNum = 21;BA.debugLine="Private playerColours As List ' List of Ints";
_playercolours = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 22;BA.debugLine="Private inGame As Boolean";
_ingame = false;
 //BA.debugLineNum = 23;BA.debugLine="Private giggleSound As Int";
_gigglesound = 0;
 //BA.debugLineNum = 24;BA.debugLine="Dim sounds As SoundPool";
_sounds = new anywheresoftware.b4a.audio.SoundPoolWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private totalScore As Int";
_totalscore = 0;
 //BA.debugLineNum = 26;BA.debugLine="Dim SPConstants As Constants";
_spconstants = new pineysoft.squarepaddocks.constants();
 //BA.debugLineNum = 27;BA.debugLine="Dim difficulty As String";
_difficulty = "";
 //BA.debugLineNum = 28;BA.debugLine="Dim vibrate As PhoneVibrate";
_vibrate = new anywheresoftware.b4a.phone.Phone.PhoneVibrate();
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public static String  _removeturn(pineysoft.squarepaddocks.turn _lastturn,pineysoft.squarepaddocks.player _currplayer) throws Exception{
 //BA.debugLineNum = 1013;BA.debugLine="Public Sub RemoveTurn(lastTurn As Turn, currPlayer As Player)";
 //BA.debugLineNum = 1016;BA.debugLine="If lastTurn.Square.sidesTaken = 4 Then";
if (_lastturn._square._sidestaken==4) { 
 //BA.debugLineNum = 1017;BA.debugLine="currPlayer.Score = currPlayer.Score - 1";
_currplayer._score = (int) (_currplayer._score-1);
 //BA.debugLineNum = 1018;BA.debugLine="EmptyTheSquare(lastTurn.Square)";
_emptythesquare(_lastturn._square);
 };
 //BA.debugLineNum = 1022;BA.debugLine="lastTurn.Square.RemoveSide(canv, lastTurn.Edge)";
_lastturn._square._removeside(mostCurrent._canv,_lastturn._edge);
 //BA.debugLineNum = 1023;BA.debugLine="MarkOtherSide(lastTurn.Square,lastTurn.Edge,False)";
_markotherside(_lastturn._square,_lastturn._edge,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 1026;BA.debugLine="gameTurns.RemoveAt(gameTurns.Size - 1)";
mostCurrent._gameturns.RemoveAt((int) (mostCurrent._gameturns.getSize()-1));
 //BA.debugLineNum = 1029;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
 //BA.debugLineNum = 1030;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
 //BA.debugLineNum = 1031;BA.debugLine="lastTurn.Square.RedrawSide(canv, lastTurn.Edge)";
_lastturn._square._redrawside(mostCurrent._canv,_lastturn._edge);
 };
 //BA.debugLineNum = 1033;BA.debugLine="End Sub";
return "";
}
public static String  _reverseanimate() throws Exception{
 //BA.debugLineNum = 208;BA.debugLine="Sub ReverseAnimate";
 //BA.debugLineNum = 216;BA.debugLine="anim1.InitializeTranslate(\"\", 350dip,100dip,-120dip,100dip)";
mostCurrent._anim1.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 217;BA.debugLine="anim1.Duration = 1000";
mostCurrent._anim1.setDuration((long) (1000));
 //BA.debugLineNum = 218;BA.debugLine="anim1.PersistAfter = True";
mostCurrent._anim1.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 219;BA.debugLine="anim1.Start(icon1)";
mostCurrent._anim1.Start((android.view.View)(mostCurrent._icon1.getObject()));
 //BA.debugLineNum = 220;BA.debugLine="anim2.InitializeTranslate(\"\", 150dip,200dip,100%x + 120dip,200dip)";
mostCurrent._anim2.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 221;BA.debugLine="anim2.Duration = 1000";
mostCurrent._anim2.setDuration((long) (1000));
 //BA.debugLineNum = 222;BA.debugLine="anim2.StartOffset = 150";
mostCurrent._anim2.setStartOffset((long) (150));
 //BA.debugLineNum = 223;BA.debugLine="anim2.PersistAfter = True";
mostCurrent._anim2.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 224;BA.debugLine="anim2.Start(icon2)";
mostCurrent._anim2.Start((android.view.View)(mostCurrent._icon2.getObject()));
 //BA.debugLineNum = 225;BA.debugLine="anim3.InitializeTranslate(\"\", 250dip,100dip,-120dip,100dip)";
mostCurrent._anim3.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 226;BA.debugLine="anim3.Duration = 1000";
mostCurrent._anim3.setDuration((long) (1000));
 //BA.debugLineNum = 227;BA.debugLine="anim3.StartOffset = 300";
mostCurrent._anim3.setStartOffset((long) (300));
 //BA.debugLineNum = 228;BA.debugLine="anim3.PersistAfter = True";
mostCurrent._anim3.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 229;BA.debugLine="anim3.Start(icon3)";
mostCurrent._anim3.Start((android.view.View)(mostCurrent._icon3.getObject()));
 //BA.debugLineNum = 230;BA.debugLine="anim4.InitializeTranslate(\"\", 200dip,250dip,200dip,100%x + 120dip)";
mostCurrent._anim4.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))));
 //BA.debugLineNum = 231;BA.debugLine="anim4.Duration = 1000";
mostCurrent._anim4.setDuration((long) (1000));
 //BA.debugLineNum = 232;BA.debugLine="anim4.StartOffset = 450";
mostCurrent._anim4.setStartOffset((long) (450));
 //BA.debugLineNum = 233;BA.debugLine="anim4.PersistAfter	 = True";
mostCurrent._anim4.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 234;BA.debugLine="anim4.Start(icon4)";
mostCurrent._anim4.Start((android.view.View)(mostCurrent._icon4.getObject()));
 //BA.debugLineNum = 235;BA.debugLine="anim5.InitializeTranslate(\"\", 150dip,100dip,-120dip,100dip)";
mostCurrent._anim5.InitializeTranslate(mostCurrent.activityBA,"",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))),(float) (-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 236;BA.debugLine="anim5.Duration = 1000";
mostCurrent._anim5.setDuration((long) (1000));
 //BA.debugLineNum = 237;BA.debugLine="anim5.StartOffset = 600";
mostCurrent._anim5.setStartOffset((long) (600));
 //BA.debugLineNum = 238;BA.debugLine="anim5.PersistAfter = True";
mostCurrent._anim5.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 239;BA.debugLine="anim5.Start(icon5)";
mostCurrent._anim5.Start((android.view.View)(mostCurrent._icon5.getObject()));
 //BA.debugLineNum = 240;BA.debugLine="anim6.InitializeTranslate(\"anim6\", 200dip,350dip,200dip,100%x + 120dip)";
mostCurrent._anim6.InitializeTranslate(mostCurrent.activityBA,"anim6",(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (350))),(float) (anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))),(float) (anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA)+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (120))));
 //BA.debugLineNum = 241;BA.debugLine="anim6.Duration = 1000";
mostCurrent._anim6.setDuration((long) (1000));
 //BA.debugLineNum = 242;BA.debugLine="anim6.StartOffset = 750";
mostCurrent._anim6.setStartOffset((long) (750));
 //BA.debugLineNum = 243;BA.debugLine="anim6.PersistAfter = True";
mostCurrent._anim6.setPersistAfter(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 244;BA.debugLine="anim6.Start(icon6)";
mostCurrent._anim6.Start((android.view.View)(mostCurrent._icon6.getObject()));
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return "";
}
public static String  _rightpanel_animationend() throws Exception{
 //BA.debugLineNum = 195;BA.debugLine="Sub RightPanel_AnimationEnd";
 //BA.debugLineNum = 196;BA.debugLine="animPanel1.Stop(pnlSelectionLeft)";
mostCurrent._animpanel1.Stop((android.view.View)(mostCurrent._pnlselectionleft.getObject()));
 //BA.debugLineNum = 197;BA.debugLine="pnlSelectionLeft.Top = 0dip";
mostCurrent._pnlselectionleft.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 198;BA.debugLine="pnlSelectionLeft.Left = 0dip";
mostCurrent._pnlselectionleft.setLeft(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 199;BA.debugLine="pnlSelectionLeft.Width = 50%x";
mostCurrent._pnlselectionleft.setWidth(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (50),mostCurrent.activityBA));
 //BA.debugLineNum = 200;BA.debugLine="pnlSelectionLeft.Height = 100%y";
mostCurrent._pnlselectionleft.setHeight(anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (100),mostCurrent.activityBA));
 //BA.debugLineNum = 202;BA.debugLine="animPanel2.Stop(pnlSelectionRight)";
mostCurrent._animpanel2.Stop((android.view.View)(mostCurrent._pnlselectionright.getObject()));
 //BA.debugLineNum = 203;BA.debugLine="pnlSelectionRight.Top = 0dip";
mostCurrent._pnlselectionright.setTop(anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (0)));
 //BA.debugLineNum = 204;BA.debugLine="pnlSelectionRight.Left = 50%x";
mostCurrent._pnlselectionright.setLeft(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (50),mostCurrent.activityBA));
 //BA.debugLineNum = 205;BA.debugLine="pnlSelectionRight.Width = 50%x";
mostCurrent._pnlselectionright.setWidth(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (50),mostCurrent.activityBA));
 //BA.debugLineNum = 206;BA.debugLine="pnlSelectionRight.Height = 100%y";
mostCurrent._pnlselectionright.setHeight(anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (100),mostCurrent.activityBA));
 //BA.debugLineNum = 207;BA.debugLine="End Sub";
return "";
}
public static String  _sbcolumns_valuechanged(int _value,boolean _userchanged) throws Exception{
 //BA.debugLineNum = 985;BA.debugLine="Sub sbColumns_ValueChanged (Value As Int, UserChanged As Boolean)";
 //BA.debugLineNum = 986;BA.debugLine="gameWidth = Value + 4";
_gamewidth = (int) (_value+4);
 //BA.debugLineNum = 987;BA.debugLine="lblColumns.Text = \"Columns : \" & (Value	+ 4)";
mostCurrent._lblcolumns.setText((Object)("Columns : "+BA.NumberToString((_value+4))));
 //BA.debugLineNum = 988;BA.debugLine="End Sub";
return "";
}
public static String  _sbrows_valuechanged(int _value,boolean _userchanged) throws Exception{
 //BA.debugLineNum = 981;BA.debugLine="Sub sbRows_ValueChanged (Value As Int, UserChanged As Boolean)";
 //BA.debugLineNum = 982;BA.debugLine="gameHeight = Value + 4";
_gameheight = (int) (_value+4);
 //BA.debugLineNum = 983;BA.debugLine="lblRows.Text = \"Rows : \" & (Value + 4)";
mostCurrent._lblrows.setText((Object)("Rows : "+BA.NumberToString((_value+4))));
 //BA.debugLineNum = 984;BA.debugLine="End Sub";
return "";
}
public static String  _setdifficulty() throws Exception{
 //BA.debugLineNum = 361;BA.debugLine="Public Sub SetDifficulty";
 //BA.debugLineNum = 362;BA.debugLine="Select spnDifficulty.SelectedItem";
switch (BA.switchObjectToInt(mostCurrent._spndifficulty.getSelectedItem(),"Easy","Medium","Hard")) {
case 0:
 //BA.debugLineNum = 364;BA.debugLine="difficulty = SPConstants.DIFFICULTY_EASY";
_difficulty = _spconstants._difficulty_easy;
 break;
case 1:
 //BA.debugLineNum = 366;BA.debugLine="difficulty = SPConstants.DIFFICULTY_MEDIUM";
_difficulty = _spconstants._difficulty_medium;
 break;
case 2:
 //BA.debugLineNum = 368;BA.debugLine="difficulty = SPConstants.DIFFICULTY_HARD";
_difficulty = _spconstants._difficulty_hard;
 break;
}
;
 //BA.debugLineNum = 370;BA.debugLine="End Sub";
return "";
}
public static String  _shading_animationend() throws Exception{
 //BA.debugLineNum = 171;BA.debugLine="Sub Shading_AnimationEnd";
 //BA.debugLineNum = 172;BA.debugLine="Log(\"Start Left Panel Anim\")";
anywheresoftware.b4a.keywords.Common.Log("Start Left Panel Anim");
 //BA.debugLineNum = 173;BA.debugLine="AnimatePanelLeft";
_animatepanelleft();
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return "";
}
public static String  _showcharacters() throws Exception{
 //BA.debugLineNum = 247;BA.debugLine="Sub ShowCharacters";
 //BA.debugLineNum = 248;BA.debugLine="icon1.Left = Activity.Left + 250dip";
mostCurrent._icon1.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))));
 //BA.debugLineNum = 249;BA.debugLine="icon1.Top = Activity.Top + 100dip";
mostCurrent._icon1.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 250;BA.debugLine="icon2.Left = Activity.Left + 50dip";
mostCurrent._icon2.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
 //BA.debugLineNum = 251;BA.debugLine="icon2.Top = Activity.Top + 200dip";
mostCurrent._icon2.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 252;BA.debugLine="icon3.Left = Activity.Left + 150dip";
mostCurrent._icon3.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))));
 //BA.debugLineNum = 253;BA.debugLine="icon3.Top = Activity.Top +  100dip";
mostCurrent._icon3.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 254;BA.debugLine="icon4.Left = Activity.Left + 150dip";
mostCurrent._icon4.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (150))));
 //BA.debugLineNum = 255;BA.debugLine="icon4.Top = Activity.Top +  200dip";
mostCurrent._icon4.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 256;BA.debugLine="icon5.Left = Activity.Left + 50dip";
mostCurrent._icon5.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (50))));
 //BA.debugLineNum = 257;BA.debugLine="icon5.Top = Activity.Top +  100dip";
mostCurrent._icon5.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (100))));
 //BA.debugLineNum = 258;BA.debugLine="icon6.Left = Activity.Left + 250dip";
mostCurrent._icon6.setLeft((int) (mostCurrent._activity.getLeft()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (250))));
 //BA.debugLineNum = 259;BA.debugLine="icon6.Top = Activity.Top +  200dip";
mostCurrent._icon6.setTop((int) (mostCurrent._activity.getTop()+anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (200))));
 //BA.debugLineNum = 260;BA.debugLine="End Sub";
return "";
}
public static String  _showsplashscreen() throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Sub ShowSplashScreen";
 //BA.debugLineNum = 117;BA.debugLine="pnlShading.Visible = False";
mostCurrent._pnlshading.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 118;BA.debugLine="pnlSelectionLeft.Left = 0 - pnlSelectionLeft.Width";
mostCurrent._pnlselectionleft.setLeft((int) (0-mostCurrent._pnlselectionleft.getWidth()));
 //BA.debugLineNum = 119;BA.debugLine="pnlSelectionRight.Left = 100%x";
mostCurrent._pnlselectionright.setLeft(anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA));
 //BA.debugLineNum = 120;BA.debugLine="UpdateLabels";
_updatelabels();
 //BA.debugLineNum = 121;BA.debugLine="AnimateCharacters";
_animatecharacters();
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public static String  _spnplayers_itemclick(int _position,Object _value) throws Exception{
int _currentitem = 0;
int _iloop = 0;
 //BA.debugLineNum = 954;BA.debugLine="Sub spnPlayers_ItemClick (Position As Int, Value As Object)";
 //BA.debugLineNum = 955;BA.debugLine="Dim currentItem As Int = spnDroids.SelectedItem";
_currentitem = (int)(Double.parseDouble(mostCurrent._spndroids.getSelectedItem()));
 //BA.debugLineNum = 956;BA.debugLine="numberOfPlayers = Value";
_numberofplayers = (int)(BA.ObjectToNumber(_value));
 //BA.debugLineNum = 957;BA.debugLine="spnDroids.Clear";
mostCurrent._spndroids.Clear();
 //BA.debugLineNum = 958;BA.debugLine="Dim iLoop As Int";
_iloop = 0;
 //BA.debugLineNum = 959;BA.debugLine="For iLoop = 0 To numberOfPlayers - 1";
{
final int step799 = 1;
final int limit799 = (int) (_numberofplayers-1);
for (_iloop = (int) (0); (step799 > 0 && _iloop <= limit799) || (step799 < 0 && _iloop >= limit799); _iloop = ((int)(0 + _iloop + step799))) {
 //BA.debugLineNum = 960;BA.debugLine="spnDroids.Add(iLoop)";
mostCurrent._spndroids.Add(BA.NumberToString(_iloop));
 }
};
 //BA.debugLineNum = 962;BA.debugLine="For iLoop = 0 To spnDroids.Size - 1";
{
final int step802 = 1;
final int limit802 = (int) (mostCurrent._spndroids.getSize()-1);
for (_iloop = (int) (0); (step802 > 0 && _iloop <= limit802) || (step802 < 0 && _iloop >= limit802); _iloop = ((int)(0 + _iloop + step802))) {
 //BA.debugLineNum = 963;BA.debugLine="spnDroids.SelectedIndex = iLoop";
mostCurrent._spndroids.setSelectedIndex(_iloop);
 //BA.debugLineNum = 964;BA.debugLine="If spnDroids.SelectedItem = currentItem Then";
if ((mostCurrent._spndroids.getSelectedItem()).equals(BA.NumberToString(_currentitem))) { 
 //BA.debugLineNum = 965;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 968;BA.debugLine="If spnDroids.SelectedItem = -1 Then";
if ((mostCurrent._spndroids.getSelectedItem()).equals(BA.NumberToString(-1))) { 
 //BA.debugLineNum = 969;BA.debugLine="spnDroids.SelectedIndex = 0";
mostCurrent._spndroids.setSelectedIndex((int) (0));
 };
 //BA.debugLineNum = 971;BA.debugLine="End Sub";
return "";
}
public static pineysoft.squarepaddocks.gamesquare  _subgetoppositesquare(pineysoft.squarepaddocks.gamesquare _square,int _side) throws Exception{
pineysoft.squarepaddocks.gamesquare _othersquare = null;
 //BA.debugLineNum = 809;BA.debugLine="Sub SubGetOppositeSquare(square As GameSquare, side As Int) As GameSquare";
 //BA.debugLineNum = 810;BA.debugLine="Dim otherSquare As GameSquare";
_othersquare = new pineysoft.squarepaddocks.gamesquare();
 //BA.debugLineNum = 811;BA.debugLine="Select side";
switch (BA.switchObjectToInt(_side,_spconstants._top_side,_spconstants._right_side,_spconstants._bottom_side,_spconstants._left_side)) {
case 0:
 //BA.debugLineNum = 813;BA.debugLine="If square.RowPos > 0 Then";
if (_square._rowpos>0) { 
 //BA.debugLineNum = 814;BA.debugLine="otherSquare = gameSquares(square.RowPos - 1, square.ColPos)";
_othersquare = mostCurrent._gamesquares[(int) (_square._rowpos-1)][_square._colpos];
 };
 break;
case 1:
 //BA.debugLineNum = 817;BA.debugLine="If square.ColPos < gameWidth - 1 Then";
if (_square._colpos<_gamewidth-1) { 
 //BA.debugLineNum = 818;BA.debugLine="otherSquare = gameSquares(square.RowPos, square.ColPos + 1)";
_othersquare = mostCurrent._gamesquares[_square._rowpos][(int) (_square._colpos+1)];
 };
 break;
case 2:
 //BA.debugLineNum = 821;BA.debugLine="If square.RowPos < gameHeight - 1 Then";
if (_square._rowpos<_gameheight-1) { 
 //BA.debugLineNum = 822;BA.debugLine="otherSquare = gameSquares(square.RowPos + 1, square.ColPos)";
_othersquare = mostCurrent._gamesquares[(int) (_square._rowpos+1)][_square._colpos];
 };
 break;
case 3:
 //BA.debugLineNum = 825;BA.debugLine="If square.RowPos > 0  Then";
if (_square._rowpos>0) { 
 //BA.debugLineNum = 826;BA.debugLine="otherSquare = gameSquares(square.RowPos, square.ColPos - 1)";
_othersquare = mostCurrent._gamesquares[_square._rowpos][(int) (_square._colpos-1)];
 };
 break;
}
;
 //BA.debugLineNum = 830;BA.debugLine="Return otherSquare";
if (true) return _othersquare;
 //BA.debugLineNum = 831;BA.debugLine="End Sub";
return null;
}
public static String  _takedoubles() throws Exception{
anywheresoftware.b4a.objects.collections.List _found3s = null;
int _closeside = 0;
pineysoft.squarepaddocks.gamesquare _currentsquare = null;
 //BA.debugLineNum = 708;BA.debugLine="Public Sub TakeDoubles";
 //BA.debugLineNum = 709;BA.debugLine="Dim found3s As List";
_found3s = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 710;BA.debugLine="Dim closeSide As Int = -1";
_closeside = (int) (-1);
 //BA.debugLineNum = 712;BA.debugLine="found3s = FindAllForSides(3)";
_found3s = _findallforsides((int) (3));
 //BA.debugLineNum = 714;BA.debugLine="For Each currentSquare As GameSquare In found3s";
final anywheresoftware.b4a.BA.IterableList group597 = _found3s;
final int groupLen597 = group597.getSize();
for (int index597 = 0;index597 < groupLen597 ;index597++){
_currentsquare = (pineysoft.squarepaddocks.gamesquare)(group597.Get(index597));
 //BA.debugLineNum = 715;BA.debugLine="If currentSquare.IsSideTaken(SPConstants.LEFT_SIDE) = False Then";
if (_currentsquare._issidetaken(_spconstants._left_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 716;BA.debugLine="If currentSquare.ColPos = 0 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos - 1).sidesTaken = 2 Then";
if (_currentsquare._colpos==0 || mostCurrent._gamesquares[_currentsquare._rowpos][(int) (_currentsquare._colpos-1)]._sidestaken==2) { 
 //BA.debugLineNum = 717;BA.debugLine="closeSide = SPConstants.LEFT_SIDE";
_closeside = _spconstants._left_side;
 };
 }else if(_currentsquare._issidetaken(_spconstants._right_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 720;BA.debugLine="If currentSquare.ColPos = gameWidth - 1 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos + 1).sidesTaken = 2 Then";
if (_currentsquare._colpos==_gamewidth-1 || mostCurrent._gamesquares[_currentsquare._rowpos][(int) (_currentsquare._colpos+1)]._sidestaken==2) { 
 //BA.debugLineNum = 721;BA.debugLine="closeSide = SPConstants.RIGHT_SIDE";
_closeside = _spconstants._right_side;
 };
 }else if(_currentsquare._issidetaken(_spconstants._top_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 724;BA.debugLine="If currentSquare.RowPos = 0 OR gameSquares(currentSquare.RowPos - 1, currentSquare.ColPos).sidesTaken = 2 Then";
if (_currentsquare._rowpos==0 || mostCurrent._gamesquares[(int) (_currentsquare._rowpos-1)][_currentsquare._colpos]._sidestaken==2) { 
 //BA.debugLineNum = 725;BA.debugLine="closeSide = SPConstants.TOP_SIDE";
_closeside = _spconstants._top_side;
 };
 }else if(_currentsquare._issidetaken(_spconstants._bottom_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 728;BA.debugLine="If currentSquare.RowPos = gameHeight - 1 OR gameSquares(currentSquare.RowPos + 1, currentSquare.ColPos).sidesTaken = 2 Then";
if (_currentsquare._rowpos==_gameheight-1 || mostCurrent._gamesquares[(int) (_currentsquare._rowpos+1)][_currentsquare._colpos]._sidestaken==2) { 
 //BA.debugLineNum = 729;BA.debugLine="closeSide = SPConstants.BOTTOM_SIDE";
_closeside = _spconstants._bottom_side;
 };
 };
 //BA.debugLineNum = 733;BA.debugLine="If closeSide = -1 Then Return";
if (_closeside==-1) { 
if (true) return "";};
 //BA.debugLineNum = 736;BA.debugLine="UpdateTurn(canv, currentSquare, closeSide)";
_updateturn(mostCurrent._canv,_currentsquare,_closeside);
 //BA.debugLineNum = 739;BA.debugLine="currentSquare.TakeSide(canv,closeSide)";
_currentsquare._takeside(mostCurrent._canv,_closeside);
 //BA.debugLineNum = 742;BA.debugLine="MarkOtherSide2(currentSquare, closeSide)";
_markotherside2(_currentsquare,_closeside);
 }
;
 //BA.debugLineNum = 746;BA.debugLine="End Sub";
return "";
}
public static boolean  _takeeasy3s(anywheresoftware.b4a.objects.collections.List _found3s,pineysoft.squarepaddocks.player _currplayer) throws Exception{
int _closeside = 0;
pineysoft.squarepaddocks.gamesquare _currentsquare = null;
 //BA.debugLineNum = 667;BA.debugLine="Public Sub TakeEasy3s(found3s As List, currPlayer As Player) As Boolean";
 //BA.debugLineNum = 668;BA.debugLine="Dim closeSide As Int = -1";
_closeside = (int) (-1);
 //BA.debugLineNum = 670;BA.debugLine="Log(\"Checking Found 3's\")";
anywheresoftware.b4a.keywords.Common.Log("Checking Found 3's");
 //BA.debugLineNum = 671;BA.debugLine="For Each currentSquare As GameSquare In found3s";
final anywheresoftware.b4a.BA.IterableList group565 = _found3s;
final int groupLen565 = group565.getSize();
for (int index565 = 0;index565 < groupLen565 ;index565++){
_currentsquare = (pineysoft.squarepaddocks.gamesquare)(group565.Get(index565));
 //BA.debugLineNum = 672;BA.debugLine="closeSide = -1";
_closeside = (int) (-1);
 //BA.debugLineNum = 673;BA.debugLine="Log(\"Row: \" & currentSquare.RowPos & \" Column: \" & currentSquare.ColPos)";
anywheresoftware.b4a.keywords.Common.Log("Row: "+BA.NumberToString(_currentsquare._rowpos)+" Column: "+BA.NumberToString(_currentsquare._colpos));
 //BA.debugLineNum = 674;BA.debugLine="If currentSquare.IsSideTaken(SPConstants.LEFT_SIDE) = False Then";
if (_currentsquare._issidetaken(_spconstants._left_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 675;BA.debugLine="If currentSquare.ColPos = 0 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos - 1).sidesTaken <> 2 Then";
if (_currentsquare._colpos==0 || mostCurrent._gamesquares[_currentsquare._rowpos][(int) (_currentsquare._colpos-1)]._sidestaken!=2) { 
 //BA.debugLineNum = 676;BA.debugLine="closeSide = SPConstants.LEFT_SIDE";
_closeside = _spconstants._left_side;
 };
 }else if(_currentsquare._issidetaken(_spconstants._right_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 679;BA.debugLine="If currentSquare.ColPos = gameWidth - 1 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos + 1).sidesTaken <> 2 Then";
if (_currentsquare._colpos==_gamewidth-1 || mostCurrent._gamesquares[_currentsquare._rowpos][(int) (_currentsquare._colpos+1)]._sidestaken!=2) { 
 //BA.debugLineNum = 680;BA.debugLine="closeSide = SPConstants.RIGHT_SIDE";
_closeside = _spconstants._right_side;
 };
 }else if(_currentsquare._issidetaken(_spconstants._top_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 683;BA.debugLine="If currentSquare.RowPos = 0 OR gameSquares(currentSquare.RowPos - 1, currentSquare.ColPos).sidesTaken <> 2 Then";
if (_currentsquare._rowpos==0 || mostCurrent._gamesquares[(int) (_currentsquare._rowpos-1)][_currentsquare._colpos]._sidestaken!=2) { 
 //BA.debugLineNum = 684;BA.debugLine="closeSide = SPConstants.TOP_SIDE";
_closeside = _spconstants._top_side;
 };
 }else if(_currentsquare._issidetaken(_spconstants._bottom_side)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 687;BA.debugLine="If currentSquare.RowPos = gameHeight - 1 OR gameSquares(currentSquare.RowPos + 1, currentSquare.ColPos).sidesTaken <> 2 Then";
if (_currentsquare._rowpos==_gameheight-1 || mostCurrent._gamesquares[(int) (_currentsquare._rowpos+1)][_currentsquare._colpos]._sidestaken!=2) { 
 //BA.debugLineNum = 688;BA.debugLine="closeSide = SPConstants.BOTTOM_SIDE";
_closeside = _spconstants._bottom_side;
 };
 };
 //BA.debugLineNum = 692;BA.debugLine="If closeSide = -1 Then Return False";
if (_closeside==-1) { 
if (true) return anywheresoftware.b4a.keywords.Common.False;};
 //BA.debugLineNum = 695;BA.debugLine="UpdateTurn(canv, currentSquare, closeSide)";
_updateturn(mostCurrent._canv,_currentsquare,_closeside);
 //BA.debugLineNum = 698;BA.debugLine="currentSquare.TakeSide(canv,closeSide)";
_currentsquare._takeside(mostCurrent._canv,_closeside);
 //BA.debugLineNum = 701;BA.debugLine="MarkOtherSide2(currentSquare, closeSide)";
_markotherside2(_currentsquare,_closeside);
 }
;
 //BA.debugLineNum = 704;BA.debugLine="Log(\"Finished Checking Found 3's\")";
anywheresoftware.b4a.keywords.Common.Log("Finished Checking Found 3's");
 //BA.debugLineNum = 705;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 706;BA.debugLine="End Sub";
return false;
}
public static boolean  _takesingle(anywheresoftware.b4a.objects.collections.List _foundvalids,boolean _forceany) throws Exception{
int _rndnum = 0;
boolean _foundside = false;
int _rndside = 0;
int _loopcount = 0;
int _loopcountinner = 0;
pineysoft.squarepaddocks.gamesquare _foundsquare = null;
int _sides = 0;
 //BA.debugLineNum = 748;BA.debugLine="Sub TakeSingle(foundValids As List, forceAny As Boolean) As Boolean";
 //BA.debugLineNum = 749;BA.debugLine="Dim rndnum As Int";
_rndnum = 0;
 //BA.debugLineNum = 750;BA.debugLine="Dim foundSide As Boolean = False";
_foundside = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 751;BA.debugLine="Dim rndSide As Int";
_rndside = 0;
 //BA.debugLineNum = 752;BA.debugLine="Dim loopCount As Int";
_loopcount = 0;
 //BA.debugLineNum = 753;BA.debugLine="Dim loopCountInner As Int";
_loopcountinner = 0;
 //BA.debugLineNum = 755;BA.debugLine="Do While foundSide = False AND loopCount < 50";
while (_foundside==anywheresoftware.b4a.keywords.Common.False && _loopcount<50) {
 //BA.debugLineNum = 756;BA.debugLine="loopCountInner = 0";
_loopcountinner = (int) (0);
 //BA.debugLineNum = 757;BA.debugLine="If foundValids.Size > 0 Then";
if (_foundvalids.getSize()>0) { 
 //BA.debugLineNum = 758;BA.debugLine="If foundValids.Size > 1 Then";
if (_foundvalids.getSize()>1) { 
 //BA.debugLineNum = 759;BA.debugLine="rndnum = Rnd(1, foundValids.Size)";
_rndnum = anywheresoftware.b4a.keywords.Common.Rnd((int) (1),_foundvalids.getSize());
 }else {
 //BA.debugLineNum = 761;BA.debugLine="rndnum = 1";
_rndnum = (int) (1);
 };
 //BA.debugLineNum = 764;BA.debugLine="Dim foundSquare As GameSquare = foundValids.Get(rndnum - 1)";
_foundsquare = (pineysoft.squarepaddocks.gamesquare)(_foundvalids.Get((int) (_rndnum-1)));
 //BA.debugLineNum = 766;BA.debugLine="Do While foundSide = False AND loopCountInner < 8";
while (_foundside==anywheresoftware.b4a.keywords.Common.False && _loopcountinner<8) {
 //BA.debugLineNum = 767;BA.debugLine="rndSide = Rnd(1,4) - 1";
_rndside = (int) (anywheresoftware.b4a.keywords.Common.Rnd((int) (1),(int) (4))-1);
 //BA.debugLineNum = 768;BA.debugLine="If foundSquare.IsSideTaken(rndSide) = False Then";
if (_foundsquare._issidetaken(_rndside)==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 769;BA.debugLine="If forceAny = True Then";
if (_forceany==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 770;BA.debugLine="foundSide = True";
_foundside = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 772;BA.debugLine="Dim sides As Int = GetOtherSideSquareSides(foundSquare, rndSide)";
_sides = _getothersidesquaresides(_foundsquare,_rndside);
 //BA.debugLineNum = 773;BA.debugLine="If sides < 2 Then";
if (_sides<2) { 
 //BA.debugLineNum = 774;BA.debugLine="foundSide = True";
_foundside = anywheresoftware.b4a.keywords.Common.True;
 };
 };
 };
 //BA.debugLineNum = 778;BA.debugLine="loopCountInner = loopCountInner + 1";
_loopcountinner = (int) (_loopcountinner+1);
 //BA.debugLineNum = 779;BA.debugLine="Log(\"loop count inner is \" & loopCountInner)";
anywheresoftware.b4a.keywords.Common.Log("loop count inner is "+BA.NumberToString(_loopcountinner));
 }
;
 //BA.debugLineNum = 782;BA.debugLine="If foundSide = True Then";
if (_foundside==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 783;BA.debugLine="UpdateTurn(canv, foundSquare, rndSide)";
_updateturn(mostCurrent._canv,_foundsquare,_rndside);
 //BA.debugLineNum = 785;BA.debugLine="foundSquare.TakeSide(canv, rndSide)";
_foundsquare._takeside(mostCurrent._canv,_rndside);
 //BA.debugLineNum = 787;BA.debugLine="MarkOtherSide2(foundSquare, rndSide)";
_markotherside2(_foundsquare,_rndside);
 };
 };
 //BA.debugLineNum = 790;BA.debugLine="loopCount = loopCount + 1";
_loopcount = (int) (_loopcount+1);
 //BA.debugLineNum = 791;BA.debugLine="Log(\"loop count is \" & loopCount)";
anywheresoftware.b4a.keywords.Common.Log("loop count is "+BA.NumberToString(_loopcount));
 }
;
 //BA.debugLineNum = 794;BA.debugLine="Return foundSide";
if (true) return _foundside;
 //BA.debugLineNum = 795;BA.debugLine="End Sub";
return false;
}
public static String  _updatelabels() throws Exception{
 //BA.debugLineNum = 296;BA.debugLine="Sub UpdateLabels";
 //BA.debugLineNum = 297;BA.debugLine="lblRows.Text = \"Rows : \" & (sbRows.Value + 4)";
mostCurrent._lblrows.setText((Object)("Rows : "+BA.NumberToString((mostCurrent._sbrows.getValue()+4))));
 //BA.debugLineNum = 298;BA.debugLine="lblColumns.Text = \"Columns : \" & (sbColumns.Value + 4)";
mostCurrent._lblcolumns.setText((Object)("Columns : "+BA.NumberToString((mostCurrent._sbcolumns.getValue()+4))));
 //BA.debugLineNum = 299;BA.debugLine="End Sub";
return "";
}
public static String  _updateplayernumber() throws Exception{
 //BA.debugLineNum = 498;BA.debugLine="Sub UpdatePlayerNumber";
 //BA.debugLineNum = 499;BA.debugLine="currentPlayer = currentPlayer + 1";
_currentplayer = (short) (_currentplayer+1);
 //BA.debugLineNum = 500;BA.debugLine="If currentPlayer > numberOfPlayers - 1 Then currentPlayer = 0";
if (_currentplayer>_numberofplayers-1) { 
_currentplayer = (short) (0);};
 //BA.debugLineNum = 501;BA.debugLine="End Sub";
return "";
}
public static String  _updatescore(pineysoft.squarepaddocks.player _currplayer) throws Exception{
anywheresoftware.b4a.objects.ConcreteViewWrapper _temp = null;
anywheresoftware.b4a.objects.LabelWrapper _lbl = null;
 //BA.debugLineNum = 474;BA.debugLine="Sub UpdateScore(currPlayer As Player)";
 //BA.debugLineNum = 475;BA.debugLine="Dim temp As View = GetViewByTag1(pnlBase, \"P\" & (currentPlayer + 1))";
_temp = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
_temp = _getviewbytag1((anywheresoftware.b4a.objects.ActivityWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.ActivityWrapper(), (anywheresoftware.b4a.BALayout)(mostCurrent._pnlbase.getObject())),"P"+BA.NumberToString((_currentplayer+1)));
 //BA.debugLineNum = 476;BA.debugLine="If temp Is Label Then";
if (_temp.getObjectOrNull() instanceof android.widget.TextView) { 
 //BA.debugLineNum = 477;BA.debugLine="Dim lbl As Label = temp";
_lbl = new anywheresoftware.b4a.objects.LabelWrapper();
_lbl.setObject((android.widget.TextView)(_temp.getObject()));
 //BA.debugLineNum = 478;BA.debugLine="lbl.Text = \"Player \" & (currentPlayer + 1) & \" : \" & currPlayer.Score";
_lbl.setText((Object)("Player "+BA.NumberToString((_currentplayer+1))+" : "+BA.NumberToString(_currplayer._score)));
 };
 //BA.debugLineNum = 480;BA.debugLine="End Sub";
return "";
}
public static String  _updateturn(anywheresoftware.b4a.objects.drawable.CanvasWrapper _cnv,pineysoft.squarepaddocks.gamesquare _currentsquare,int _chosenside) throws Exception{
pineysoft.squarepaddocks.turn _lastturn = null;
pineysoft.squarepaddocks.turn _newturn = null;
 //BA.debugLineNum = 482;BA.debugLine="Sub UpdateTurn(cnv As Canvas, currentSquare As GameSquare, chosenSide As Int)";
 //BA.debugLineNum = 483;BA.debugLine="Dim lastTurn As Turn";
_lastturn = new pineysoft.squarepaddocks.turn();
 //BA.debugLineNum = 484;BA.debugLine="Dim newTurn As Turn";
_newturn = new pineysoft.squarepaddocks.turn();
 //BA.debugLineNum = 487;BA.debugLine="If gameTurns.Size > 0 Then";
if (mostCurrent._gameturns.getSize()>0) { 
 //BA.debugLineNum = 488;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
_lastturn = (pineysoft.squarepaddocks.turn)(mostCurrent._gameturns.Get((int) (mostCurrent._gameturns.getSize()-1)));
 //BA.debugLineNum = 489;BA.debugLine="lastTurn.Square.DrawEdge2(canv,lastTurn.Edge,Colors.LightGray)";
_lastturn._square._drawedge2(mostCurrent._canv,_lastturn._edge,anywheresoftware.b4a.keywords.Common.Colors.LightGray);
 };
 //BA.debugLineNum = 493;BA.debugLine="newTurn.Initialize(currentSquare, chosenSide, currentPlayer)";
_newturn._initialize(mostCurrent.activityBA,_currentsquare,_chosenside,(int) (_currentplayer));
 //BA.debugLineNum = 496;BA.debugLine="gameTurns.Add(newTurn)";
mostCurrent._gameturns.Add((Object)(_newturn));
 //BA.debugLineNum = 497;BA.debugLine="End Sub";
return "";
}
}
