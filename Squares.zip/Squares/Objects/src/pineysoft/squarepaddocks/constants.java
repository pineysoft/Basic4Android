package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class constants extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new anywheresoftware.b4a.ShellBA(_ba, this, htSubs, "pineysoft.squarepaddocks.constants");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            if (BA.isShellModeRuntimeCheck(ba)) {
			    ba.raiseEvent2(null, true, "CREATE", true, "pineysoft.squarepaddocks.constants",
                    ba);
                return;
		    }
        }
        ba.raiseEvent2(null, true, "class_globals", false);
    }

 
    public void  innerInitializeHelper(anywheresoftware.b4a.BA _ba) throws Exception{
        innerInitialize(_ba);
    }
    public Object callSub(String sub, Object sender, Object[] args) throws Exception {
        return BA.SubDelegator.SubNotFound;
    }
public anywheresoftware.b4a.keywords.Common __c = null;
public int _player_type_human = 0;
public int _player_type_droid = 0;
public int _top_side = 0;
public int _right_side = 0;
public int _bottom_side = 0;
public int _left_side = 0;
public int _horizontal = 0;
public int _vertical = 0;
public int _vacant = 0;
public int _occupied = 0;
public char _side_taken = '\0';
public char _side_available = '\0';
public int _bg_colour = 0;
public int _current_side_colour = 0;
public pineysoft.squarepaddocks.main _main = null;
public String  _initialize(pineysoft.squarepaddocks.constants __ref,anywheresoftware.b4a.BA _ba) throws Exception{
__ref = this;
innerInitialize(_ba);
RDebugUtils.currentModule="constants";
RDebugUtils.currentLine=3014656;
 //BA.debugLineNum = 3014656;BA.debugLine="Public Sub Initialize";
RDebugUtils.currentLine=3014657;
 //BA.debugLineNum = 3014657;BA.debugLine="PLAYER_TYPE_HUMAN = 0";
__ref._player_type_human = (int) (0);
RDebugUtils.currentLine=3014658;
 //BA.debugLineNum = 3014658;BA.debugLine="PLAYER_TYPE_DROID = 1";
__ref._player_type_droid = (int) (1);
RDebugUtils.currentLine=3014660;
 //BA.debugLineNum = 3014660;BA.debugLine="TOP_SIDE = 0";
__ref._top_side = (int) (0);
RDebugUtils.currentLine=3014661;
 //BA.debugLineNum = 3014661;BA.debugLine="RIGHT_SIDE = 1";
__ref._right_side = (int) (1);
RDebugUtils.currentLine=3014662;
 //BA.debugLineNum = 3014662;BA.debugLine="BOTTOM_SIDE = 2";
__ref._bottom_side = (int) (2);
RDebugUtils.currentLine=3014663;
 //BA.debugLineNum = 3014663;BA.debugLine="LEFT_SIDE = 3";
__ref._left_side = (int) (3);
RDebugUtils.currentLine=3014665;
 //BA.debugLineNum = 3014665;BA.debugLine="SIDE_TAKEN = \"X\"";
__ref._side_taken = BA.ObjectToChar("X");
RDebugUtils.currentLine=3014666;
 //BA.debugLineNum = 3014666;BA.debugLine="SIDE_AVAILABLE = \"O\"";
__ref._side_available = BA.ObjectToChar("O");
RDebugUtils.currentLine=3014669;
 //BA.debugLineNum = 3014669;BA.debugLine="VACANT = 0";
__ref._vacant = (int) (0);
RDebugUtils.currentLine=3014670;
 //BA.debugLineNum = 3014670;BA.debugLine="OCCUPIED = 1";
__ref._occupied = (int) (1);
RDebugUtils.currentLine=3014672;
 //BA.debugLineNum = 3014672;BA.debugLine="HORIZONTAL = 0";
__ref._horizontal = (int) (0);
RDebugUtils.currentLine=3014673;
 //BA.debugLineNum = 3014673;BA.debugLine="VERTICAL = 1";
__ref._vertical = (int) (1);
RDebugUtils.currentLine=3014675;
 //BA.debugLineNum = 3014675;BA.debugLine="End Sub";
return "";
}
}