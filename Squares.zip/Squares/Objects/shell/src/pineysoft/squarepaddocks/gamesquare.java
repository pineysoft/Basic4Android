
package pineysoft.squarepaddocks;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;

public class gamesquare implements IRemote{
	public static gamesquare mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public gamesquare() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
public boolean isSingleton() {
		return false;
	}
    public static PCBA staticBA = new PCBA(null, gamesquare.class, null);
    private PCBA pcBA;
    public RemoteObject ba;
    public RemoteObject ref;
	public RemoteObject runMethod(boolean notUsed, String method, Object... args) throws Exception{
		return (RemoteObject) pcBA.raiseEvent(method.substring(1), RemoteObject.addItemToArray(ref, args));
	}
    public void runVoidMethod(String method, Object... args) throws Exception{
		runMethod(false, method, args);
	}
	public PCBA create(Object[] args) throws ClassNotFoundException{
        ref = (RemoteObject) args[0];
        ba = (RemoteObject) args[2];
		pcBA = new PCBA(this, gamesquare.class, ba);
		return pcBA;
	}


public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _colpos = RemoteObject.createImmutable(0);
public static RemoteObject _rowpos = RemoteObject.createImmutable(0);
public static RemoteObject _topleft = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
public static RemoteObject _topright = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
public static RemoteObject _bottomleft = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
public static RemoteObject _bottomright = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
public static RemoteObject _sides = null;
public static RemoteObject _occupied = RemoteObject.createImmutable(false);
public static RemoteObject _spconstants = RemoteObject.declareNull("pineysoft.squarepaddocks.constants");
public static RemoteObject _sidestaken = RemoteObject.createImmutable(0);
public static RemoteObject _filllabel = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static pineysoft.squarepaddocks.main _main = null;
public static Object[] GetGlobals(RemoteObject _ref) throws Exception {
		return new Object[] {"BottomLeft",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_bottomleft"),"BottomRight",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_bottomright"),"ColPos",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_colpos"),"fillLabel",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_filllabel"),"Occupied",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_occupied"),"RowPos",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_rowpos"),"sides",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_sides"),"sidesTaken",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_sidestaken"),"SpConstants",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_spconstants"),"TopLeft",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_topleft"),"TopRight",_ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false, "_topright")};
}
}