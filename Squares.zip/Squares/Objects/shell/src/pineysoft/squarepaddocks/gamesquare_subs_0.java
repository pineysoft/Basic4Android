package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class gamesquare_subs_0 {


public static RemoteObject  _calculateclosestedge(RemoteObject __ref,RemoteObject _xypos) throws Exception{
try {
		Debug.PushSubsStack("CalculateClosestEdge (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("calculateclosestedge")) return __ref.runUserSub(false, "gamesquare","calculateclosestedge", __ref, _xypos);
RemoteObject _deltax = RemoteObject.createImmutable(0);
RemoteObject _deltay = RemoteObject.createImmutable(0);
RemoteObject _deg = RemoteObject.createImmutable(0);
Debug.locals.put("xypos", _xypos);
 BA.debugLineNum = 31;BA.debugLine="Public Sub CalculateClosestEdge(xypos As Point) As Int";
Debug.ShouldStop(1073741824);
 BA.debugLineNum = 32;BA.debugLine="Dim deltax As Double";
Debug.ShouldStop(-2147483648);
_deltax = RemoteObject.createImmutable(0);Debug.locals.put("deltax", _deltax);
 BA.debugLineNum = 33;BA.debugLine="Dim deltaY As Double";
Debug.ShouldStop(1);
_deltay = RemoteObject.createImmutable(0);Debug.locals.put("deltaY", _deltay);
 BA.debugLineNum = 34;BA.debugLine="Dim deg As Double";
Debug.ShouldStop(2);
_deg = RemoteObject.createImmutable(0);Debug.locals.put("deg", _deg);
 BA.debugLineNum = 37;BA.debugLine="If xypos.Pos1 < TopLeft.Pos1 + (TopRight.Pos1 - TopLeft.Pos1) / 2 Then";
Debug.ShouldStop(16);
if (RemoteObject.solveBoolean("<",_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),(RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1")}, "-",1, 1)),RemoteObject.createImmutable(2)}, "+/",1, 0))) { 
 BA.debugLineNum = 38;BA.debugLine="If xypos.Pos2 < (TopLeft.Pos2 + (BottomLeft.Pos2 - TopLeft.Pos2) / 2) Then";
Debug.ShouldStop(32);
if (RemoteObject.solveBoolean("<",_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),(RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),(RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2")}, "-",1, 1)),RemoteObject.createImmutable(2)}, "+/",1, 0)))) { 
 BA.debugLineNum = 39;BA.debugLine="deltax = TopLeft.Pos1 - xypos.Pos1";
Debug.ShouldStop(64);
_deltax = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1")}, "-",1, 1));Debug.locals.put("deltax", _deltax);
 BA.debugLineNum = 40;BA.debugLine="deltaY = TopLeft.Pos2 - xypos.Pos2";
Debug.ShouldStop(128);
_deltay = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2")}, "-",1, 1));Debug.locals.put("deltaY", _deltay);
 BA.debugLineNum = 41;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
Debug.ShouldStop(256);
_deg = RemoteObject.solve(new RemoteObject[] {gamesquare.__c.runMethod(true,"ATan2",(Object)(_deltay),(Object)(_deltax)),(RemoteObject.solve(new RemoteObject[] {RemoteObject.createImmutable(180),RemoteObject.createImmutable(3.14159265359)}, "/",0, 0))}, "*",0, 0);Debug.locals.put("deg", _deg);
 BA.debugLineNum = 42;BA.debugLine="Log(\"Top Left Deg = \" & deg)";
Debug.ShouldStop(512);
gamesquare.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Top Left Deg = "),_deg)));
 BA.debugLineNum = 43;BA.debugLine="If deg > -135 Then";
Debug.ShouldStop(1024);
if (RemoteObject.solveBoolean(">",_deg,BA.numberCast(double.class, -(double) (0 + 135)))) { 
 BA.debugLineNum = 44;BA.debugLine="Return SpConstants.LEFT_SIDE";
Debug.ShouldStop(2048);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side");
 }else {
 BA.debugLineNum = 46;BA.debugLine="Return SpConstants.TOP_SIDE";
Debug.ShouldStop(8192);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side");
 };
 }else {
 BA.debugLineNum = 49;BA.debugLine="deltax = BottomLeft.Pos1 - xypos.Pos1";
Debug.ShouldStop(65536);
_deltax = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1")}, "-",1, 1));Debug.locals.put("deltax", _deltax);
 BA.debugLineNum = 50;BA.debugLine="deltaY = BottomLeft.Pos2 - xypos.Pos2";
Debug.ShouldStop(131072);
_deltay = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2")}, "-",1, 1));Debug.locals.put("deltaY", _deltay);
 BA.debugLineNum = 51;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
Debug.ShouldStop(262144);
_deg = RemoteObject.solve(new RemoteObject[] {gamesquare.__c.runMethod(true,"ATan2",(Object)(_deltay),(Object)(_deltax)),(RemoteObject.solve(new RemoteObject[] {RemoteObject.createImmutable(180),RemoteObject.createImmutable(3.14159265359)}, "/",0, 0))}, "*",0, 0);Debug.locals.put("deg", _deg);
 BA.debugLineNum = 52;BA.debugLine="Log(\"Bottom Left Deg = \" & deg)";
Debug.ShouldStop(524288);
gamesquare.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Bottom Left Deg = "),_deg)));
 BA.debugLineNum = 53;BA.debugLine="If deg > 135 Then";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean(">",_deg,BA.numberCast(double.class, 135))) { 
 BA.debugLineNum = 54;BA.debugLine="Return SpConstants.BOTTOM_SIDE";
Debug.ShouldStop(2097152);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side");
 }else {
 BA.debugLineNum = 56;BA.debugLine="Return SpConstants.LEFT_SIDE";
Debug.ShouldStop(8388608);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side");
 };
 };
 }else {
 BA.debugLineNum = 60;BA.debugLine="If xypos.Pos2 < (TopLeft.Pos2 + (BottomLeft.Pos2 - TopLeft.Pos2) / 2) Then";
Debug.ShouldStop(134217728);
if (RemoteObject.solveBoolean("<",_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),(RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),(RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2")}, "-",1, 1)),RemoteObject.createImmutable(2)}, "+/",1, 0)))) { 
 BA.debugLineNum = 61;BA.debugLine="deltax = TopRight.Pos1 - xypos.Pos1";
Debug.ShouldStop(268435456);
_deltax = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1")}, "-",1, 1));Debug.locals.put("deltax", _deltax);
 BA.debugLineNum = 62;BA.debugLine="deltaY = TopRight.Pos2 - xypos.Pos2";
Debug.ShouldStop(536870912);
_deltay = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2")}, "-",1, 1));Debug.locals.put("deltaY", _deltay);
 BA.debugLineNum = 63;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
Debug.ShouldStop(1073741824);
_deg = RemoteObject.solve(new RemoteObject[] {gamesquare.__c.runMethod(true,"ATan2",(Object)(_deltay),(Object)(_deltax)),(RemoteObject.solve(new RemoteObject[] {RemoteObject.createImmutable(180),RemoteObject.createImmutable(3.14159265359)}, "/",0, 0))}, "*",0, 0);Debug.locals.put("deg", _deg);
 BA.debugLineNum = 64;BA.debugLine="Log(\"Top Right Deg = \" & deg)";
Debug.ShouldStop(-2147483648);
gamesquare.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Top Right Deg = "),_deg)));
 BA.debugLineNum = 65;BA.debugLine="If deg < -45 Then";
Debug.ShouldStop(1);
if (RemoteObject.solveBoolean("<",_deg,BA.numberCast(double.class, -(double) (0 + 45)))) { 
 BA.debugLineNum = 66;BA.debugLine="Return SpConstants.RIGHT_SIDE";
Debug.ShouldStop(2);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side");
 }else {
 BA.debugLineNum = 68;BA.debugLine="Return SpConstants.TOP_SIDE";
Debug.ShouldStop(8);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side");
 };
 }else {
 BA.debugLineNum = 71;BA.debugLine="deltax = BottomRight.Pos1 - xypos.Pos1";
Debug.ShouldStop(64);
_deltax = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1")}, "-",1, 1));Debug.locals.put("deltax", _deltax);
 BA.debugLineNum = 72;BA.debugLine="deltaY = BottomRight.Pos2 - xypos.Pos2";
Debug.ShouldStop(128);
_deltay = BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),_xypos.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2")}, "-",1, 1));Debug.locals.put("deltaY", _deltay);
 BA.debugLineNum = 73;BA.debugLine="deg = ATan2(deltaY, deltax)* (180/ 3.14159265359)";
Debug.ShouldStop(256);
_deg = RemoteObject.solve(new RemoteObject[] {gamesquare.__c.runMethod(true,"ATan2",(Object)(_deltay),(Object)(_deltax)),(RemoteObject.solve(new RemoteObject[] {RemoteObject.createImmutable(180),RemoteObject.createImmutable(3.14159265359)}, "/",0, 0))}, "*",0, 0);Debug.locals.put("deg", _deg);
 BA.debugLineNum = 74;BA.debugLine="Log(\"Bottom Right Deg = \" & deg)";
Debug.ShouldStop(512);
gamesquare.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Bottom Right Deg = "),_deg)));
 BA.debugLineNum = 75;BA.debugLine="If deg < 45 Then";
Debug.ShouldStop(1024);
if (RemoteObject.solveBoolean("<",_deg,BA.numberCast(double.class, 45))) { 
 BA.debugLineNum = 76;BA.debugLine="Return SpConstants.BOTTOM_SIDE";
Debug.ShouldStop(2048);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side");
 }else {
 BA.debugLineNum = 78;BA.debugLine="Return SpConstants.RIGHT_SIDE";
Debug.ShouldStop(8192);
if (true) return __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side");
 };
 };
 };
 BA.debugLineNum = 83;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable(0);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Dim ColPos As Int";
gamesquare._colpos = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_colpos",gamesquare._colpos);
 //BA.debugLineNum = 4;BA.debugLine="Dim RowPos As Int";
gamesquare._rowpos = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_rowpos",gamesquare._rowpos);
 //BA.debugLineNum = 5;BA.debugLine="Dim TopLeft As Point";
gamesquare._topleft = RemoteObject.createNew ("pineysoft.squarepaddocks.point");__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_topleft",gamesquare._topleft);
 //BA.debugLineNum = 6;BA.debugLine="Dim TopRight As Point";
gamesquare._topright = RemoteObject.createNew ("pineysoft.squarepaddocks.point");__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_topright",gamesquare._topright);
 //BA.debugLineNum = 7;BA.debugLine="Dim BottomLeft As Point";
gamesquare._bottomleft = RemoteObject.createNew ("pineysoft.squarepaddocks.point");__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_bottomleft",gamesquare._bottomleft);
 //BA.debugLineNum = 8;BA.debugLine="Dim BottomRight As Point";
gamesquare._bottomright = RemoteObject.createNew ("pineysoft.squarepaddocks.point");__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_bottomright",gamesquare._bottomright);
 //BA.debugLineNum = 9;BA.debugLine="Dim sides(4) As Char";
gamesquare._sides = RemoteObject.createNewArray ("char", new int[] {4}, new Object[]{});__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_sides",gamesquare._sides);
 //BA.debugLineNum = 10;BA.debugLine="Dim Occupied As Boolean";
gamesquare._occupied = RemoteObject.createImmutable(false);__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_occupied",gamesquare._occupied);
 //BA.debugLineNum = 11;BA.debugLine="Dim SpConstants As Constants";
gamesquare._spconstants = RemoteObject.createNew ("pineysoft.squarepaddocks.constants");__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_spconstants",gamesquare._spconstants);
 //BA.debugLineNum = 12;BA.debugLine="Dim sidesTaken As Int";
gamesquare._sidestaken = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_sidestaken",gamesquare._sidestaken);
 //BA.debugLineNum = 13;BA.debugLine="Dim fillLabel As Label";
gamesquare._filllabel = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare","_filllabel",gamesquare._filllabel);
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _drawedge(RemoteObject __ref,RemoteObject _cnv,RemoteObject _startpoint,RemoteObject _endpoint,RemoteObject _color,RemoteObject _direction) throws Exception{
try {
		Debug.PushSubsStack("DrawEdge (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("drawedge")) return __ref.runUserSub(false, "gamesquare","drawedge", __ref, _cnv, _startpoint, _endpoint, _color, _direction);
RemoteObject _line = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
Debug.locals.put("cnv", _cnv);
Debug.locals.put("startPoint", _startpoint);
Debug.locals.put("endPoint", _endpoint);
Debug.locals.put("color", _color);
Debug.locals.put("direction", _direction);
 BA.debugLineNum = 107;BA.debugLine="Public Sub DrawEdge(cnv As Canvas, startPoint As Point, endPoint As Point, color As Int, direction As Int)";
Debug.ShouldStop(1024);
 BA.debugLineNum = 109;BA.debugLine="Dim line As Rect";
Debug.ShouldStop(4096);
_line = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");Debug.locals.put("line", _line);
 BA.debugLineNum = 110;BA.debugLine="If direction = SpConstants.VERTICAL Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",_direction,BA.numberCast(double.class, __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_vertical")))) { 
 BA.debugLineNum = 111;BA.debugLine="line.Initialize(startPoint.Pos1-2dip, startPoint.Pos2+4dip, endPoint.Pos1+2dip, endPoint.Pos2-4dip)";
Debug.ShouldStop(16384);
_line.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_startpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 2)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_startpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_endpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 2)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_endpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)));
 }else {
 BA.debugLineNum = 113;BA.debugLine="line.Initialize(startPoint.Pos1+4dip, startPoint.Pos2-2dip, endPoint.Pos1-4dip, endPoint.Pos2+2dip)";
Debug.ShouldStop(65536);
_line.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_startpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_startpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 2)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_endpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_endpoint.getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 2)))}, "+",1, 1)));
 };
 BA.debugLineNum = 116;BA.debugLine="cnv.DrawRect(line,color,True,2dip)";
Debug.ShouldStop(524288);
_cnv.runVoidMethod ("DrawRect",(Object)((_line.getObject())),(Object)(_color),(Object)(gamesquare.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, gamesquare.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 2))))));
 BA.debugLineNum = 117;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _drawedge2(RemoteObject __ref,RemoteObject _cnv,RemoteObject _side,RemoteObject _color) throws Exception{
try {
		Debug.PushSubsStack("DrawEdge2 (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("drawedge2")) return __ref.runUserSub(false, "gamesquare","drawedge2", __ref, _cnv, _side, _color);
RemoteObject _startpoint = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
RemoteObject _endpoint = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
RemoteObject _direction = RemoteObject.createImmutable(0);
Debug.locals.put("cnv", _cnv);
Debug.locals.put("side", _side);
Debug.locals.put("color", _color);
 BA.debugLineNum = 118;BA.debugLine="Public Sub DrawEdge2(cnv As Canvas, side As Int, color As Int)";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 119;BA.debugLine="Dim startPoint As Point";
Debug.ShouldStop(4194304);
_startpoint = RemoteObject.createNew ("pineysoft.squarepaddocks.point");Debug.locals.put("startPoint", _startpoint);
 BA.debugLineNum = 120;BA.debugLine="Dim endPoint As Point";
Debug.ShouldStop(8388608);
_endpoint = RemoteObject.createNew ("pineysoft.squarepaddocks.point");Debug.locals.put("endPoint", _endpoint);
 BA.debugLineNum = 121;BA.debugLine="Dim direction As Int";
Debug.ShouldStop(16777216);
_direction = RemoteObject.createImmutable(0);Debug.locals.put("direction", _direction);
 BA.debugLineNum = 122;BA.debugLine="Select side";
Debug.ShouldStop(33554432);
switch (BA.switchObjectToInt(_side,__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side"),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side"),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side"))) {
case 0:
 BA.debugLineNum = 124;BA.debugLine="startPoint = TopLeft";
Debug.ShouldStop(134217728);
_startpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft");Debug.locals.put("startPoint", _startpoint);
 BA.debugLineNum = 125;BA.debugLine="endPoint = TopRight";
Debug.ShouldStop(268435456);
_endpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright");Debug.locals.put("endPoint", _endpoint);
 BA.debugLineNum = 126;BA.debugLine="direction = SpConstants.HORIZONTAL";
Debug.ShouldStop(536870912);
_direction = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_horizontal");Debug.locals.put("direction", _direction);
 break;
case 1:
 BA.debugLineNum = 128;BA.debugLine="startPoint = TopRight";
Debug.ShouldStop(-2147483648);
_startpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright");Debug.locals.put("startPoint", _startpoint);
 BA.debugLineNum = 129;BA.debugLine="endPoint = BottomRight";
Debug.ShouldStop(1);
_endpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright");Debug.locals.put("endPoint", _endpoint);
 BA.debugLineNum = 130;BA.debugLine="direction = SpConstants.VERTICAL";
Debug.ShouldStop(2);
_direction = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_vertical");Debug.locals.put("direction", _direction);
 break;
case 2:
 BA.debugLineNum = 132;BA.debugLine="startPoint = BottomLeft";
Debug.ShouldStop(8);
_startpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft");Debug.locals.put("startPoint", _startpoint);
 BA.debugLineNum = 133;BA.debugLine="endPoint = BottomRight";
Debug.ShouldStop(16);
_endpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright");Debug.locals.put("endPoint", _endpoint);
 BA.debugLineNum = 134;BA.debugLine="direction = SpConstants.HORIZONTAL";
Debug.ShouldStop(32);
_direction = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_horizontal");Debug.locals.put("direction", _direction);
 break;
case 3:
 BA.debugLineNum = 136;BA.debugLine="startPoint = TopLeft";
Debug.ShouldStop(128);
_startpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft");Debug.locals.put("startPoint", _startpoint);
 BA.debugLineNum = 137;BA.debugLine="endPoint = BottomLeft";
Debug.ShouldStop(256);
_endpoint = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft");Debug.locals.put("endPoint", _endpoint);
 BA.debugLineNum = 138;BA.debugLine="direction = SpConstants.VERTICAL";
Debug.ShouldStop(512);
_direction = __ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_vertical");Debug.locals.put("direction", _direction);
 break;
}
;
 BA.debugLineNum = 141;BA.debugLine="DrawEdge(cnv,startPoint, endPoint, color, direction)";
Debug.ShouldStop(4096);
__ref.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_drawedge",(Object)(_cnv),(Object)(_startpoint),(Object)(_endpoint),(Object)(_color),(Object)(_direction));
 BA.debugLineNum = 142;BA.debugLine="End Sub";
Debug.ShouldStop(8192);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba,RemoteObject _x,RemoteObject _y,RemoteObject _width,RemoteObject _height,RemoteObject _row,RemoteObject _col) throws Exception{
try {
		Debug.PushSubsStack("Initialize (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("initialize")) return __ref.runUserSub(false, "gamesquare","initialize", __ref, _ba, _x, _y, _width, _height, _row, _col);
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
Debug.locals.put("x", _x);
Debug.locals.put("y", _y);
Debug.locals.put("width", _width);
Debug.locals.put("height", _height);
Debug.locals.put("row", _row);
Debug.locals.put("col", _col);
 BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize(x As Int, y As Int, width As Int, height As Int, row As Int, col As Int)";
Debug.ShouldStop(32768);
 BA.debugLineNum = 17;BA.debugLine="TopLeft.Initialize(x,y)";
Debug.ShouldStop(65536);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").runClassMethod (pineysoft.squarepaddocks.point.class, "_initialize",__ref.getField(false, "ba"),(Object)(_x),(Object)(_y));
 BA.debugLineNum = 18;BA.debugLine="TopRight.Initialize(x+width,y)";
Debug.ShouldStop(131072);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").runClassMethod (pineysoft.squarepaddocks.point.class, "_initialize",__ref.getField(false, "ba"),(Object)(RemoteObject.solve(new RemoteObject[] {_x,_width}, "+",1, 1)),(Object)(_y));
 BA.debugLineNum = 19;BA.debugLine="BottomLeft.Initialize(x,y+height)";
Debug.ShouldStop(262144);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").runClassMethod (pineysoft.squarepaddocks.point.class, "_initialize",__ref.getField(false, "ba"),(Object)(_x),(Object)(RemoteObject.solve(new RemoteObject[] {_y,_height}, "+",1, 1)));
 BA.debugLineNum = 20;BA.debugLine="BottomRight.Initialize(x+width,y+height)";
Debug.ShouldStop(524288);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").runClassMethod (pineysoft.squarepaddocks.point.class, "_initialize",__ref.getField(false, "ba"),(Object)(RemoteObject.solve(new RemoteObject[] {_x,_width}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_y,_height}, "+",1, 1)));
 BA.debugLineNum = 21;BA.debugLine="SpConstants.Initialize";
Debug.ShouldStop(1048576);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").runClassMethod (pineysoft.squarepaddocks.constants.class, "_initialize",__ref.getField(false, "ba"));
 BA.debugLineNum = 22;BA.debugLine="ColPos = col";
Debug.ShouldStop(2097152);
__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare", "_colpos",_col);
 BA.debugLineNum = 23;BA.debugLine="RowPos = row";
Debug.ShouldStop(4194304);
__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare", "_rowpos",_row);
 BA.debugLineNum = 24;BA.debugLine="sides(0) = \"O\"";
Debug.ShouldStop(8388608);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").setArrayElement (BA.ObjectToChar("O"),BA.numberCast(int.class, 0));
 BA.debugLineNum = 25;BA.debugLine="sides(1) = \"O\"";
Debug.ShouldStop(16777216);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").setArrayElement (BA.ObjectToChar("O"),BA.numberCast(int.class, 1));
 BA.debugLineNum = 26;BA.debugLine="sides(2) = \"O\"";
Debug.ShouldStop(33554432);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").setArrayElement (BA.ObjectToChar("O"),BA.numberCast(int.class, 2));
 BA.debugLineNum = 27;BA.debugLine="sides(3) = \"O\"";
Debug.ShouldStop(67108864);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").setArrayElement (BA.ObjectToChar("O"),BA.numberCast(int.class, 3));
 BA.debugLineNum = 29;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _issidetaken(RemoteObject __ref,RemoteObject _side) throws Exception{
try {
		Debug.PushSubsStack("IsSideTaken (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("issidetaken")) return __ref.runUserSub(false, "gamesquare","issidetaken", __ref, _side);
Debug.locals.put("side", _side);
 BA.debugLineNum = 85;BA.debugLine="Public Sub IsSideTaken(side As Int) As Boolean";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 87;BA.debugLine="Return sides(side) = SpConstants.SIDE_TAKEN";
Debug.ShouldStop(4194304);
if (true) return BA.ObjectToBoolean(RemoteObject.solveBoolean("=",__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").getArrayElement(true,_side),__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_side_taken")));
 BA.debugLineNum = 89;BA.debugLine="End Sub";
Debug.ShouldStop(16777216);
return RemoteObject.createImmutable(false);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _marksidetaken(RemoteObject __ref,RemoteObject _side,RemoteObject _marktaken) throws Exception{
try {
		Debug.PushSubsStack("MarkSideTaken (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("marksidetaken")) return __ref.runUserSub(false, "gamesquare","marksidetaken", __ref, _side, _marktaken);
Debug.locals.put("side", _side);
Debug.locals.put("markTaken", _marktaken);
 BA.debugLineNum = 91;BA.debugLine="Public Sub MarkSideTaken(side As Int, markTaken As Boolean)";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 93;BA.debugLine="If markTaken Then";
Debug.ShouldStop(268435456);
if (_marktaken.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 94;BA.debugLine="sides(side) = SpConstants.SIDE_TAKEN";
Debug.ShouldStop(536870912);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").setArrayElement (__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_side_taken"),_side);
 BA.debugLineNum = 95;BA.debugLine="sidesTaken = sidesTaken + 1";
Debug.ShouldStop(1073741824);
__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare", "_sidestaken",RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),RemoteObject.createImmutable(1)}, "+",1, 1));
 }else {
 BA.debugLineNum = 97;BA.debugLine="sides(side) = SpConstants.SIDE_AVAILABLE";
Debug.ShouldStop(1);
__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_sides").setArrayElement (__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_side_available"),_side);
 BA.debugLineNum = 98;BA.debugLine="sidesTaken = sidesTaken - 1";
Debug.ShouldStop(2);
__ref.setFieldClass("pineysoft.squarepaddocks.gamesquare", "_sidestaken",RemoteObject.solve(new RemoteObject[] {__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),RemoteObject.createImmutable(1)}, "-",1, 1));
 };
 BA.debugLineNum = 100;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _redrawside(RemoteObject __ref,RemoteObject _cnv,RemoteObject _side) throws Exception{
try {
		Debug.PushSubsStack("RedrawSide (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("redrawside")) return __ref.runUserSub(false, "gamesquare","redrawside", __ref, _cnv, _side);
Debug.locals.put("cnv", _cnv);
Debug.locals.put("side", _side);
 BA.debugLineNum = 149;BA.debugLine="Public Sub RedrawSide(cnv As Canvas, side As Int)";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 150;BA.debugLine="DrawEdge2(cnv, side, SpConstants.CURRENT_SIDE_COLOUR)";
Debug.ShouldStop(2097152);
__ref.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_drawedge2",(Object)(_cnv),(Object)(_side),(Object)(__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_current_side_colour")));
 BA.debugLineNum = 151;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _removeside(RemoteObject __ref,RemoteObject _cnv,RemoteObject _side) throws Exception{
try {
		Debug.PushSubsStack("RemoveSide (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("removeside")) return __ref.runUserSub(false, "gamesquare","removeside", __ref, _cnv, _side);
Debug.locals.put("cnv", _cnv);
Debug.locals.put("side", _side);
 BA.debugLineNum = 144;BA.debugLine="Public Sub RemoveSide(cnv As Canvas, side As Int)";
Debug.ShouldStop(32768);
 BA.debugLineNum = 145;BA.debugLine="DrawEdge2(cnv, side, SpConstants.BG_COLOUR)";
Debug.ShouldStop(65536);
__ref.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_drawedge2",(Object)(_cnv),(Object)(_side),(Object)(__ref.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_spconstants").getFieldClass("pineysoft.squarepaddocks.constants", true,"_bg_colour")));
 BA.debugLineNum = 146;BA.debugLine="MarkSideTaken(side,False)";
Debug.ShouldStop(131072);
__ref.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_marksidetaken",(Object)(_side),(Object)(gamesquare.__c.getField(true,"False")));
 BA.debugLineNum = 147;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _takeside(RemoteObject __ref,RemoteObject _cnv,RemoteObject _side) throws Exception{
try {
		Debug.PushSubsStack("TakeSide (gamesquare) ","gamesquare",4,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("takeside")) return __ref.runUserSub(false, "gamesquare","takeside", __ref, _cnv, _side);
Debug.locals.put("cnv", _cnv);
Debug.locals.put("side", _side);
 BA.debugLineNum = 102;BA.debugLine="Public Sub TakeSide(cnv As Canvas, side As Int)";
Debug.ShouldStop(32);
 BA.debugLineNum = 103;BA.debugLine="DrawEdge2(cnv,side,Colors.Red)";
Debug.ShouldStop(64);
__ref.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_drawedge2",(Object)(_cnv),(Object)(_side),(Object)(gamesquare.__c.getField(false,"Colors").getField(true,"Red")));
 BA.debugLineNum = 104;BA.debugLine="MarkSideTaken(side,True)";
Debug.ShouldStop(128);
__ref.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_marksidetaken",(Object)(_side),(Object)(gamesquare.__c.getField(true,"True")));
 BA.debugLineNum = 105;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
}