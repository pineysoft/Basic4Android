
package pineysoft.squarepaddocks;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;

public class main implements IRemote{
	public static main mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public main() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
	public static void main (String[] args) throws Exception {
		new RDebug(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]));
		RDebug.INSTANCE.waitForTask();

	}
    static {
        anywheresoftware.b4a.pc.RapidSub.moduleToObject.put("pineysoft.squarepaddocks.main", "pineysoft.squarepaddocks.main");
	}

public boolean isSingleton() {
		return true;
	}
     public static RemoteObject getObject() {
		return myClass;
	 }

	public RemoteObject activityBA;
	public RemoteObject _activity;
    private PCBA pcBA;

	public PCBA create(Object[] args) throws ClassNotFoundException{
		processBA = (RemoteObject) args[1];
		activityBA = (RemoteObject) args[2];
		_activity = (RemoteObject) args[3];
        anywheresoftware.b4a.keywords.Common.Density = (Float)args[4];
        remoteMe = (RemoteObject) args[5];
		pcBA = new PCBA(this, main.class, processBA);
        main_subs_0.initializeProcessGlobals();
		return pcBA;
	}
public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _currentplayer = RemoteObject.createImmutable((short)0);
public static RemoteObject _numberofplayers = RemoteObject.createImmutable(0);
public static RemoteObject _numberofdroids = RemoteObject.createImmutable(0);
public static RemoteObject _playercolours = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
public static RemoteObject _ingame = RemoteObject.createImmutable(false);
public static RemoteObject _gigglesound = RemoteObject.createImmutable(0);
public static RemoteObject _sounds = RemoteObject.declareNull("anywheresoftware.b4a.audio.SoundPoolWrapper");
public static RemoteObject _totalscore = RemoteObject.createImmutable(0);
public static RemoteObject _spconstants = RemoteObject.declareNull("pineysoft.squarepaddocks.constants");
public static RemoteObject _gamesquares = null;
public static RemoteObject _gameturns = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
public static RemoteObject _gamewidth = RemoteObject.createImmutable(0);
public static RemoteObject _gameheight = RemoteObject.createImmutable(0);
public static RemoteObject _columnspacing = RemoteObject.createImmutable(0);
public static RemoteObject _rowspacing = RemoteObject.createImmutable(0);
public static RemoteObject _panel1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _canv = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper");
public static RemoteObject _players = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
public static RemoteObject _playerimages = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
public static RemoteObject _lblplayer1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer1image = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer2 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer2image = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer3 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer3image = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer4 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayer4image = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _btncontinue = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _spnplayers = RemoteObject.declareNull("anywheresoftware.b4a.objects.SpinnerWrapper");
public static RemoteObject _sbcolumns = RemoteObject.declareNull("anywheresoftware.b4a.objects.SeekBarWrapper");
public static RemoteObject _sbrows = RemoteObject.declareNull("anywheresoftware.b4a.objects.SeekBarWrapper");
public static RemoteObject _pnlstartscreen = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _icon1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _icon2 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _icon3 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _icon4 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _lblcolumns = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblplayers = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _lblrows = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _pnlbase = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _btncurrplayer = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _icon5 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _icon6 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _pnldisplay = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _pnlouter = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _imageicon = RemoteObject.declareNull("anywheresoftware.b4a.objects.ImageViewWrapper");
public static RemoteObject _lblwinner = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _chksounds = RemoteObject.declareNull("anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper");
public static RemoteObject _anim1 = RemoteObject.declareNull("flm.b4a.animationplus.AnimationPlusWrapper");
public static RemoteObject _anim2 = RemoteObject.declareNull("flm.b4a.animationplus.AnimationPlusWrapper");
public static RemoteObject _anim3 = RemoteObject.declareNull("flm.b4a.animationplus.AnimationPlusWrapper");
public static RemoteObject _anim4 = RemoteObject.declareNull("flm.b4a.animationplus.AnimationPlusWrapper");
public static RemoteObject _anim5 = RemoteObject.declareNull("flm.b4a.animationplus.AnimationPlusWrapper");
public static RemoteObject _anim6 = RemoteObject.declareNull("flm.b4a.animationplus.AnimationPlusWrapper");
public static RemoteObject _spndroids = RemoteObject.declareNull("anywheresoftware.b4a.objects.SpinnerWrapper");
  public Object[] GetGlobals() {
		return new Object[] {"Activity",main.mostCurrent._activity,"anim1",main.mostCurrent._anim1,"anim2",main.mostCurrent._anim2,"anim3",main.mostCurrent._anim3,"anim4",main.mostCurrent._anim4,"anim5",main.mostCurrent._anim5,"anim6",main.mostCurrent._anim6,"btnContinue",main.mostCurrent._btncontinue,"btnCurrPlayer",main.mostCurrent._btncurrplayer,"canv",main.mostCurrent._canv,"chkSounds",main.mostCurrent._chksounds,"columnSpacing",main._columnspacing,"currentPlayer",main._currentplayer,"gameHeight",main._gameheight,"gameSquares",main.mostCurrent._gamesquares,"gameTurns",main.mostCurrent._gameturns,"gameWidth",main._gamewidth,"giggleSound",main._gigglesound,"icon1",main.mostCurrent._icon1,"icon2",main.mostCurrent._icon2,"icon3",main.mostCurrent._icon3,"icon4",main.mostCurrent._icon4,"icon5",main.mostCurrent._icon5,"icon6",main.mostCurrent._icon6,"imageIcon",main.mostCurrent._imageicon,"inGame",main._ingame,"lblColumns",main.mostCurrent._lblcolumns,"lblPlayer1",main.mostCurrent._lblplayer1,"lblPlayer1Image",main.mostCurrent._lblplayer1image,"lblPlayer2",main.mostCurrent._lblplayer2,"lblPlayer2Image",main.mostCurrent._lblplayer2image,"lblPlayer3",main.mostCurrent._lblplayer3,"lblPlayer3Image",main.mostCurrent._lblplayer3image,"lblPlayer4",main.mostCurrent._lblplayer4,"lblPlayer4Image",main.mostCurrent._lblplayer4image,"lblPlayers",main.mostCurrent._lblplayers,"lblRows",main.mostCurrent._lblrows,"lblWinner",main.mostCurrent._lblwinner,"numberOfDroids",main._numberofdroids,"numberOfPlayers",main._numberofplayers,"panel1",main.mostCurrent._panel1,"playerColours",main._playercolours,"playerImages",main.mostCurrent._playerimages,"players",main.mostCurrent._players,"pnlBase",main.mostCurrent._pnlbase,"pnlDisplay",main.mostCurrent._pnldisplay,"pnlOuter",main.mostCurrent._pnlouter,"pnlStartScreen",main.mostCurrent._pnlstartscreen,"rowSpacing",main._rowspacing,"sbColumns",main.mostCurrent._sbcolumns,"sbRows",main.mostCurrent._sbrows,"sounds",main._sounds,"SPConstants",main._spconstants,"spnDroids",main.mostCurrent._spndroids,"spnPlayers",main.mostCurrent._spnplayers,"totalScore",main._totalscore};
}
}