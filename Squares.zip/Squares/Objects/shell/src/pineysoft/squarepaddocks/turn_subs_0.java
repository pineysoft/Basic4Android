package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class turn_subs_0 {


public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Dim Square As GameSquare";
turn._square = RemoteObject.createNew ("pineysoft.squarepaddocks.gamesquare");__ref.setFieldClass("pineysoft.squarepaddocks.turn","_square",turn._square);
 //BA.debugLineNum = 4;BA.debugLine="Dim Edge As Int";
turn._edge = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.turn","_edge",turn._edge);
 //BA.debugLineNum = 5;BA.debugLine="Dim PlayerNum As Int";
turn._playernum = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.turn","_playernum",turn._playernum);
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba,RemoteObject _msquare,RemoteObject _medge,RemoteObject _mplayernum) throws Exception{
try {
		Debug.PushSubsStack("Initialize (turn) ","turn",5,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("initialize")) return __ref.runUserSub(false, "turn","initialize", __ref, _ba, _msquare, _medge, _mplayernum);
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
Debug.locals.put("mSquare", _msquare);
Debug.locals.put("mEdge", _medge);
Debug.locals.put("mPlayerNum", _mplayernum);
 BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize(mSquare As GameSquare, mEdge As Int, mPlayerNum As Int)";
Debug.ShouldStop(256);
 BA.debugLineNum = 10;BA.debugLine="Square = mSquare";
Debug.ShouldStop(512);
__ref.setFieldClass("pineysoft.squarepaddocks.turn", "_square",_msquare);
 BA.debugLineNum = 11;BA.debugLine="Edge = mEdge";
Debug.ShouldStop(1024);
__ref.setFieldClass("pineysoft.squarepaddocks.turn", "_edge",_medge);
 BA.debugLineNum = 12;BA.debugLine="PlayerNum = mPlayerNum";
Debug.ShouldStop(2048);
__ref.setFieldClass("pineysoft.squarepaddocks.turn", "_playernum",_mplayernum);
 BA.debugLineNum = 13;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
}