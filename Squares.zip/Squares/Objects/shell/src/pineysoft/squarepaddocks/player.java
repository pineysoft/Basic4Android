
package pineysoft.squarepaddocks;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;

public class player implements IRemote{
	public static player mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public player() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
public boolean isSingleton() {
		return false;
	}
    public static PCBA staticBA = new PCBA(null, player.class, null);
    private PCBA pcBA;
    public RemoteObject ba;
    public RemoteObject ref;
	public RemoteObject runMethod(boolean notUsed, String method, Object... args) throws Exception{
		return (RemoteObject) pcBA.raiseEvent(method.substring(1), RemoteObject.addItemToArray(ref, args));
	}
    public void runVoidMethod(String method, Object... args) throws Exception{
		runMethod(false, method, args);
	}
	public PCBA create(Object[] args) throws ClassNotFoundException{
        ref = (RemoteObject) args[0];
        ba = (RemoteObject) args[2];
		pcBA = new PCBA(this, player.class, ba);
		return pcBA;
	}


public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _name = RemoteObject.createImmutable("");
public static RemoteObject _score = RemoteObject.createImmutable(0);
public static RemoteObject _colour = RemoteObject.createImmutable(0);
public static RemoteObject _playerimage = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
public static RemoteObject _playertype = RemoteObject.createImmutable(0);
public static pineysoft.squarepaddocks.main _main = null;
public static Object[] GetGlobals(RemoteObject _ref) throws Exception {
		return new Object[] {"Colour",_ref.getFieldClass("pineysoft.squarepaddocks.player", false, "_colour"),"Name",_ref.getFieldClass("pineysoft.squarepaddocks.player", false, "_name"),"PlayerImage",_ref.getFieldClass("pineysoft.squarepaddocks.player", false, "_playerimage"),"PlayerType",_ref.getFieldClass("pineysoft.squarepaddocks.player", false, "_playertype"),"Score",_ref.getFieldClass("pineysoft.squarepaddocks.player", false, "_score")};
}
}