package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class constants_subs_0 {


public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Dim PLAYER_TYPE_HUMAN As Int";
constants._player_type_human = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_player_type_human",constants._player_type_human);
 //BA.debugLineNum = 4;BA.debugLine="Dim PLAYER_TYPE_DROID As Int";
constants._player_type_droid = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_player_type_droid",constants._player_type_droid);
 //BA.debugLineNum = 6;BA.debugLine="Dim TOP_SIDE As Int";
constants._top_side = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_top_side",constants._top_side);
 //BA.debugLineNum = 7;BA.debugLine="Dim RIGHT_SIDE As Int";
constants._right_side = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_right_side",constants._right_side);
 //BA.debugLineNum = 8;BA.debugLine="Dim BOTTOM_SIDE As Int";
constants._bottom_side = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_bottom_side",constants._bottom_side);
 //BA.debugLineNum = 9;BA.debugLine="Dim LEFT_SIDE As Int";
constants._left_side = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_left_side",constants._left_side);
 //BA.debugLineNum = 11;BA.debugLine="Dim HORIZONTAL As Int";
constants._horizontal = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_horizontal",constants._horizontal);
 //BA.debugLineNum = 12;BA.debugLine="Dim VERTICAL As Int";
constants._vertical = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_vertical",constants._vertical);
 //BA.debugLineNum = 14;BA.debugLine="Dim VACANT As Int";
constants._vacant = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_vacant",constants._vacant);
 //BA.debugLineNum = 15;BA.debugLine="Dim OCCUPIED As Int";
constants._occupied = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.constants","_occupied",constants._occupied);
 //BA.debugLineNum = 17;BA.debugLine="Dim SIDE_TAKEN As Char";
constants._side_taken = RemoteObject.createImmutable('\0');__ref.setFieldClass("pineysoft.squarepaddocks.constants","_side_taken",constants._side_taken);
 //BA.debugLineNum = 18;BA.debugLine="Dim SIDE_AVAILABLE As Char";
constants._side_available = RemoteObject.createImmutable('\0');__ref.setFieldClass("pineysoft.squarepaddocks.constants","_side_available",constants._side_available);
 //BA.debugLineNum = 20;BA.debugLine="Dim BG_COLOUR As Int = Colors.RGB(30,144,255)";
constants._bg_colour = constants.__c.getField(false,"Colors").runMethod(true,"RGB",(Object)(BA.numberCast(int.class, 30)),(Object)(BA.numberCast(int.class, 144)),(Object)(BA.numberCast(int.class, 255)));__ref.setFieldClass("pineysoft.squarepaddocks.constants","_bg_colour",constants._bg_colour);
 //BA.debugLineNum = 21;BA.debugLine="Dim CURRENT_SIDE_COLOUR As Int = Colors.Red";
constants._current_side_colour = constants.__c.getField(false,"Colors").getField(true,"Red");__ref.setFieldClass("pineysoft.squarepaddocks.constants","_current_side_colour",constants._current_side_colour);
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba) throws Exception{
try {
		Debug.PushSubsStack("Initialize (constants) ","constants",3,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("initialize")) return __ref.runUserSub(false, "constants","initialize", __ref, _ba);
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
 BA.debugLineNum = 25;BA.debugLine="Public Sub Initialize";
Debug.ShouldStop(16777216);
 BA.debugLineNum = 26;BA.debugLine="PLAYER_TYPE_HUMAN = 0";
Debug.ShouldStop(33554432);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_player_type_human",BA.numberCast(int.class, 0));
 BA.debugLineNum = 27;BA.debugLine="PLAYER_TYPE_DROID = 1";
Debug.ShouldStop(67108864);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_player_type_droid",BA.numberCast(int.class, 1));
 BA.debugLineNum = 29;BA.debugLine="TOP_SIDE = 0";
Debug.ShouldStop(268435456);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_top_side",BA.numberCast(int.class, 0));
 BA.debugLineNum = 30;BA.debugLine="RIGHT_SIDE = 1";
Debug.ShouldStop(536870912);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_right_side",BA.numberCast(int.class, 1));
 BA.debugLineNum = 31;BA.debugLine="BOTTOM_SIDE = 2";
Debug.ShouldStop(1073741824);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_bottom_side",BA.numberCast(int.class, 2));
 BA.debugLineNum = 32;BA.debugLine="LEFT_SIDE = 3";
Debug.ShouldStop(-2147483648);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_left_side",BA.numberCast(int.class, 3));
 BA.debugLineNum = 34;BA.debugLine="SIDE_TAKEN = \"X\"";
Debug.ShouldStop(2);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_side_taken",BA.ObjectToChar("X"));
 BA.debugLineNum = 35;BA.debugLine="SIDE_AVAILABLE = \"O\"";
Debug.ShouldStop(4);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_side_available",BA.ObjectToChar("O"));
 BA.debugLineNum = 38;BA.debugLine="VACANT = 0";
Debug.ShouldStop(32);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_vacant",BA.numberCast(int.class, 0));
 BA.debugLineNum = 39;BA.debugLine="OCCUPIED = 1";
Debug.ShouldStop(64);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_occupied",BA.numberCast(int.class, 1));
 BA.debugLineNum = 41;BA.debugLine="HORIZONTAL = 0";
Debug.ShouldStop(256);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_horizontal",BA.numberCast(int.class, 0));
 BA.debugLineNum = 42;BA.debugLine="VERTICAL = 1";
Debug.ShouldStop(512);
__ref.setFieldClass("pineysoft.squarepaddocks.constants", "_vertical",BA.numberCast(int.class, 1));
 BA.debugLineNum = 44;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
}