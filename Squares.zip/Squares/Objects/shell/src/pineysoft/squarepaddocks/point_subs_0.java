package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class point_subs_0 {


public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Dim Pos1 As Int";
point._pos1 = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.point","_pos1",point._pos1);
 //BA.debugLineNum = 4;BA.debugLine="Dim Pos2 As Int";
point._pos2 = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.point","_pos2",point._pos2);
 //BA.debugLineNum = 5;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba,RemoteObject _a,RemoteObject _b) throws Exception{
try {
		Debug.PushSubsStack("Initialize (point) ","point",1,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("initialize")) return __ref.runUserSub(false, "point","initialize", __ref, _ba, _a, _b);
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
Debug.locals.put("a", _a);
Debug.locals.put("b", _b);
 BA.debugLineNum = 8;BA.debugLine="Public Sub Initialize(a As Int, b As Int)";
Debug.ShouldStop(128);
 BA.debugLineNum = 9;BA.debugLine="Pos1 = a";
Debug.ShouldStop(256);
__ref.setFieldClass("pineysoft.squarepaddocks.point", "_pos1",_a);
 BA.debugLineNum = 10;BA.debugLine="Pos2 = b";
Debug.ShouldStop(512);
__ref.setFieldClass("pineysoft.squarepaddocks.point", "_pos2",_b);
 BA.debugLineNum = 11;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
}