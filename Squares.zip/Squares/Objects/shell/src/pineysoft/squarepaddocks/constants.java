
package pineysoft.squarepaddocks;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;

public class constants implements IRemote{
	public static constants mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public constants() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
public boolean isSingleton() {
		return false;
	}
    public static PCBA staticBA = new PCBA(null, constants.class, null);
    private PCBA pcBA;
    public RemoteObject ba;
    public RemoteObject ref;
	public RemoteObject runMethod(boolean notUsed, String method, Object... args) throws Exception{
		return (RemoteObject) pcBA.raiseEvent(method.substring(1), RemoteObject.addItemToArray(ref, args));
	}
    public void runVoidMethod(String method, Object... args) throws Exception{
		runMethod(false, method, args);
	}
	public PCBA create(Object[] args) throws ClassNotFoundException{
        ref = (RemoteObject) args[0];
        ba = (RemoteObject) args[2];
		pcBA = new PCBA(this, constants.class, ba);
		return pcBA;
	}


public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _player_type_human = RemoteObject.createImmutable(0);
public static RemoteObject _player_type_droid = RemoteObject.createImmutable(0);
public static RemoteObject _top_side = RemoteObject.createImmutable(0);
public static RemoteObject _right_side = RemoteObject.createImmutable(0);
public static RemoteObject _bottom_side = RemoteObject.createImmutable(0);
public static RemoteObject _left_side = RemoteObject.createImmutable(0);
public static RemoteObject _horizontal = RemoteObject.createImmutable(0);
public static RemoteObject _vertical = RemoteObject.createImmutable(0);
public static RemoteObject _vacant = RemoteObject.createImmutable(0);
public static RemoteObject _occupied = RemoteObject.createImmutable(0);
public static RemoteObject _side_taken = RemoteObject.createImmutable('\0');
public static RemoteObject _side_available = RemoteObject.createImmutable('\0');
public static RemoteObject _bg_colour = RemoteObject.createImmutable(0);
public static RemoteObject _current_side_colour = RemoteObject.createImmutable(0);
public static pineysoft.squarepaddocks.main _main = null;
public static Object[] GetGlobals(RemoteObject _ref) throws Exception {
		return new Object[] {"BG_COLOUR",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_bg_colour"),"BOTTOM_SIDE",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_bottom_side"),"CURRENT_SIDE_COLOUR",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_current_side_colour"),"HORIZONTAL",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_horizontal"),"LEFT_SIDE",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_left_side"),"OCCUPIED",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_occupied"),"PLAYER_TYPE_DROID",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_player_type_droid"),"PLAYER_TYPE_HUMAN",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_player_type_human"),"RIGHT_SIDE",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_right_side"),"SIDE_AVAILABLE",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_side_available"),"SIDE_TAKEN",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_side_taken"),"TOP_SIDE",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_top_side"),"VACANT",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_vacant"),"VERTICAL",_ref.getFieldClass("pineysoft.squarepaddocks.constants", false, "_vertical")};
}
}