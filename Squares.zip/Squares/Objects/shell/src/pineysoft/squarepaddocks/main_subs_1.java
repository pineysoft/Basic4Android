package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_1 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("activity_create")) return main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 80;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(32768);
 BA.debugLineNum = 82;BA.debugLine="SPConstants.Initialize";
Debug.ShouldStop(131072);
main._spconstants.runClassMethod (pineysoft.squarepaddocks.constants.class, "_initialize",main.processBA);
 BA.debugLineNum = 83;BA.debugLine="If FirstTime Then";
Debug.ShouldStop(262144);
if (_firsttime.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 84;BA.debugLine="Activity.LoadLayout(\"StartScreen\")";
Debug.ShouldStop(524288);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(BA.ObjectToString("StartScreen")),main.mostCurrent.activityBA);
 BA.debugLineNum = 85;BA.debugLine="ShowSplashScreen";
Debug.ShouldStop(1048576);
_showsplashscreen();
 BA.debugLineNum = 86;BA.debugLine="CreateColours";
Debug.ShouldStop(2097152);
_createcolours();
 BA.debugLineNum = 87;BA.debugLine="LoadImages";
Debug.ShouldStop(4194304);
_loadimages();
 BA.debugLineNum = 88;BA.debugLine="LoadPlayerSpinner";
Debug.ShouldStop(8388608);
_loadplayerspinner();
 BA.debugLineNum = 89;BA.debugLine="InitialiseSounds";
Debug.ShouldStop(16777216);
_initialisesounds();
 }else {
 BA.debugLineNum = 91;BA.debugLine="Activity.LoadLayout(\"StartScreen\")";
Debug.ShouldStop(67108864);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(BA.ObjectToString("StartScreen")),main.mostCurrent.activityBA);
 BA.debugLineNum = 92;BA.debugLine="DisplayFrontScreen";
Debug.ShouldStop(134217728);
_displayfrontscreen();
 BA.debugLineNum = 93;BA.debugLine="ShowCharacters";
Debug.ShouldStop(268435456);
_showcharacters();
 BA.debugLineNum = 94;BA.debugLine="CreateColours";
Debug.ShouldStop(536870912);
_createcolours();
 BA.debugLineNum = 95;BA.debugLine="LoadImages";
Debug.ShouldStop(1073741824);
_loadimages();
 BA.debugLineNum = 96;BA.debugLine="LoadPlayerSpinner";
Debug.ShouldStop(-2147483648);
_loadplayerspinner();
 BA.debugLineNum = 97;BA.debugLine="UpdateLabels";
Debug.ShouldStop(1);
_updatelabels();
 };
 BA.debugLineNum = 100;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_keypress(RemoteObject _keycode) throws Exception{
try {
		Debug.PushSubsStack("Activity_KeyPress (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("activity_keypress")) return main.remoteMe.runUserSub(false, "main","activity_keypress", _keycode);
RemoteObject _answ = RemoteObject.createImmutable(0);
Debug.locals.put("KeyCode", _keycode);
 BA.debugLineNum = 843;BA.debugLine="Sub Activity_KeyPress (KeyCode As Int) As Boolean 'Return True to consume the event";
Debug.ShouldStop(1024);
 BA.debugLineNum = 844;BA.debugLine="If KeyCode = KeyCodes.KEYCODE_BACK Then";
Debug.ShouldStop(2048);
if (RemoteObject.solveBoolean("=",_keycode,BA.numberCast(double.class, main.mostCurrent.__c.getField(false,"KeyCodes").getField(true,"KEYCODE_BACK")))) { 
 BA.debugLineNum = 845;BA.debugLine="If inGame Then";
Debug.ShouldStop(4096);
if (main._ingame.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 846;BA.debugLine="Dim Answ As Int";
Debug.ShouldStop(8192);
_answ = RemoteObject.createImmutable(0);Debug.locals.put("Answ", _answ);
 BA.debugLineNum = 847;BA.debugLine="Answ = Msgbox2(\"Do you want to quit this game, you will lose all progress.\", _ 		      \"W A R N I N G\", \"Yes\", \"\", \"No\", Null)";
Debug.ShouldStop(16384);
_answ = main.mostCurrent.__c.runMethodAndSync(true,"Msgbox2",(Object)(BA.ObjectToString("Do you want to quit this game, you will lose all progress.")),(Object)(BA.ObjectToString("W A R N I N G")),(Object)(BA.ObjectToString("Yes")),(Object)(BA.ObjectToString("")),(Object)(BA.ObjectToString("No")),(Object)((main.mostCurrent.__c.getField(false,"Null"))),main.mostCurrent.activityBA);Debug.locals.put("Answ", _answ);
 BA.debugLineNum = 849;BA.debugLine="If Answ = DialogResponse.NEGATIVE Then";
Debug.ShouldStop(65536);
if (RemoteObject.solveBoolean("=",_answ,BA.numberCast(double.class, main.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"NEGATIVE")))) { 
 BA.debugLineNum = 850;BA.debugLine="Return True";
Debug.ShouldStop(131072);
if (true) return main.mostCurrent.__c.getField(true,"True");
 }else {
 BA.debugLineNum = 852;BA.debugLine="DisplayFrontScreen";
Debug.ShouldStop(524288);
_displayfrontscreen();
 BA.debugLineNum = 853;BA.debugLine="Return True";
Debug.ShouldStop(1048576);
if (true) return main.mostCurrent.__c.getField(true,"True");
 };
 };
 };
 BA.debugLineNum = 858;BA.debugLine="Return False";
Debug.ShouldStop(33554432);
if (true) return main.mostCurrent.__c.getField(true,"False");
 BA.debugLineNum = 859;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return RemoteObject.createImmutable(false);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("activity_pause")) return main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 305;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(65536);
 BA.debugLineNum = 307;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("activity_resume")) return main.remoteMe.runUserSub(false, "main","activity_resume");
 BA.debugLineNum = 301;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(4096);
 BA.debugLineNum = 303;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _anim6_animationend() throws Exception{
try {
		Debug.PushSubsStack("anim6_AnimationEnd (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("anim6_animationend")) return main.remoteMe.runUserSub(false, "main","anim6_animationend");
 BA.debugLineNum = 181;BA.debugLine="Sub anim6_AnimationEnd";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 182;BA.debugLine="pnlStartScreen.Left = 200%x";
Debug.ShouldStop(2097152);
main.mostCurrent._pnlstartscreen.runMethod(true,"setLeft",main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 200)),main.mostCurrent.activityBA));
 BA.debugLineNum = 183;BA.debugLine="Activity.LoadLayout(\"layout1\")";
Debug.ShouldStop(4194304);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(BA.ObjectToString("layout1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 184;BA.debugLine="Activity.LoadLayout(\"winnerScreen\")";
Debug.ShouldStop(8388608);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(BA.ObjectToString("winnerScreen")),main.mostCurrent.activityBA);
 BA.debugLineNum = 185;BA.debugLine="pnlOuter.Left = -100%x";
Debug.ShouldStop(16777216);
main.mostCurrent._pnlouter.runMethod(true,"setLeft",BA.numberCast(int.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA).<Integer>get().intValue())));
 BA.debugLineNum = 186;BA.debugLine="inGame = True";
Debug.ShouldStop(33554432);
main._ingame = main.mostCurrent.__c.getField(true,"True");
 BA.debugLineNum = 187;BA.debugLine="InitGamePlay";
Debug.ShouldStop(67108864);
_initgameplay();
 BA.debugLineNum = 188;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _animatecharacters() throws Exception{
try {
		Debug.PushSubsStack("AnimateCharacters (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("animatecharacters")) return main.remoteMe.runUserSub(false, "main","animatecharacters");
 BA.debugLineNum = 107;BA.debugLine="Sub AnimateCharacters";
Debug.ShouldStop(1024);
 BA.debugLineNum = 109;BA.debugLine="anim1.InitializeTranslate(\"\", -120dip,100dip,350dip,100dip)";
Debug.ShouldStop(4096);
main.mostCurrent._anim1.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120))).<Integer>get().intValue()))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 350))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))));
 BA.debugLineNum = 110;BA.debugLine="anim1.Duration = 1500";
Debug.ShouldStop(8192);
main.mostCurrent._anim1.runMethod(true,"setDuration",BA.numberCast(long.class, 1500));
 BA.debugLineNum = 111;BA.debugLine="anim1.StartOffset = 250";
Debug.ShouldStop(16384);
main.mostCurrent._anim1.runMethod(true,"setStartOffset",BA.numberCast(long.class, 250));
 BA.debugLineNum = 112;BA.debugLine="anim1.PersistAfter = True";
Debug.ShouldStop(32768);
main.mostCurrent._anim1.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 113;BA.debugLine="anim1.Start(icon1)";
Debug.ShouldStop(65536);
main.mostCurrent._anim1.runVoidMethod ("Start",(Object)((main.mostCurrent._icon1.getObject())));
 BA.debugLineNum = 114;BA.debugLine="anim2.InitializeTranslate(\"\", 100%x + 120dip,200dip,150dip,200dip)";
Debug.ShouldStop(131072);
main.mostCurrent._anim2.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120)))}, "+",1, 1))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 150))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))));
 BA.debugLineNum = 115;BA.debugLine="anim2.Duration = 1500";
Debug.ShouldStop(262144);
main.mostCurrent._anim2.runMethod(true,"setDuration",BA.numberCast(long.class, 1500));
 BA.debugLineNum = 116;BA.debugLine="anim2.StartOffset = 500";
Debug.ShouldStop(524288);
main.mostCurrent._anim2.runMethod(true,"setStartOffset",BA.numberCast(long.class, 500));
 BA.debugLineNum = 117;BA.debugLine="anim2.PersistAfter = True";
Debug.ShouldStop(1048576);
main.mostCurrent._anim2.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 118;BA.debugLine="anim2.Start(icon2)";
Debug.ShouldStop(2097152);
main.mostCurrent._anim2.runVoidMethod ("Start",(Object)((main.mostCurrent._icon2.getObject())));
 BA.debugLineNum = 119;BA.debugLine="anim3.InitializeTranslate(\"\", -120dip,100dip,250dip,100dip)";
Debug.ShouldStop(4194304);
main.mostCurrent._anim3.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120))).<Integer>get().intValue()))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))));
 BA.debugLineNum = 120;BA.debugLine="anim3.Duration = 1500";
Debug.ShouldStop(8388608);
main.mostCurrent._anim3.runMethod(true,"setDuration",BA.numberCast(long.class, 1500));
 BA.debugLineNum = 121;BA.debugLine="anim3.StartOffset = 750";
Debug.ShouldStop(16777216);
main.mostCurrent._anim3.runMethod(true,"setStartOffset",BA.numberCast(long.class, 750));
 BA.debugLineNum = 122;BA.debugLine="anim3.PersistAfter = True";
Debug.ShouldStop(33554432);
main.mostCurrent._anim3.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 123;BA.debugLine="anim3.Start(icon3)";
Debug.ShouldStop(67108864);
main.mostCurrent._anim3.runVoidMethod ("Start",(Object)((main.mostCurrent._icon3.getObject())));
 BA.debugLineNum = 124;BA.debugLine="anim4.InitializeTranslate(\"\", 100%x + 120dip,200dip,250dip,200dip)";
Debug.ShouldStop(134217728);
main.mostCurrent._anim4.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120)))}, "+",1, 1))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))));
 BA.debugLineNum = 125;BA.debugLine="anim4.Duration = 1500";
Debug.ShouldStop(268435456);
main.mostCurrent._anim4.runMethod(true,"setDuration",BA.numberCast(long.class, 1500));
 BA.debugLineNum = 126;BA.debugLine="anim4.StartOffset = 1000";
Debug.ShouldStop(536870912);
main.mostCurrent._anim4.runMethod(true,"setStartOffset",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 127;BA.debugLine="anim4.PersistAfter	 = True";
Debug.ShouldStop(1073741824);
main.mostCurrent._anim4.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 128;BA.debugLine="anim4.Start(icon4)";
Debug.ShouldStop(-2147483648);
main.mostCurrent._anim4.runVoidMethod ("Start",(Object)((main.mostCurrent._icon4.getObject())));
 BA.debugLineNum = 129;BA.debugLine="anim5.InitializeTranslate(\"\", -120dip,100dip,150dip,100dip)";
Debug.ShouldStop(1);
main.mostCurrent._anim5.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120))).<Integer>get().intValue()))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 150))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))));
 BA.debugLineNum = 130;BA.debugLine="anim5.Duration = 1500";
Debug.ShouldStop(2);
main.mostCurrent._anim5.runMethod(true,"setDuration",BA.numberCast(long.class, 1500));
 BA.debugLineNum = 131;BA.debugLine="anim5.StartOffset = 750";
Debug.ShouldStop(4);
main.mostCurrent._anim5.runMethod(true,"setStartOffset",BA.numberCast(long.class, 750));
 BA.debugLineNum = 132;BA.debugLine="anim5.PersistAfter = True";
Debug.ShouldStop(8);
main.mostCurrent._anim5.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 133;BA.debugLine="anim5.Start(icon5)";
Debug.ShouldStop(16);
main.mostCurrent._anim5.runVoidMethod ("Start",(Object)((main.mostCurrent._icon5.getObject())));
 BA.debugLineNum = 134;BA.debugLine="anim6.InitializeTranslate(\"\", 100%x + 120dip,200dip,350dip,200dip)";
Debug.ShouldStop(32);
main.mostCurrent._anim6.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120)))}, "+",1, 1))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 350))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))));
 BA.debugLineNum = 135;BA.debugLine="anim6.Duration = 1500";
Debug.ShouldStop(64);
main.mostCurrent._anim6.runMethod(true,"setDuration",BA.numberCast(long.class, 1500));
 BA.debugLineNum = 136;BA.debugLine="anim6.StartOffset = 1000";
Debug.ShouldStop(128);
main.mostCurrent._anim6.runMethod(true,"setStartOffset",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 137;BA.debugLine="anim6.PersistAfter = True";
Debug.ShouldStop(256);
main.mostCurrent._anim6.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 138;BA.debugLine="anim6.Start(icon6)";
Debug.ShouldStop(512);
main.mostCurrent._anim6.runVoidMethod ("Start",(Object)((main.mostCurrent._icon6.getObject())));
 BA.debugLineNum = 140;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btncontinue_click() throws Exception{
try {
		Debug.PushSubsStack("btnContinue_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("btncontinue_click")) return main.remoteMe.runUserSub(false, "main","btncontinue_click");
 BA.debugLineNum = 820;BA.debugLine="Sub btnContinue_Click";
Debug.ShouldStop(524288);
 BA.debugLineNum = 821;BA.debugLine="pnlStartScreen.Left = 200%x";
Debug.ShouldStop(1048576);
main.mostCurrent._pnlstartscreen.runMethod(true,"setLeft",main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 200)),main.mostCurrent.activityBA));
 BA.debugLineNum = 822;BA.debugLine="Activity.LoadLayout(\"layout1\")";
Debug.ShouldStop(2097152);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(BA.ObjectToString("layout1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 823;BA.debugLine="Activity.LoadLayout(\"winnerScreen\")";
Debug.ShouldStop(4194304);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(BA.ObjectToString("winnerScreen")),main.mostCurrent.activityBA);
 BA.debugLineNum = 824;BA.debugLine="pnlOuter.Left = -100%x";
Debug.ShouldStop(8388608);
main.mostCurrent._pnlouter.runMethod(true,"setLeft",BA.numberCast(int.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA).<Integer>get().intValue())));
 BA.debugLineNum = 825;BA.debugLine="inGame = True";
Debug.ShouldStop(16777216);
main._ingame = main.mostCurrent.__c.getField(true,"True");
 BA.debugLineNum = 826;BA.debugLine="InitGamePlay";
Debug.ShouldStop(33554432);
_initgameplay();
 BA.debugLineNum = 828;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btncurrplayer_click() throws Exception{
try {
		Debug.PushSubsStack("btnCurrPlayer_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("btncurrplayer_click")) return main.remoteMe.runUserSub(false, "main","btncurrplayer_click");
RemoteObject _lastturn = RemoteObject.declareNull("pineysoft.squarepaddocks.turn");
RemoteObject _currplayer = RemoteObject.declareNull("pineysoft.squarepaddocks.player");
 BA.debugLineNum = 883;BA.debugLine="Sub btnCurrPlayer_Click";
Debug.ShouldStop(262144);
 BA.debugLineNum = 884;BA.debugLine="If gameTurns.Size > 0 Then";
Debug.ShouldStop(524288);
if (RemoteObject.solveBoolean(">",main.mostCurrent._gameturns.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 886;BA.debugLine="Dim lastTurn As Turn = gameTurns.Get(gameTurns.Size - 1)";
Debug.ShouldStop(2097152);
_lastturn = (main.mostCurrent._gameturns.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent._gameturns.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1))));Debug.locals.put("lastTurn", _lastturn);Debug.locals.put("lastTurn", _lastturn);
 BA.debugLineNum = 887;BA.debugLine="Dim currPlayer As Player  = players.Get(lastTurn.PlayerNum)";
Debug.ShouldStop(4194304);
_currplayer = (main.mostCurrent._players.runMethod(false,"Get",(Object)(_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", true,"_playernum"))));Debug.locals.put("currPlayer", _currplayer);Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 889;BA.debugLine="RemoveTurn(lastTurn, currPlayer)";
Debug.ShouldStop(16777216);
_removeturn(_lastturn,_currplayer);
 BA.debugLineNum = 891;BA.debugLine="If gameTurns.Size > 0 Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean(">",main.mostCurrent._gameturns.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 892;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
Debug.ShouldStop(134217728);
_lastturn = (main.mostCurrent._gameturns.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent._gameturns.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1))));Debug.locals.put("lastTurn", _lastturn);
 BA.debugLineNum = 893;BA.debugLine="currentPlayer = lastTurn.PlayerNum";
Debug.ShouldStop(268435456);
main._currentplayer = BA.numberCast(short.class, _lastturn.getFieldClass("pineysoft.squarepaddocks.turn", true,"_playernum"));
 }else {
 BA.debugLineNum = 895;BA.debugLine="currentPlayer = 0";
Debug.ShouldStop(1073741824);
main._currentplayer = BA.numberCast(short.class, 0);
 };
 BA.debugLineNum = 898;BA.debugLine="btnCurrPlayer.SetBackgroundImage(playerImages.Get(currentPlayer))";
Debug.ShouldStop(2);
main.mostCurrent._btncurrplayer.runVoidMethod ("SetBackgroundImage",(Object)((main.mostCurrent._playerimages.runMethod(false,"Get",(Object)(BA.numberCast(int.class, main._currentplayer))))));
 BA.debugLineNum = 899;BA.debugLine="panel1.Invalidate";
Debug.ShouldStop(4);
main.mostCurrent._panel1.runVoidMethod ("Invalidate");
 }else {
 BA.debugLineNum = 901;BA.debugLine="ToastMessageShow(\"No More Undo's left\",False)";
Debug.ShouldStop(16);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToString("No More Undo's left")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 };
 BA.debugLineNum = 904;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnok_click() throws Exception{
try {
		Debug.PushSubsStack("btnOk_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("btnok_click")) return main.remoteMe.runUserSub(false, "main","btnok_click");
 BA.debugLineNum = 905;BA.debugLine="Sub btnOk_Click";
Debug.ShouldStop(256);
 BA.debugLineNum = 906;BA.debugLine="pnlOuter.Left = -100%x";
Debug.ShouldStop(512);
main.mostCurrent._pnlouter.runMethod(true,"setLeft",BA.numberCast(int.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA).<Integer>get().intValue())));
 BA.debugLineNum = 907;BA.debugLine="DisplayFrontScreen";
Debug.ShouldStop(1024);
_displayfrontscreen();
 BA.debugLineNum = 908;BA.debugLine="End Sub";
Debug.ShouldStop(2048);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _calculatemove(RemoteObject _xcoord,RemoteObject _ycoord) throws Exception{
try {
		Debug.PushSubsStack("CalculateMove (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("calculatemove")) return main.remoteMe.runUserSub(false, "main","calculatemove", _xcoord, _ycoord);
RemoteObject _touchpoint = RemoteObject.declareNull("pineysoft.squarepaddocks.point");
RemoteObject _chosenside = RemoteObject.createImmutable(0);
RemoteObject _currentsquare = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
RemoteObject _currplayer = RemoteObject.declareNull("pineysoft.squarepaddocks.player");
RemoteObject _numberclosed = RemoteObject.createImmutable(0);
RemoteObject _temp = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
RemoteObject _lbl = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
Debug.locals.put("xCoord", _xcoord);
Debug.locals.put("yCoord", _ycoord);
 BA.debugLineNum = 356;BA.debugLine="Sub CalculateMove(xCoord As Int, yCoord As Int)";
Debug.ShouldStop(8);
 BA.debugLineNum = 357;BA.debugLine="canv.DrawCircle(xCoord,yCoord,2dip,Colors.Red,True,1dip)";
Debug.ShouldStop(16);
main.mostCurrent._canv.runVoidMethod ("DrawCircle",(Object)(BA.numberCast(float.class, _xcoord)),(Object)(BA.numberCast(float.class, _ycoord)),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 2))))),(Object)(main.mostCurrent.__c.getField(false,"Colors").getField(true,"Red")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 BA.debugLineNum = 358;BA.debugLine="panel1.Invalidate";
Debug.ShouldStop(32);
main.mostCurrent._panel1.runVoidMethod ("Invalidate");
 BA.debugLineNum = 359;BA.debugLine="Dim touchPoint As Point";
Debug.ShouldStop(64);
_touchpoint = RemoteObject.createNew ("pineysoft.squarepaddocks.point");Debug.locals.put("touchPoint", _touchpoint);
 BA.debugLineNum = 360;BA.debugLine="Dim chosenSide As Int";
Debug.ShouldStop(128);
_chosenside = RemoteObject.createImmutable(0);Debug.locals.put("chosenSide", _chosenside);
 BA.debugLineNum = 361;BA.debugLine="touchPoint.Initialize(xCoord, yCoord)";
Debug.ShouldStop(256);
_touchpoint.runClassMethod (pineysoft.squarepaddocks.point.class, "_initialize",main.processBA,(Object)(_xcoord),(Object)(_ycoord));
 BA.debugLineNum = 362;BA.debugLine="Dim currentSquare As GameSquare = FindSelectedSquare(xCoord, yCoord)";
Debug.ShouldStop(512);
_currentsquare = _findselectedsquare(_xcoord,_ycoord);Debug.locals.put("currentSquare", _currentsquare);Debug.locals.put("currentSquare", _currentsquare);
 BA.debugLineNum = 363;BA.debugLine="Dim currPlayer As Player = players.Get(currentPlayer)";
Debug.ShouldStop(1024);
_currplayer = (main.mostCurrent._players.runMethod(false,"Get",(Object)(BA.numberCast(int.class, main._currentplayer))));Debug.locals.put("currPlayer", _currplayer);Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 365;BA.debugLine="chosenSide = currentSquare.CalculateClosestEdge(touchPoint)";
Debug.ShouldStop(4096);
_chosenside = _currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_calculateclosestedge",(Object)(_touchpoint));Debug.locals.put("chosenSide", _chosenside);
 BA.debugLineNum = 366;BA.debugLine="Log(chosenSide)";
Debug.ShouldStop(8192);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(BA.NumberToString(_chosenside)));
 BA.debugLineNum = 369;BA.debugLine="If currentSquare.IsSideTaken(chosenSide) Then Return";
Debug.ShouldStop(65536);
if (_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(_chosenside)).<Boolean>get().booleanValue()) { 
if (true) return RemoteObject.createImmutable("");};
 BA.debugLineNum = 371;BA.debugLine="UpdateTurn(canv, currentSquare, chosenSide)";
Debug.ShouldStop(262144);
_updateturn(main.mostCurrent._canv,_currentsquare,_chosenside);
 BA.debugLineNum = 374;BA.debugLine="currentSquare.TakeSide(canv,chosenSide)";
Debug.ShouldStop(2097152);
_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_takeside",(Object)(main.mostCurrent._canv),(Object)(_chosenside));
 BA.debugLineNum = 377;BA.debugLine="MarkOtherSide2(currentSquare, chosenSide)";
Debug.ShouldStop(16777216);
_markotherside2(_currentsquare,_chosenside);
 BA.debugLineNum = 380;BA.debugLine="Dim numberClosed As Int = CloseCompletedSquares(currPlayer)";
Debug.ShouldStop(134217728);
_numberclosed = _closecompletedsquares(_currplayer);Debug.locals.put("numberClosed", _numberclosed);Debug.locals.put("numberClosed", _numberclosed);
 BA.debugLineNum = 382;BA.debugLine="If numberClosed = 0 Then";
Debug.ShouldStop(536870912);
if (RemoteObject.solveBoolean("=",_numberclosed,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 383;BA.debugLine="UpdatePlayerNumber";
Debug.ShouldStop(1073741824);
_updateplayernumber();
 BA.debugLineNum = 384;BA.debugLine="currPlayer = players.Get(currentPlayer)";
Debug.ShouldStop(-2147483648);
_currplayer = (main.mostCurrent._players.runMethod(false,"Get",(Object)(BA.numberCast(int.class, main._currentplayer))));Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 385;BA.debugLine="btnCurrPlayer.SetBackgroundImage(currPlayer.PlayerImage)";
Debug.ShouldStop(1);
main.mostCurrent._btncurrplayer.runVoidMethod ("SetBackgroundImage",(Object)((_currplayer.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").getObject())));
 BA.debugLineNum = 386;BA.debugLine="Do While currPlayer.PlayerType = SPConstants.PLAYER_TYPE_DROID";
Debug.ShouldStop(2);
while (RemoteObject.solveBoolean("=",_currplayer.getFieldClass("pineysoft.squarepaddocks.player", true,"_playertype"),BA.numberCast(double.class, main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_player_type_droid")))) {
 BA.debugLineNum = 387;BA.debugLine="btnCurrPlayer.Text = \"D\"";
Debug.ShouldStop(4);
main.mostCurrent._btncurrplayer.runMethod(true,"setText",RemoteObject.createImmutable(("D")));
 BA.debugLineNum = 388;BA.debugLine="MakeDroidMove(currPlayer)";
Debug.ShouldStop(8);
_makedroidmove(_currplayer);
 BA.debugLineNum = 389;BA.debugLine="UpdatePlayerNumber";
Debug.ShouldStop(16);
_updateplayernumber();
 BA.debugLineNum = 390;BA.debugLine="currPlayer = players.Get(currentPlayer)";
Debug.ShouldStop(32);
_currplayer = (main.mostCurrent._players.runMethod(false,"Get",(Object)(BA.numberCast(int.class, main._currentplayer))));Debug.locals.put("currPlayer", _currplayer);
 }
;
 BA.debugLineNum = 392;BA.debugLine="btnCurrPlayer.Text = \"\"";
Debug.ShouldStop(128);
main.mostCurrent._btncurrplayer.runMethod(true,"setText",RemoteObject.createImmutable(("")));
 BA.debugLineNum = 393;BA.debugLine="btnCurrPlayer.SetBackgroundImage(currPlayer.PlayerImage)";
Debug.ShouldStop(256);
main.mostCurrent._btncurrplayer.runVoidMethod ("SetBackgroundImage",(Object)((_currplayer.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").getObject())));
 }else {
 BA.debugLineNum = 395;BA.debugLine="currPlayer.Score = currPlayer.Score + numberClosed";
Debug.ShouldStop(1024);
_currplayer.setFieldClass("pineysoft.squarepaddocks.player", "_score",RemoteObject.solve(new RemoteObject[] {_currplayer.getFieldClass("pineysoft.squarepaddocks.player", true,"_score"),_numberclosed}, "+",1, 1));
 BA.debugLineNum = 396;BA.debugLine="totalScore = totalScore + numberClosed";
Debug.ShouldStop(2048);
main._totalscore = RemoteObject.solve(new RemoteObject[] {main._totalscore,_numberclosed}, "+",1, 1);
 BA.debugLineNum = 397;BA.debugLine="If chkSounds.Checked Then sounds.Play(giggleSound,1,1,1,1,0)";
Debug.ShouldStop(4096);
if (main.mostCurrent._chksounds.runMethod(true,"getChecked").<Boolean>get().booleanValue()) { 
main._sounds.runVoidMethod ("Play",(Object)(main._gigglesound),(Object)(BA.numberCast(float.class, 1)),(Object)(BA.numberCast(float.class, 1)),(Object)(BA.numberCast(int.class, 1)),(Object)(BA.numberCast(int.class, 1)),(Object)(BA.numberCast(float.class, 0)));};
 BA.debugLineNum = 398;BA.debugLine="Dim temp As View = GetViewByTag1(pnlBase, \"P\" & (currentPlayer + 1))";
Debug.ShouldStop(8192);
_temp = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");
_temp = _getviewbytag1(RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.ActivityWrapper"), main.mostCurrent._pnlbase.getObject()),RemoteObject.concat(RemoteObject.createImmutable("P"),(RemoteObject.solve(new RemoteObject[] {main._currentplayer,RemoteObject.createImmutable(1)}, "+",1, 1))));Debug.locals.put("temp", _temp);Debug.locals.put("temp", _temp);
 BA.debugLineNum = 399;BA.debugLine="If temp Is Label Then";
Debug.ShouldStop(16384);
if (RemoteObject.solveBoolean("i",_temp.getObjectOrNull(), RemoteObject.createImmutable("android.widget.TextView"))) { 
 BA.debugLineNum = 400;BA.debugLine="Dim lbl As Label = temp";
Debug.ShouldStop(32768);
_lbl = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
_lbl.setObject(_temp.getObject());Debug.locals.put("lbl", _lbl);
 BA.debugLineNum = 401;BA.debugLine="lbl.Text = \"Player \" & (currentPlayer + 1) & \" : \" & currPlayer.Score";
Debug.ShouldStop(65536);
_lbl.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Player "),(RemoteObject.solve(new RemoteObject[] {main._currentplayer,RemoteObject.createImmutable(1)}, "+",1, 1)),RemoteObject.createImmutable(" : "),_currplayer.getFieldClass("pineysoft.squarepaddocks.player", true,"_score"))));
 };
 BA.debugLineNum = 403;BA.debugLine="CheckAndDisplayWinnerScreen";
Debug.ShouldStop(262144);
_checkanddisplaywinnerscreen();
 };
 BA.debugLineNum = 406;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _checkanddisplaywinnerscreen() throws Exception{
try {
		Debug.PushSubsStack("CheckAndDisplayWinnerScreen (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("checkanddisplaywinnerscreen")) return main.remoteMe.runUserSub(false, "main","checkanddisplaywinnerscreen");
 BA.debugLineNum = 477;BA.debugLine="Sub CheckAndDisplayWinnerScreen()";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 478;BA.debugLine="If totalScore = gameWidth  * gameHeight Then";
Debug.ShouldStop(536870912);
if (RemoteObject.solveBoolean("=",main._totalscore,BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gamewidth,main._gameheight}, "*",0, 1)))) { 
 BA.debugLineNum = 479;BA.debugLine="If pnlOuter.IsInitialized Then";
Debug.ShouldStop(1073741824);
if (main.mostCurrent._pnlouter.runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 480;BA.debugLine="lblWinner.Text = \"Player \" & (currentPlayer + 1) & \" is the winner!!!\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._lblwinner.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Player "),(RemoteObject.solve(new RemoteObject[] {main._currentplayer,RemoteObject.createImmutable(1)}, "+",1, 1)),RemoteObject.createImmutable(" is the winner!!!"))));
 BA.debugLineNum = 481;BA.debugLine="imageIcon.Bitmap = playerImages.Get(currentPlayer)";
Debug.ShouldStop(1);
main.mostCurrent._imageicon.runMethod(false,"setBitmap",(main.mostCurrent._playerimages.runMethod(false,"Get",(Object)(BA.numberCast(int.class, main._currentplayer)))));
 BA.debugLineNum = 482;BA.debugLine="pnlOuter.Left = 0dip";
Debug.ShouldStop(2);
main.mostCurrent._pnlouter.runMethod(true,"setLeft",main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 0))));
 };
 };
 BA.debugLineNum = 485;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _closecompletedsquares(RemoteObject _currplayer) throws Exception{
try {
		Debug.PushSubsStack("CloseCompletedSquares (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("closecompletedsquares")) return main.remoteMe.runUserSub(false, "main","closecompletedsquares", _currplayer);
RemoteObject _allclosed = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _closed = RemoteObject.createImmutable(0);
RemoteObject _item = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 670;BA.debugLine="Sub CloseCompletedSquares(currPlayer As Player) As Int";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 671;BA.debugLine="Dim allClosed As List = FindAllForSides(4)";
Debug.ShouldStop(1073741824);
_allclosed = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_allclosed = _findallforsides(BA.numberCast(int.class, 4));Debug.locals.put("allClosed", _allclosed);Debug.locals.put("allClosed", _allclosed);
 BA.debugLineNum = 672;BA.debugLine="Dim closed As Int";
Debug.ShouldStop(-2147483648);
_closed = RemoteObject.createImmutable(0);Debug.locals.put("closed", _closed);
 BA.debugLineNum = 674;BA.debugLine="For Each item As GameSquare In allClosed";
Debug.ShouldStop(2);
final RemoteObject group539 = _allclosed;
final int groupLen539 = group539.runMethod(true,"getSize").<Integer>get();
for (int index539 = 0;index539 < groupLen539 ;index539++){
_item = (group539.runMethod(false,"Get",index539));Debug.locals.put("item", _item);
Debug.locals.put("item", _item);
 BA.debugLineNum = 675;BA.debugLine="If item.Occupied = False Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean("=",_item.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_occupied"),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 676;BA.debugLine="FillTheSquare(item, currPlayer)";
Debug.ShouldStop(8);
_fillthesquare(_item,_currplayer);
 BA.debugLineNum = 677;BA.debugLine="closed = closed + 1";
Debug.ShouldStop(16);
_closed = RemoteObject.solve(new RemoteObject[] {_closed,RemoteObject.createImmutable(1)}, "+",1, 1);Debug.locals.put("closed", _closed);
 BA.debugLineNum = 678;BA.debugLine="item.Occupied = True";
Debug.ShouldStop(32);
_item.setFieldClass("pineysoft.squarepaddocks.gamesquare", "_occupied",main.mostCurrent.__c.getField(true,"True"));
 };
 }
Debug.locals.put("item", _item);
;
 BA.debugLineNum = 682;BA.debugLine="Return closed";
Debug.ShouldStop(512);
if (true) return _closed;
 BA.debugLineNum = 683;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable(0);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _createboard() throws Exception{
try {
		Debug.PushSubsStack("CreateBoard (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("createboard")) return main.remoteMe.runUserSub(false, "main","createboard");
RemoteObject _colloop = RemoteObject.createImmutable(0);
RemoteObject _rowloop = RemoteObject.createImmutable(0);
RemoteObject _x = RemoteObject.createImmutable(0);
RemoteObject _y = RemoteObject.createImmutable(0);
RemoteObject _square = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
 BA.debugLineNum = 318;BA.debugLine="Sub CreateBoard";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 319;BA.debugLine="Dim colLoop As Int";
Debug.ShouldStop(1073741824);
_colloop = RemoteObject.createImmutable(0);Debug.locals.put("colLoop", _colloop);
 BA.debugLineNum = 320;BA.debugLine="Dim rowLoop As Int";
Debug.ShouldStop(-2147483648);
_rowloop = RemoteObject.createImmutable(0);Debug.locals.put("rowLoop", _rowloop);
 BA.debugLineNum = 321;BA.debugLine="Dim x As Int = columnSpacing / 2";
Debug.ShouldStop(1);
_x = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {main._columnspacing,RemoteObject.createImmutable(2)}, "/",0, 0));Debug.locals.put("x", _x);Debug.locals.put("x", _x);
 BA.debugLineNum = 322;BA.debugLine="Dim y As Int = rowSpacing / 2";
Debug.ShouldStop(2);
_y = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {main._rowspacing,RemoteObject.createImmutable(2)}, "/",0, 0));Debug.locals.put("y", _y);Debug.locals.put("y", _y);
 BA.debugLineNum = 323;BA.debugLine="Dim gameSquares(gameHeight,gameWidth) As GameSquare";
Debug.ShouldStop(4);
main.mostCurrent._gamesquares = RemoteObject.createNewArray ("pineysoft.squarepaddocks.gamesquare", new int[] {main._gameheight.<Integer>get().intValue(),main._gamewidth.<Integer>get().intValue()}, new Object[]{});
 BA.debugLineNum = 325;BA.debugLine="For rowLoop = 0 To gameHeight - 1";
Debug.ShouldStop(16);
{
final int step269 = 1;
final int limit269 = RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_rowloop = BA.numberCast(int.class, 0); (step269 > 0 && _rowloop.<Integer>get().intValue() <= limit269) || (step269 < 0 && _rowloop.<Integer>get().intValue() >= limit269); _rowloop = RemoteObject.createImmutable((int)(0 + _rowloop.<Integer>get().intValue() + step269))) {
Debug.locals.put("rowLoop", _rowloop);
 BA.debugLineNum = 326;BA.debugLine="For colLoop = 0 To gameWidth - 1";
Debug.ShouldStop(32);
{
final int step270 = 1;
final int limit270 = RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_colloop = BA.numberCast(int.class, 0); (step270 > 0 && _colloop.<Integer>get().intValue() <= limit270) || (step270 < 0 && _colloop.<Integer>get().intValue() >= limit270); _colloop = RemoteObject.createImmutable((int)(0 + _colloop.<Integer>get().intValue() + step270))) {
Debug.locals.put("colLoop", _colloop);
 BA.debugLineNum = 327;BA.debugLine="Dim square As GameSquare";
Debug.ShouldStop(64);
_square = RemoteObject.createNew ("pineysoft.squarepaddocks.gamesquare");Debug.locals.put("square", _square);
 BA.debugLineNum = 328;BA.debugLine="square.Initialize(x,y,columnSpacing,rowSpacing,rowLoop,colLoop)";
Debug.ShouldStop(128);
_square.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_initialize",main.mostCurrent.activityBA,(Object)(_x),(Object)(_y),(Object)(main._columnspacing),(Object)(main._rowspacing),(Object)(_rowloop),(Object)(_colloop));
 BA.debugLineNum = 329;BA.debugLine="gameSquares(rowLoop, colLoop) = square";
Debug.ShouldStop(256);
main.mostCurrent._gamesquares.setArrayElement (_square,_rowloop,_colloop);
 BA.debugLineNum = 330;BA.debugLine="x = x + columnSpacing";
Debug.ShouldStop(512);
_x = RemoteObject.solve(new RemoteObject[] {_x,main._columnspacing}, "+",1, 1);Debug.locals.put("x", _x);
 }
}Debug.locals.put("colLoop", _colloop);
;
 BA.debugLineNum = 332;BA.debugLine="x = columnSpacing / 2";
Debug.ShouldStop(2048);
_x = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {main._columnspacing,RemoteObject.createImmutable(2)}, "/",0, 0));Debug.locals.put("x", _x);
 BA.debugLineNum = 333;BA.debugLine="y = y + rowSpacing";
Debug.ShouldStop(4096);
_y = RemoteObject.solve(new RemoteObject[] {_y,main._rowspacing}, "+",1, 1);Debug.locals.put("y", _y);
 }
}Debug.locals.put("rowLoop", _rowloop);
;
 BA.debugLineNum = 335;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _createcolours() throws Exception{
try {
		Debug.PushSubsStack("CreateColours (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("createcolours")) return main.remoteMe.runUserSub(false, "main","createcolours");
 BA.debugLineNum = 204;BA.debugLine="Sub CreateColours()";
Debug.ShouldStop(2048);
 BA.debugLineNum = 205;BA.debugLine="playerColours.Initialize";
Debug.ShouldStop(4096);
main._playercolours.runVoidMethod ("Initialize");
 BA.debugLineNum = 206;BA.debugLine="playerColours.Add(Colors.Yellow)";
Debug.ShouldStop(8192);
main._playercolours.runVoidMethod ("Add",(Object)((main.mostCurrent.__c.getField(false,"Colors").getField(true,"Yellow"))));
 BA.debugLineNum = 207;BA.debugLine="playerColours.Add(Colors.Blue)";
Debug.ShouldStop(16384);
main._playercolours.runVoidMethod ("Add",(Object)((main.mostCurrent.__c.getField(false,"Colors").getField(true,"Blue"))));
 BA.debugLineNum = 208;BA.debugLine="playerColours.Add(Colors.Green)";
Debug.ShouldStop(32768);
main._playercolours.runVoidMethod ("Add",(Object)((main.mostCurrent.__c.getField(false,"Colors").getField(true,"Green"))));
 BA.debugLineNum = 209;BA.debugLine="playerColours.Add(Colors.Red)";
Debug.ShouldStop(65536);
main._playercolours.runVoidMethod ("Add",(Object)((main.mostCurrent.__c.getField(false,"Colors").getField(true,"Red"))));
 BA.debugLineNum = 210;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _createplayers() throws Exception{
try {
		Debug.PushSubsStack("CreatePlayers (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("createplayers")) return main.remoteMe.runUserSub(false, "main","createplayers");
RemoteObject _iloop = RemoteObject.createImmutable(0);
RemoteObject _playerval = RemoteObject.declareNull("pineysoft.squarepaddocks.player");
RemoteObject _v = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
RemoteObject _lbl = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
RemoteObject _vimage = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
RemoteObject _lblimage = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
 BA.debugLineNum = 246;BA.debugLine="Sub CreatePlayers";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 247;BA.debugLine="Dim iLoop As Int";
Debug.ShouldStop(4194304);
_iloop = RemoteObject.createImmutable(0);Debug.locals.put("iLoop", _iloop);
 BA.debugLineNum = 248;BA.debugLine="players.Initialize";
Debug.ShouldStop(8388608);
main.mostCurrent._players.runVoidMethod ("Initialize");
 BA.debugLineNum = 250;BA.debugLine="For iLoop = 1 To numberOfPlayers";
Debug.ShouldStop(33554432);
{
final int step204 = 1;
final int limit204 = main._numberofplayers.<Integer>get().intValue();
for (_iloop = BA.numberCast(int.class, 1); (step204 > 0 && _iloop.<Integer>get().intValue() <= limit204) || (step204 < 0 && _iloop.<Integer>get().intValue() >= limit204); _iloop = RemoteObject.createImmutable((int)(0 + _iloop.<Integer>get().intValue() + step204))) {
Debug.locals.put("iLoop", _iloop);
 BA.debugLineNum = 251;BA.debugLine="Dim playerVal As Player";
Debug.ShouldStop(67108864);
_playerval = RemoteObject.createNew ("pineysoft.squarepaddocks.player");Debug.locals.put("playerVal", _playerval);
 BA.debugLineNum = 252;BA.debugLine="playerVal.Initialize(\"Player \" & iLoop, playerColours.Get(iLoop - 1))";
Debug.ShouldStop(134217728);
_playerval.runClassMethod (pineysoft.squarepaddocks.player.class, "_initialize",main.processBA,(Object)(RemoteObject.concat(RemoteObject.createImmutable("Player "),_iloop)),(Object)(BA.numberCast(int.class, main._playercolours.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_iloop,RemoteObject.createImmutable(1)}, "-",1, 1))))));
 BA.debugLineNum = 253;BA.debugLine="If iLoop <= numberOfPlayers - numberOfDroids Then";
Debug.ShouldStop(268435456);
if (RemoteObject.solveBoolean("k",_iloop,BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._numberofplayers,main._numberofdroids}, "-",1, 1)))) { 
 BA.debugLineNum = 254;BA.debugLine="playerVal.PlayerType = SPConstants.PLAYER_TYPE_HUMAN";
Debug.ShouldStop(536870912);
_playerval.setFieldClass("pineysoft.squarepaddocks.player", "_playertype",main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_player_type_human"));
 }else {
 BA.debugLineNum = 256;BA.debugLine="playerVal.PlayerType = SPConstants.PLAYER_TYPE_DROID";
Debug.ShouldStop(-2147483648);
_playerval.setFieldClass("pineysoft.squarepaddocks.player", "_playertype",main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_player_type_droid"));
 };
 BA.debugLineNum = 258;BA.debugLine="Dim v As View = GetViewByTag1(pnlBase, \"P\" & iLoop)";
Debug.ShouldStop(2);
_v = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");
_v = _getviewbytag1(RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.ActivityWrapper"), main.mostCurrent._pnlbase.getObject()),RemoteObject.concat(RemoteObject.createImmutable("P"),_iloop));Debug.locals.put("v", _v);Debug.locals.put("v", _v);
 BA.debugLineNum = 259;BA.debugLine="If v Is Label Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean("i",_v.getObjectOrNull(), RemoteObject.createImmutable("android.widget.TextView"))) { 
 BA.debugLineNum = 260;BA.debugLine="Dim lbl As Label = v";
Debug.ShouldStop(8);
_lbl = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
_lbl.setObject(_v.getObject());Debug.locals.put("lbl", _lbl);
 BA.debugLineNum = 261;BA.debugLine="If playerVal.PlayerType = SPConstants.PLAYER_TYPE_HUMAN Then";
Debug.ShouldStop(16);
if (RemoteObject.solveBoolean("=",_playerval.getFieldClass("pineysoft.squarepaddocks.player", true,"_playertype"),BA.numberCast(double.class, main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_player_type_human")))) { 
 BA.debugLineNum = 262;BA.debugLine="lbl.Text = \"Player \" & iLoop";
Debug.ShouldStop(32);
_lbl.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Player "),_iloop)));
 }else {
 BA.debugLineNum = 264;BA.debugLine="lbl.Text = \"Droid \" & iLoop";
Debug.ShouldStop(128);
_lbl.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Droid "),_iloop)));
 };
 BA.debugLineNum = 266;BA.debugLine="If iLoop <= playerImages.Size Then";
Debug.ShouldStop(512);
if (RemoteObject.solveBoolean("k",_iloop,BA.numberCast(double.class, main.mostCurrent._playerimages.runMethod(true,"getSize")))) { 
 BA.debugLineNum = 267;BA.debugLine="Dim vImage As View = GetViewByTag1(pnlBase, \"I\" & iLoop)";
Debug.ShouldStop(1024);
_vimage = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");
_vimage = _getviewbytag1(RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.ActivityWrapper"), main.mostCurrent._pnlbase.getObject()),RemoteObject.concat(RemoteObject.createImmutable("I"),_iloop));Debug.locals.put("vImage", _vimage);Debug.locals.put("vImage", _vimage);
 BA.debugLineNum = 268;BA.debugLine="If vImage Is Label Then";
Debug.ShouldStop(2048);
if (RemoteObject.solveBoolean("i",_vimage.getObjectOrNull(), RemoteObject.createImmutable("android.widget.TextView"))) { 
 BA.debugLineNum = 269;BA.debugLine="Dim lblImage As Label = vImage";
Debug.ShouldStop(4096);
_lblimage = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
_lblimage.setObject(_vimage.getObject());Debug.locals.put("lblImage", _lblimage);
 BA.debugLineNum = 270;BA.debugLine="playerVal.PlayerImage = playerImages.Get(iLoop - 1)";
Debug.ShouldStop(8192);
_playerval.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").setObject (main.mostCurrent._playerimages.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_iloop,RemoteObject.createImmutable(1)}, "-",1, 1))));
 BA.debugLineNum = 271;BA.debugLine="lblImage.SetBackgroundImage(playerVal.PlayerImage)";
Debug.ShouldStop(16384);
_lblimage.runVoidMethod ("SetBackgroundImage",(Object)((_playerval.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").getObject())));
 BA.debugLineNum = 272;BA.debugLine="If playerVal.PlayerType = SPConstants.PLAYER_TYPE_DROID Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",_playerval.getFieldClass("pineysoft.squarepaddocks.player", true,"_playertype"),BA.numberCast(double.class, main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_player_type_droid")))) { 
 BA.debugLineNum = 273;BA.debugLine="lblImage.Text = \"D\"";
Debug.ShouldStop(65536);
_lblimage.runMethod(true,"setText",RemoteObject.createImmutable(("D")));
 };
 };
 };
 };
 BA.debugLineNum = 278;BA.debugLine="players.Add(playerVal)";
Debug.ShouldStop(2097152);
main.mostCurrent._players.runVoidMethod ("Add",(Object)((_playerval)));
 }
}Debug.locals.put("iLoop", _iloop);
;
 BA.debugLineNum = 280;BA.debugLine="currentPlayer = 0";
Debug.ShouldStop(8388608);
main._currentplayer = BA.numberCast(short.class, 0);
 BA.debugLineNum = 281;BA.debugLine="btnCurrPlayer.SetBackgroundImage(playerImages.Get(0))";
Debug.ShouldStop(16777216);
main.mostCurrent._btncurrplayer.runVoidMethod ("SetBackgroundImage",(Object)((main.mostCurrent._playerimages.runMethod(false,"Get",(Object)(BA.numberCast(int.class, 0))))));
 BA.debugLineNum = 283;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _displayfrontscreen() throws Exception{
try {
		Debug.PushSubsStack("DisplayFrontScreen (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("displayfrontscreen")) return main.remoteMe.runUserSub(false, "main","displayfrontscreen");
 BA.debugLineNum = 803;BA.debugLine="Sub DisplayFrontScreen";
Debug.ShouldStop(4);
 BA.debugLineNum = 804;BA.debugLine="If pnlBase.IsInitialized Then";
Debug.ShouldStop(8);
if (main.mostCurrent._pnlbase.runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 805;BA.debugLine="pnlBase.Left = 200%x";
Debug.ShouldStop(16);
main.mostCurrent._pnlbase.runMethod(true,"setLeft",main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 200)),main.mostCurrent.activityBA));
 };
 BA.debugLineNum = 807;BA.debugLine="pnlStartScreen.Left = 0dip";
Debug.ShouldStop(64);
main.mostCurrent._pnlstartscreen.runMethod(true,"setLeft",main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 0))));
 BA.debugLineNum = 808;BA.debugLine="inGame = False";
Debug.ShouldStop(128);
main._ingame = main.mostCurrent.__c.getField(true,"False");
 BA.debugLineNum = 809;BA.debugLine="ShowCharacters";
Debug.ShouldStop(256);
_showcharacters();
 BA.debugLineNum = 810;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _drawboard() throws Exception{
try {
		Debug.PushSubsStack("DrawBoard (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("drawboard")) return main.remoteMe.runUserSub(false, "main","drawboard");
RemoteObject _square = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
int _rowloop = 0;
int _colloop = 0;
RemoteObject _gsquare = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
 BA.debugLineNum = 337;BA.debugLine="Sub DrawBoard";
Debug.ShouldStop(65536);
 BA.debugLineNum = 338;BA.debugLine="Dim square As Rect";
Debug.ShouldStop(131072);
_square = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");Debug.locals.put("square", _square);
 BA.debugLineNum = 339;BA.debugLine="For rowLoop = 0 To gameHeight - 1";
Debug.ShouldStop(262144);
{
final int step282 = 1;
final int limit282 = RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_rowloop = 0; (step282 > 0 && _rowloop <= limit282) || (step282 < 0 && _rowloop >= limit282); _rowloop = ((int)(0 + _rowloop + step282))) {
Debug.locals.put("rowloop", _rowloop);
 BA.debugLineNum = 340;BA.debugLine="For colLoop = 0 To gameWidth - 1";
Debug.ShouldStop(524288);
{
final int step283 = 1;
final int limit283 = RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_colloop = 0; (step283 > 0 && _colloop <= limit283) || (step283 < 0 && _colloop >= limit283); _colloop = ((int)(0 + _colloop + step283))) {
Debug.locals.put("colloop", _colloop);
 BA.debugLineNum = 341;BA.debugLine="Dim gSquare As GameSquare = gameSquares(rowLoop, colLoop)";
Debug.ShouldStop(1048576);
_gsquare = main.mostCurrent._gamesquares.getArrayElement(false,BA.numberCast(int.class, _rowloop),BA.numberCast(int.class, _colloop));Debug.locals.put("gSquare", _gsquare);Debug.locals.put("gSquare", _gsquare);
 BA.debugLineNum = 343;BA.debugLine="square.Initialize(gSquare.TopLeft.Pos1-4dip,gSquare.TopLeft.Pos2-4dip,gSquare.TopLeft.Pos1+4dip,gSquare.TopLeft.Pos2+4dip)";
Debug.ShouldStop(4194304);
_square.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)));
 BA.debugLineNum = 344;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
Debug.ShouldStop(8388608);
main.mostCurrent._canv.runVoidMethod ("DrawRect",(Object)((_square.getObject())),(Object)(main.mostCurrent.__c.getField(false,"Colors").getField(true,"LightGray")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 BA.debugLineNum = 345;BA.debugLine="square.Initialize(gSquare.TopRight.Pos1-4dip,gSquare.TopRight.Pos2-4dip,gSquare.TopRight.Pos1+4dip,gSquare.TopRight.Pos2+4dip)";
Debug.ShouldStop(16777216);
_square.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)));
 BA.debugLineNum = 346;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
Debug.ShouldStop(33554432);
main.mostCurrent._canv.runVoidMethod ("DrawRect",(Object)((_square.getObject())),(Object)(main.mostCurrent.__c.getField(false,"Colors").getField(true,"LightGray")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 BA.debugLineNum = 347;BA.debugLine="square.Initialize(gSquare.BottomLeft.Pos1-4dip,gSquare.BottomLeft.Pos2-4dip,gSquare.BottomLeft.Pos1+4dip,gSquare.BottomLeft.Pos2+4dip)";
Debug.ShouldStop(67108864);
_square.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)));
 BA.debugLineNum = 348;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
Debug.ShouldStop(134217728);
main.mostCurrent._canv.runVoidMethod ("DrawRect",(Object)((_square.getObject())),(Object)(main.mostCurrent.__c.getField(false,"Colors").getField(true,"LightGray")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 BA.debugLineNum = 349;BA.debugLine="square.Initialize(gSquare.BottomRight.Pos1-4dip,gSquare.BottomRight.Pos2-4dip,gSquare.BottomRight.Pos1+4dip,gSquare.BottomRight.Pos2+4dip)";
Debug.ShouldStop(268435456);
_square.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_gsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)));
 BA.debugLineNum = 350;BA.debugLine="canv.DrawRect(square, Colors.LightGray, True, 1dip)";
Debug.ShouldStop(536870912);
main.mostCurrent._canv.runVoidMethod ("DrawRect",(Object)((_square.getObject())),(Object)(main.mostCurrent.__c.getField(false,"Colors").getField(true,"LightGray")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 BA.debugLineNum = 351;BA.debugLine="Log(\"Drawing \" & rowLoop & \", \" & colLoop)";
Debug.ShouldStop(1073741824);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Drawing "),RemoteObject.createImmutable(_rowloop),RemoteObject.createImmutable(", "),RemoteObject.createImmutable(_colloop))));
 }
}Debug.locals.put("colloop", _colloop);
;
 }
}Debug.locals.put("rowloop", _rowloop);
;
 BA.debugLineNum = 354;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _emptythesquare(RemoteObject _square) throws Exception{
try {
		Debug.PushSubsStack("EmptyTheSquare (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("emptythesquare")) return main.remoteMe.runUserSub(false, "main","emptythesquare", _square);
RemoteObject _fillrect = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
Debug.locals.put("square", _square);
 BA.debugLineNum = 705;BA.debugLine="Sub EmptyTheSquare(square As GameSquare)";
Debug.ShouldStop(1);
 BA.debugLineNum = 706;BA.debugLine="Dim fillRect As Rect";
Debug.ShouldStop(2);
_fillrect = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");Debug.locals.put("fillRect", _fillrect);
 BA.debugLineNum = 708;BA.debugLine="If square.fillLabel.IsInitialized Then";
Debug.ShouldStop(8);
if (_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_filllabel").runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 709;BA.debugLine="square.fillLabel.SetBackgroundImage(Null)";
Debug.ShouldStop(16);
_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_filllabel").runVoidMethod ("SetBackgroundImage",(Object)((main.mostCurrent.__c.getField(false,"Null"))));
 }else {
 BA.debugLineNum = 711;BA.debugLine="fillRect.Initialize(square.TopLeft.Pos1 + 4dip, square.TopLeft.pos2  + 4dip, square.BottomRight.pos1  - 4dip, square.BottomRight.Pos2  - 4dip)";
Debug.ShouldStop(64);
_fillrect.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)));
 BA.debugLineNum = 712;BA.debugLine="canv.DrawRect(fillRect,SPConstants.BG_COLOUR,True,1dip)";
Debug.ShouldStop(128);
main.mostCurrent._canv.runVoidMethod ("DrawRect",(Object)((_fillrect.getObject())),(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bg_colour")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 };
 BA.debugLineNum = 714;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _fillthesquare(RemoteObject _square,RemoteObject _currplayer) throws Exception{
try {
		Debug.PushSubsStack("FillTheSquare (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("fillthesquare")) return main.remoteMe.runUserSub(false, "main","fillthesquare", _square, _currplayer);
RemoteObject _fillrect = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
RemoteObject _lblnew = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
Debug.locals.put("square", _square);
Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 685;BA.debugLine="Sub FillTheSquare(square As GameSquare, currPlayer As Player)";
Debug.ShouldStop(4096);
 BA.debugLineNum = 686;BA.debugLine="Dim fillRect As Rect";
Debug.ShouldStop(8192);
_fillrect = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");Debug.locals.put("fillRect", _fillrect);
 BA.debugLineNum = 688;BA.debugLine="If currPlayer.PlayerImage.IsInitialized Then";
Debug.ShouldStop(32768);
if (_currplayer.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 689;BA.debugLine="If square.fillLabel.IsInitialized Then";
Debug.ShouldStop(65536);
if (_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_filllabel").runMethod(true,"IsInitialized").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 690;BA.debugLine="square.fillLabel.SetBackgroundImage(currPlayer.PlayerImage)";
Debug.ShouldStop(131072);
_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_filllabel").runVoidMethod ("SetBackgroundImage",(Object)((_currplayer.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").getObject())));
 }else {
 BA.debugLineNum = 692;BA.debugLine="Dim lblNew As Label";
Debug.ShouldStop(524288);
_lblnew = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");Debug.locals.put("lblNew", _lblnew);
 BA.debugLineNum = 693;BA.debugLine="lblNew.Initialize(\"\")";
Debug.ShouldStop(1048576);
_lblnew.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")));
 BA.debugLineNum = 694;BA.debugLine="lblNew.SetBackgroundImage(currPlayer.PlayerImage)";
Debug.ShouldStop(2097152);
_lblnew.runVoidMethod ("SetBackgroundImage",(Object)((_currplayer.getFieldClass("pineysoft.squarepaddocks.player", false,"_playerimage").getObject())));
 BA.debugLineNum = 695;BA.debugLine="lblNew.Gravity = Gravity.FILL";
Debug.ShouldStop(4194304);
_lblnew.runMethod(true,"setGravity",main.mostCurrent.__c.getField(false,"Gravity").getField(true,"FILL"));
 BA.debugLineNum = 696;BA.debugLine="square.fillLabel = lblNew";
Debug.ShouldStop(8388608);
_square.setFieldClass("pineysoft.squarepaddocks.gamesquare", "_filllabel",_lblnew);
 BA.debugLineNum = 697;BA.debugLine="panel1.AddView(lblNew, square.TopLeft.Pos1 + 4dip, square.TopLeft.Pos2  + 4dip, columnSpacing - 8dip, rowSpacing - 8dip)";
Debug.ShouldStop(16777216);
main.mostCurrent._panel1.runVoidMethod ("AddView",(Object)((_lblnew.getObject())),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {main._columnspacing,main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 8)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {main._rowspacing,main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 8)))}, "-",1, 1)));
 };
 }else {
 BA.debugLineNum = 700;BA.debugLine="fillRect.Initialize(square.TopLeft.Pos1 + 4dip, square.TopLeft.Pos2  + 4dip, square.BottomRight.Pos1  - 4dip, square.BottomRight.Pos2  - 4dip)";
Debug.ShouldStop(134217728);
_fillrect.runVoidMethod ("Initialize",(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "+",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)),(Object)(RemoteObject.solve(new RemoteObject[] {_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_bottomright").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 4)))}, "-",1, 1)));
 BA.debugLineNum = 701;BA.debugLine="canv.DrawRect(fillRect,currPlayer.colour,True,1dip)";
Debug.ShouldStop(268435456);
main.mostCurrent._canv.runVoidMethod ("DrawRect",(Object)((_fillrect.getObject())),(Object)(_currplayer.getFieldClass("pineysoft.squarepaddocks.player", true,"_colour")),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 1))))));
 };
 BA.debugLineNum = 703;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _findallforsides(RemoteObject _checksides) throws Exception{
try {
		Debug.PushSubsStack("FindAllForSides (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("findallforsides")) return main.remoteMe.runUserSub(false, "main","findallforsides", _checksides);
RemoteObject _foundsquares = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
int _row = 0;
int _col = 0;
Debug.locals.put("checkSides", _checksides);
 BA.debugLineNum = 789;BA.debugLine="Sub FindAllForSides(checkSides As Int) As List";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 790;BA.debugLine="Dim foundSquares As List";
Debug.ShouldStop(2097152);
_foundsquares = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");Debug.locals.put("foundSquares", _foundsquares);
 BA.debugLineNum = 791;BA.debugLine="foundSquares.Initialize";
Debug.ShouldStop(4194304);
_foundsquares.runVoidMethod ("Initialize");
 BA.debugLineNum = 792;BA.debugLine="For row = 0 To gameHeight - 1";
Debug.ShouldStop(8388608);
{
final int step641 = 1;
final int limit641 = RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_row = 0; (step641 > 0 && _row <= limit641) || (step641 < 0 && _row >= limit641); _row = ((int)(0 + _row + step641))) {
Debug.locals.put("row", _row);
 BA.debugLineNum = 793;BA.debugLine="For col = 0 To gameWidth - 1";
Debug.ShouldStop(16777216);
{
final int step642 = 1;
final int limit642 = RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_col = 0; (step642 > 0 && _col <= limit642) || (step642 < 0 && _col >= limit642); _col = ((int)(0 + _col + step642))) {
Debug.locals.put("col", _col);
 BA.debugLineNum = 794;BA.debugLine="If gameSquares(row,col).sidesTaken = checkSides Then";
Debug.ShouldStop(33554432);
if (RemoteObject.solveBoolean("=",main.mostCurrent._gamesquares.getArrayElement(false,BA.numberCast(int.class, _row),BA.numberCast(int.class, _col)).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, _checksides))) { 
 BA.debugLineNum = 795;BA.debugLine="foundSquares.Add(gameSquares(row,col))";
Debug.ShouldStop(67108864);
_foundsquares.runVoidMethod ("Add",(Object)((main.mostCurrent._gamesquares.getArrayElement(false,BA.numberCast(int.class, _row),BA.numberCast(int.class, _col)))));
 };
 }
}Debug.locals.put("col", _col);
;
 }
}Debug.locals.put("row", _row);
;
 BA.debugLineNum = 800;BA.debugLine="Return foundSquares";
Debug.ShouldStop(-2147483648);
if (true) return _foundsquares;
 BA.debugLineNum = 801;BA.debugLine="End Sub";
Debug.ShouldStop(1);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _findselectedsquare(RemoteObject _xpos,RemoteObject _ypos) throws Exception{
try {
		Debug.PushSubsStack("FindSelectedSquare (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("findselectedsquare")) return main.remoteMe.runUserSub(false, "main","findselectedsquare", _xpos, _ypos);
RemoteObject _colloop = RemoteObject.createImmutable(0);
RemoteObject _rowloop = RemoteObject.createImmutable(0);
RemoteObject _foundrow = RemoteObject.createImmutable(0);
RemoteObject _foundcol = RemoteObject.createImmutable(0);
RemoteObject _square = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
Debug.locals.put("xpos", _xpos);
Debug.locals.put("ypos", _ypos);
 BA.debugLineNum = 716;BA.debugLine="Sub FindSelectedSquare(xpos As Int, ypos As Int) As GameSquare";
Debug.ShouldStop(2048);
 BA.debugLineNum = 717;BA.debugLine="Dim colLoop As Int = 0";
Debug.ShouldStop(4096);
_colloop = BA.numberCast(int.class, 0);Debug.locals.put("colLoop", _colloop);Debug.locals.put("colLoop", _colloop);
 BA.debugLineNum = 718;BA.debugLine="Dim rowloop As Int = 0";
Debug.ShouldStop(8192);
_rowloop = BA.numberCast(int.class, 0);Debug.locals.put("rowloop", _rowloop);Debug.locals.put("rowloop", _rowloop);
 BA.debugLineNum = 719;BA.debugLine="Dim foundRow As Int = -1";
Debug.ShouldStop(16384);
_foundrow = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundRow", _foundrow);Debug.locals.put("foundRow", _foundrow);
 BA.debugLineNum = 720;BA.debugLine="Dim foundCol As Int = -1";
Debug.ShouldStop(32768);
_foundcol = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundCol", _foundcol);Debug.locals.put("foundCol", _foundcol);
 BA.debugLineNum = 721;BA.debugLine="Dim square As GameSquare";
Debug.ShouldStop(65536);
_square = RemoteObject.createNew ("pineysoft.squarepaddocks.gamesquare");Debug.locals.put("square", _square);
 BA.debugLineNum = 723;BA.debugLine="For rowloop = 0 To gameHeight - 1";
Debug.ShouldStop(262144);
{
final int step581 = 1;
final int limit581 = RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_rowloop = BA.numberCast(int.class, 0); (step581 > 0 && _rowloop.<Integer>get().intValue() <= limit581) || (step581 < 0 && _rowloop.<Integer>get().intValue() >= limit581); _rowloop = RemoteObject.createImmutable((int)(0 + _rowloop.<Integer>get().intValue() + step581))) {
Debug.locals.put("rowloop", _rowloop);
 BA.debugLineNum = 724;BA.debugLine="square = gameSquares(rowloop, 0)";
Debug.ShouldStop(524288);
_square = main.mostCurrent._gamesquares.getArrayElement(false,_rowloop,BA.numberCast(int.class, 0));Debug.locals.put("square", _square);
 BA.debugLineNum = 725;BA.debugLine="If square.TopLeft.pos2 > ypos Then";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean(">",_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos2"),BA.numberCast(double.class, _ypos))) { 
 BA.debugLineNum = 726;BA.debugLine="If rowloop = 0 Then";
Debug.ShouldStop(2097152);
if (RemoteObject.solveBoolean("=",_rowloop,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 727;BA.debugLine="foundRow = 0";
Debug.ShouldStop(4194304);
_foundrow = BA.numberCast(int.class, 0);Debug.locals.put("foundRow", _foundrow);
 }else {
 BA.debugLineNum = 729;BA.debugLine="foundRow = rowloop - 1";
Debug.ShouldStop(16777216);
_foundrow = RemoteObject.solve(new RemoteObject[] {_rowloop,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("foundRow", _foundrow);
 };
 BA.debugLineNum = 731;BA.debugLine="rowloop = gameHeight -1";
Debug.ShouldStop(67108864);
_rowloop = RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("rowloop", _rowloop);
 };
 }
}Debug.locals.put("rowloop", _rowloop);
;
 BA.debugLineNum = 735;BA.debugLine="If foundRow = -1 Then foundRow = gameHeight-1";
Debug.ShouldStop(1073741824);
if (RemoteObject.solveBoolean("=",_foundrow,BA.numberCast(double.class, -(double) (0 + 1)))) { 
_foundrow = RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("foundRow", _foundrow);};
 BA.debugLineNum = 737;BA.debugLine="For colLoop = 0 To gameWidth - 1";
Debug.ShouldStop(1);
{
final int step593 = 1;
final int limit593 = RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_colloop = BA.numberCast(int.class, 0); (step593 > 0 && _colloop.<Integer>get().intValue() <= limit593) || (step593 < 0 && _colloop.<Integer>get().intValue() >= limit593); _colloop = RemoteObject.createImmutable((int)(0 + _colloop.<Integer>get().intValue() + step593))) {
Debug.locals.put("colLoop", _colloop);
 BA.debugLineNum = 738;BA.debugLine="square = gameSquares(foundRow, colLoop)";
Debug.ShouldStop(2);
_square = main.mostCurrent._gamesquares.getArrayElement(false,_foundrow,_colloop);Debug.locals.put("square", _square);
 BA.debugLineNum = 739;BA.debugLine="If square.TopLeft.pos1 > xpos  Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean(">",_square.getFieldClass("pineysoft.squarepaddocks.gamesquare", false,"_topleft").getFieldClass("pineysoft.squarepaddocks.point", true,"_pos1"),BA.numberCast(double.class, _xpos))) { 
 BA.debugLineNum = 740;BA.debugLine="If colLoop = 0 Then";
Debug.ShouldStop(8);
if (RemoteObject.solveBoolean("=",_colloop,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 741;BA.debugLine="foundCol = 0";
Debug.ShouldStop(16);
_foundcol = BA.numberCast(int.class, 0);Debug.locals.put("foundCol", _foundcol);
 }else {
 BA.debugLineNum = 743;BA.debugLine="foundCol = colLoop - 1";
Debug.ShouldStop(64);
_foundcol = RemoteObject.solve(new RemoteObject[] {_colloop,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("foundCol", _foundcol);
 };
 BA.debugLineNum = 745;BA.debugLine="colLoop = gameWidth - 1";
Debug.ShouldStop(256);
_colloop = RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("colLoop", _colloop);
 };
 }
}Debug.locals.put("colLoop", _colloop);
;
 BA.debugLineNum = 749;BA.debugLine="If foundCol = -1 Then foundCol = gameWidth - 1";
Debug.ShouldStop(4096);
if (RemoteObject.solveBoolean("=",_foundcol,BA.numberCast(double.class, -(double) (0 + 1)))) { 
_foundcol = RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("foundCol", _foundcol);};
 BA.debugLineNum = 751;BA.debugLine="Return gameSquares(foundRow,foundCol)";
Debug.ShouldStop(16384);
if (true) return main.mostCurrent._gamesquares.getArrayElement(false,_foundrow,_foundcol);
 BA.debugLineNum = 752;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _getviewbytag(RemoteObject _tag) throws Exception{
try {
		Debug.PushSubsStack("GetViewByTag (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("getviewbytag")) return main.remoteMe.runUserSub(false, "main","getviewbytag", _tag);
RemoteObject _tempview = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
RemoteObject _vw = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
Debug.locals.put("tag", _tag);
 BA.debugLineNum = 754;BA.debugLine="Sub GetViewByTag(tag As String) As View";
Debug.ShouldStop(131072);
 BA.debugLineNum = 755;BA.debugLine="Dim tempView As View";
Debug.ShouldStop(262144);
_tempview = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");Debug.locals.put("tempView", _tempview);
 BA.debugLineNum = 756;BA.debugLine="For Each vw As View In Activity.GetAllViewsRecursive";
Debug.ShouldStop(524288);
_vw = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");
final RemoteObject group609 = main.mostCurrent._activity.runMethod(false,"GetAllViewsRecursive");
final int groupLen609 = group609.runMethod(true,"getSize").<Integer>get();
for (int index609 = 0;index609 < groupLen609 ;index609++){
_vw.setObject(group609.runMethod(false,"Get",index609));
Debug.locals.put("vw", _vw);
 BA.debugLineNum = 757;BA.debugLine="If tempView.tag = tag Then";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean("=",_tempview.runMethod(false,"getTag"),(_tag))) { 
 BA.debugLineNum = 758;BA.debugLine="Return tempView";
Debug.ShouldStop(2097152);
if (true) return _tempview;
 };
 }
Debug.locals.put("vw", _vw);
;
 BA.debugLineNum = 761;BA.debugLine="Return tempView";
Debug.ShouldStop(16777216);
if (true) return _tempview;
 BA.debugLineNum = 762;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _getviewbytag1(RemoteObject _searchview,RemoteObject _tag) throws Exception{
try {
		Debug.PushSubsStack("GetViewByTag1 (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("getviewbytag1")) return main.remoteMe.runUserSub(false, "main","getviewbytag1", _searchview, _tag);
RemoteObject _tempview = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
RemoteObject _vwloop = RemoteObject.createImmutable(0);
Debug.locals.put("searchView", _searchview);
Debug.locals.put("tag", _tag);
 BA.debugLineNum = 764;BA.debugLine="Sub GetViewByTag1(searchView As Activity, tag As String) As View";
Debug.ShouldStop(134217728);
 BA.debugLineNum = 766;BA.debugLine="Dim tempView As View";
Debug.ShouldStop(536870912);
_tempview = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");Debug.locals.put("tempView", _tempview);
 BA.debugLineNum = 767;BA.debugLine="Dim vwloop As Int";
Debug.ShouldStop(1073741824);
_vwloop = RemoteObject.createImmutable(0);Debug.locals.put("vwloop", _vwloop);
 BA.debugLineNum = 768;BA.debugLine="For vwloop = 0 To searchView.NumberOfViews - 1";
Debug.ShouldStop(-2147483648);
{
final int step619 = 1;
final int limit619 = RemoteObject.solve(new RemoteObject[] {_searchview.runMethod(true,"getNumberOfViews"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_vwloop = BA.numberCast(int.class, 0); (step619 > 0 && _vwloop.<Integer>get().intValue() <= limit619) || (step619 < 0 && _vwloop.<Integer>get().intValue() >= limit619); _vwloop = RemoteObject.createImmutable((int)(0 + _vwloop.<Integer>get().intValue() + step619))) {
Debug.locals.put("vwloop", _vwloop);
 BA.debugLineNum = 769;BA.debugLine="tempView = searchView.GetView(vwloop)";
Debug.ShouldStop(1);
_tempview = _searchview.runMethod(false,"GetView",(Object)(_vwloop));Debug.locals.put("tempView", _tempview);
 BA.debugLineNum = 770;BA.debugLine="If tempView.tag = tag Then";
Debug.ShouldStop(2);
if (RemoteObject.solveBoolean("=",_tempview.runMethod(false,"getTag"),(_tag))) { 
 BA.debugLineNum = 771;BA.debugLine="Return tempView";
Debug.ShouldStop(4);
if (true) return _tempview;
 };
 }
}Debug.locals.put("vwloop", _vwloop);
;
 BA.debugLineNum = 774;BA.debugLine="Return tempView";
Debug.ShouldStop(32);
if (true) return _tempview;
 BA.debugLineNum = 775;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _getviewbytag2(RemoteObject _searchview,RemoteObject _tag) throws Exception{
try {
		Debug.PushSubsStack("GetViewByTag2 (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("getviewbytag2")) return main.remoteMe.runUserSub(false, "main","getviewbytag2", _searchview, _tag);
RemoteObject _tempview = RemoteObject.declareNull("anywheresoftware.b4a.objects.ConcreteViewWrapper");
RemoteObject _vwloop = RemoteObject.createImmutable(0);
Debug.locals.put("searchView", _searchview);
Debug.locals.put("tag", _tag);
 BA.debugLineNum = 777;BA.debugLine="Sub GetViewByTag2(searchView As Panel, tag As String) As View";
Debug.ShouldStop(256);
 BA.debugLineNum = 778;BA.debugLine="Dim tempView As View";
Debug.ShouldStop(512);
_tempview = RemoteObject.createNew ("anywheresoftware.b4a.objects.ConcreteViewWrapper");Debug.locals.put("tempView", _tempview);
 BA.debugLineNum = 779;BA.debugLine="Dim vwloop As Int";
Debug.ShouldStop(1024);
_vwloop = RemoteObject.createImmutable(0);Debug.locals.put("vwloop", _vwloop);
 BA.debugLineNum = 780;BA.debugLine="For vwloop = 0 To searchView.NumberOfViews - 1";
Debug.ShouldStop(2048);
{
final int step630 = 1;
final int limit630 = RemoteObject.solve(new RemoteObject[] {_searchview.runMethod(true,"getNumberOfViews"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_vwloop = BA.numberCast(int.class, 0); (step630 > 0 && _vwloop.<Integer>get().intValue() <= limit630) || (step630 < 0 && _vwloop.<Integer>get().intValue() >= limit630); _vwloop = RemoteObject.createImmutable((int)(0 + _vwloop.<Integer>get().intValue() + step630))) {
Debug.locals.put("vwloop", _vwloop);
 BA.debugLineNum = 781;BA.debugLine="tempView = searchView.GetView(vwloop)";
Debug.ShouldStop(4096);
_tempview = _searchview.runMethod(false,"GetView",(Object)(_vwloop));Debug.locals.put("tempView", _tempview);
 BA.debugLineNum = 782;BA.debugLine="If tempView.tag = tag Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",_tempview.runMethod(false,"getTag"),(_tag))) { 
 BA.debugLineNum = 783;BA.debugLine="Return tempView";
Debug.ShouldStop(16384);
if (true) return _tempview;
 };
 }
}Debug.locals.put("vwloop", _vwloop);
;
 BA.debugLineNum = 786;BA.debugLine="Return tempView";
Debug.ShouldStop(131072);
if (true) return _tempview;
 BA.debugLineNum = 787;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("pineysoft.squarepaddocks.main");
point.myClass = BA.getDeviceClass ("pineysoft.squarepaddocks.point");
player.myClass = BA.getDeviceClass ("pineysoft.squarepaddocks.player");
constants.myClass = BA.getDeviceClass ("pineysoft.squarepaddocks.constants");
gamesquare.myClass = BA.getDeviceClass ("pineysoft.squarepaddocks.gamesquare");
turn.myClass = BA.getDeviceClass ("pineysoft.squarepaddocks.turn");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 32;BA.debugLine="Private gameSquares(,) As GameSquare";
main.mostCurrent._gamesquares = RemoteObject.createNewArray ("pineysoft.squarepaddocks.gamesquare", new int[] {0,0}, new Object[]{});
 //BA.debugLineNum = 33;BA.debugLine="Dim gameTurns As List";
main.mostCurrent._gameturns = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
 //BA.debugLineNum = 34;BA.debugLine="Private gameWidth As Int = 7";
main._gamewidth = BA.numberCast(int.class, 7);
 //BA.debugLineNum = 35;BA.debugLine="Private gameHeight As Int = 9";
main._gameheight = BA.numberCast(int.class, 9);
 //BA.debugLineNum = 36;BA.debugLine="Private columnSpacing As Int";
main._columnspacing = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 37;BA.debugLine="Private rowSpacing As Int";
main._rowspacing = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 38;BA.debugLine="Private panel1 As Panel";
main.mostCurrent._panel1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 39;BA.debugLine="Private canv As Canvas";
main.mostCurrent._canv = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper");
 //BA.debugLineNum = 40;BA.debugLine="Private players As List";
main.mostCurrent._players = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
 //BA.debugLineNum = 41;BA.debugLine="Private playerImages As List";
main.mostCurrent._playerimages = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
 //BA.debugLineNum = 42;BA.debugLine="Private lblPlayer1 As Label";
main.mostCurrent._lblplayer1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 43;BA.debugLine="Private lblPlayer1Image As Label";
main.mostCurrent._lblplayer1image = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 44;BA.debugLine="Private lblPlayer2 As Label";
main.mostCurrent._lblplayer2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 45;BA.debugLine="Private lblPlayer2Image As Label";
main.mostCurrent._lblplayer2image = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 46;BA.debugLine="Private lblPlayer3 As Label";
main.mostCurrent._lblplayer3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 47;BA.debugLine="Private lblPlayer3Image As Label";
main.mostCurrent._lblplayer3image = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 48;BA.debugLine="Private lblPlayer4 As Label";
main.mostCurrent._lblplayer4 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 49;BA.debugLine="Private lblPlayer4Image As Label";
main.mostCurrent._lblplayer4image = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 50;BA.debugLine="Private btnContinue As Button";
main.mostCurrent._btncontinue = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 51;BA.debugLine="Private spnPlayers As Spinner";
main.mostCurrent._spnplayers = RemoteObject.createNew ("anywheresoftware.b4a.objects.SpinnerWrapper");
 //BA.debugLineNum = 52;BA.debugLine="Private sbColumns As SeekBar";
main.mostCurrent._sbcolumns = RemoteObject.createNew ("anywheresoftware.b4a.objects.SeekBarWrapper");
 //BA.debugLineNum = 53;BA.debugLine="Private sbRows As SeekBar";
main.mostCurrent._sbrows = RemoteObject.createNew ("anywheresoftware.b4a.objects.SeekBarWrapper");
 //BA.debugLineNum = 54;BA.debugLine="Private pnlStartScreen As Panel";
main.mostCurrent._pnlstartscreen = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 55;BA.debugLine="Private icon1 As ImageView";
main.mostCurrent._icon1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 56;BA.debugLine="Private icon2 As ImageView";
main.mostCurrent._icon2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 57;BA.debugLine="Private icon3 As ImageView";
main.mostCurrent._icon3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 58;BA.debugLine="Private icon4 As ImageView";
main.mostCurrent._icon4 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 59;BA.debugLine="Private lblColumns As Label";
main.mostCurrent._lblcolumns = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 60;BA.debugLine="Private lblPlayers As Label";
main.mostCurrent._lblplayers = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 61;BA.debugLine="Private lblRows As Label";
main.mostCurrent._lblrows = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 62;BA.debugLine="Private pnlBase As Panel";
main.mostCurrent._pnlbase = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 63;BA.debugLine="Private btnCurrPlayer As Button";
main.mostCurrent._btncurrplayer = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 64;BA.debugLine="Private icon5 As ImageView";
main.mostCurrent._icon5 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 65;BA.debugLine="Private icon6 As ImageView";
main.mostCurrent._icon6 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 66;BA.debugLine="Private pnlDisplay As Panel";
main.mostCurrent._pnldisplay = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 67;BA.debugLine="Private pnlOuter As Panel";
main.mostCurrent._pnlouter = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 68;BA.debugLine="Private imageIcon As ImageView";
main.mostCurrent._imageicon = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 69;BA.debugLine="Private lblWinner As Label";
main.mostCurrent._lblwinner = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 70;BA.debugLine="Private chkSounds As CheckBox";
main.mostCurrent._chksounds = RemoteObject.createNew ("anywheresoftware.b4a.objects.CompoundButtonWrapper.CheckBoxWrapper");
 //BA.debugLineNum = 71;BA.debugLine="Dim anim1 As AnimationPlus";
main.mostCurrent._anim1 = RemoteObject.createNew ("flm.b4a.animationplus.AnimationPlusWrapper");
 //BA.debugLineNum = 72;BA.debugLine="Dim anim2 As AnimationPlus";
main.mostCurrent._anim2 = RemoteObject.createNew ("flm.b4a.animationplus.AnimationPlusWrapper");
 //BA.debugLineNum = 73;BA.debugLine="Dim anim3 As AnimationPlus";
main.mostCurrent._anim3 = RemoteObject.createNew ("flm.b4a.animationplus.AnimationPlusWrapper");
 //BA.debugLineNum = 74;BA.debugLine="Dim anim4 As AnimationPlus";
main.mostCurrent._anim4 = RemoteObject.createNew ("flm.b4a.animationplus.AnimationPlusWrapper");
 //BA.debugLineNum = 75;BA.debugLine="Dim anim5 As AnimationPlus";
main.mostCurrent._anim5 = RemoteObject.createNew ("flm.b4a.animationplus.AnimationPlusWrapper");
 //BA.debugLineNum = 76;BA.debugLine="Dim anim6 As AnimationPlus";
main.mostCurrent._anim6 = RemoteObject.createNew ("flm.b4a.animationplus.AnimationPlusWrapper");
 //BA.debugLineNum = 77;BA.debugLine="Private spnDroids As Spinner";
main.mostCurrent._spndroids = RemoteObject.createNew ("anywheresoftware.b4a.objects.SpinnerWrapper");
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _initgameplay() throws Exception{
try {
		Debug.PushSubsStack("InitGamePlay (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("initgameplay")) return main.remoteMe.runUserSub(false, "main","initgameplay");
 BA.debugLineNum = 285;BA.debugLine="Public Sub InitGamePlay";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 286;BA.debugLine="numberOfPlayers = spnPlayers.SelectedItem";
Debug.ShouldStop(536870912);
main._numberofplayers = BA.numberCast(int.class, main.mostCurrent._spnplayers.runMethod(true,"getSelectedItem"));
 BA.debugLineNum = 287;BA.debugLine="numberOfDroids = spnDroids.SelectedItem";
Debug.ShouldStop(1073741824);
main._numberofdroids = BA.numberCast(int.class, main.mostCurrent._spndroids.runMethod(true,"getSelectedItem"));
 BA.debugLineNum = 288;BA.debugLine="gameHeight = sbRows.Value";
Debug.ShouldStop(-2147483648);
main._gameheight = main.mostCurrent._sbrows.runMethod(true,"getValue");
 BA.debugLineNum = 289;BA.debugLine="gameWidth = sbColumns.Value";
Debug.ShouldStop(1);
main._gamewidth = main.mostCurrent._sbcolumns.runMethod(true,"getValue");
 BA.debugLineNum = 290;BA.debugLine="columnSpacing = panel1.Width / (gameWidth + 1)";
Debug.ShouldStop(2);
main._columnspacing = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent._panel1.runMethod(true,"getWidth"),(RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "+",1, 1))}, "/",0, 0));
 BA.debugLineNum = 291;BA.debugLine="rowSpacing = panel1.Height / (gameHeight + 1)";
Debug.ShouldStop(4);
main._rowspacing = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent._panel1.runMethod(true,"getHeight"),(RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "+",1, 1))}, "/",0, 0));
 BA.debugLineNum = 292;BA.debugLine="canv.Initialize(panel1)";
Debug.ShouldStop(8);
main.mostCurrent._canv.runVoidMethod ("Initialize",(Object)((main.mostCurrent._panel1.getObject())));
 BA.debugLineNum = 293;BA.debugLine="totalScore = 0";
Debug.ShouldStop(16);
main._totalscore = BA.numberCast(int.class, 0);
 BA.debugLineNum = 294;BA.debugLine="gameTurns.Initialize";
Debug.ShouldStop(32);
main.mostCurrent._gameturns.runVoidMethod ("Initialize");
 BA.debugLineNum = 296;BA.debugLine="CreateBoard";
Debug.ShouldStop(128);
_createboard();
 BA.debugLineNum = 297;BA.debugLine="DrawBoard";
Debug.ShouldStop(256);
_drawboard();
 BA.debugLineNum = 298;BA.debugLine="CreatePlayers";
Debug.ShouldStop(512);
_createplayers();
 BA.debugLineNum = 299;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _initialisesounds() throws Exception{
try {
		Debug.PushSubsStack("InitialiseSounds (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("initialisesounds")) return main.remoteMe.runUserSub(false, "main","initialisesounds");
 BA.debugLineNum = 242;BA.debugLine="Sub InitialiseSounds";
Debug.ShouldStop(131072);
 BA.debugLineNum = 243;BA.debugLine="sounds.Initialize(10)";
Debug.ShouldStop(262144);
main._sounds.runVoidMethod ("Initialize",(Object)(BA.numberCast(int.class, 10)));
 BA.debugLineNum = 244;BA.debugLine="giggleSound = sounds.Load(File.DirAssets, \"Giggle1.mp3\")";
Debug.ShouldStop(524288);
main._gigglesound = main._sounds.runMethod(true,"Load",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(BA.ObjectToString("Giggle1.mp3")));
 BA.debugLineNum = 245;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _loadimages() throws Exception{
try {
		Debug.PushSubsStack("LoadImages (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("loadimages")) return main.remoteMe.runUserSub(false, "main","loadimages");
RemoteObject _moreimages = RemoteObject.createImmutable(false);
RemoteObject _imageloop = RemoteObject.createImmutable(0);
RemoteObject _bm = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
 BA.debugLineNum = 212;BA.debugLine="Sub LoadImages";
Debug.ShouldStop(524288);
 BA.debugLineNum = 213;BA.debugLine="Dim moreImages As Boolean = True";
Debug.ShouldStop(1048576);
_moreimages = main.mostCurrent.__c.getField(true,"True");Debug.locals.put("moreImages", _moreimages);Debug.locals.put("moreImages", _moreimages);
 BA.debugLineNum = 214;BA.debugLine="Dim imageLoop As Int = 1";
Debug.ShouldStop(2097152);
_imageloop = BA.numberCast(int.class, 1);Debug.locals.put("imageLoop", _imageloop);Debug.locals.put("imageLoop", _imageloop);
 BA.debugLineNum = 216;BA.debugLine="playerImages.Initialize";
Debug.ShouldStop(8388608);
main.mostCurrent._playerimages.runVoidMethod ("Initialize");
 BA.debugLineNum = 218;BA.debugLine="Do While moreImages = True";
Debug.ShouldStop(33554432);
while (RemoteObject.solveBoolean("=",_moreimages,main.mostCurrent.__c.getField(true,"True"))) {
 BA.debugLineNum = 219;BA.debugLine="If File.Exists(File.DirAssets,\"cuteImage\" & imageLoop & \".png\") Then";
Debug.ShouldStop(67108864);
if (main.mostCurrent.__c.getField(false,"File").runMethod(true,"Exists",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(RemoteObject.concat(RemoteObject.createImmutable("cuteImage"),_imageloop,RemoteObject.createImmutable(".png")))).<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 220;BA.debugLine="Dim bm As Bitmap";
Debug.ShouldStop(134217728);
_bm = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");Debug.locals.put("bm", _bm);
 BA.debugLineNum = 221;BA.debugLine="bm.Initialize(File.DirAssets, \"cuteImage\" & imageLoop & \".png\")";
Debug.ShouldStop(268435456);
_bm.runVoidMethod ("Initialize",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirAssets")),(Object)(RemoteObject.concat(RemoteObject.createImmutable("cuteImage"),_imageloop,RemoteObject.createImmutable(".png"))));
 BA.debugLineNum = 222;BA.debugLine="playerImages.Add(bm)";
Debug.ShouldStop(536870912);
main.mostCurrent._playerimages.runVoidMethod ("Add",(Object)((_bm.getObject())));
 BA.debugLineNum = 223;BA.debugLine="imageLoop = imageLoop + 1";
Debug.ShouldStop(1073741824);
_imageloop = RemoteObject.solve(new RemoteObject[] {_imageloop,RemoteObject.createImmutable(1)}, "+",1, 1);Debug.locals.put("imageLoop", _imageloop);
 }else {
 BA.debugLineNum = 225;BA.debugLine="moreImages = False";
Debug.ShouldStop(1);
_moreimages = main.mostCurrent.__c.getField(true,"False");Debug.locals.put("moreImages", _moreimages);
 };
 }
;
 BA.debugLineNum = 228;BA.debugLine="End Sub";
Debug.ShouldStop(8);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _loadplayerspinner() throws Exception{
try {
		Debug.PushSubsStack("LoadPlayerSpinner (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("loadplayerspinner")) return main.remoteMe.runUserSub(false, "main","loadplayerspinner");
 BA.debugLineNum = 230;BA.debugLine="Sub LoadPlayerSpinner";
Debug.ShouldStop(32);
 BA.debugLineNum = 232;BA.debugLine="spnPlayers.AddAll(Array As Int(2,3,4))";
Debug.ShouldStop(128);
main.mostCurrent._spnplayers.runVoidMethod ("AddAll",(Object)(main.mostCurrent.__c.runMethod(false, "ArrayToList", (Object)(RemoteObject.createNewArray("int",new int[] {3},new Object[] {BA.numberCast(int.class, 2),BA.numberCast(int.class, 3),BA.numberCast(int.class, 4)})))));
 BA.debugLineNum = 233;BA.debugLine="spnDroids.AddAll(Array As Int(0,1,2,3))";
Debug.ShouldStop(256);
main.mostCurrent._spndroids.runVoidMethod ("AddAll",(Object)(main.mostCurrent.__c.runMethod(false, "ArrayToList", (Object)(RemoteObject.createNewArray("int",new int[] {4},new Object[] {BA.numberCast(int.class, 0),BA.numberCast(int.class, 1),BA.numberCast(int.class, 2),BA.numberCast(int.class, 3)})))));
 BA.debugLineNum = 235;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _makedroidmove(RemoteObject _currplayer) throws Exception{
try {
		Debug.PushSubsStack("MakeDroidMove (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("makedroidmove")) return main.remoteMe.runUserSub(false, "main","makedroidmove", _currplayer);
RemoteObject _found3s = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _found2s = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _found1s = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _found0s = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _numberclosed = RemoteObject.createImmutable(0);
Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 486;BA.debugLine="Sub MakeDroidMove(currPlayer As Player)";
Debug.ShouldStop(32);
 BA.debugLineNum = 487;BA.debugLine="Dim found3s As List = FindAllForSides(3)";
Debug.ShouldStop(64);
_found3s = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_found3s = _findallforsides(BA.numberCast(int.class, 3));Debug.locals.put("found3s", _found3s);Debug.locals.put("found3s", _found3s);
 BA.debugLineNum = 488;BA.debugLine="Dim found2s As List = FindAllForSides(2)";
Debug.ShouldStop(128);
_found2s = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_found2s = _findallforsides(BA.numberCast(int.class, 2));Debug.locals.put("found2s", _found2s);Debug.locals.put("found2s", _found2s);
 BA.debugLineNum = 489;BA.debugLine="Dim found1s As List = FindAllForSides(1)";
Debug.ShouldStop(256);
_found1s = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_found1s = _findallforsides(BA.numberCast(int.class, 1));Debug.locals.put("found1s", _found1s);Debug.locals.put("found1s", _found1s);
 BA.debugLineNum = 490;BA.debugLine="Dim found0s As List = FindAllForSides(0)";
Debug.ShouldStop(512);
_found0s = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_found0s = _findallforsides(BA.numberCast(int.class, 0));Debug.locals.put("found0s", _found0s);Debug.locals.put("found0s", _found0s);
 BA.debugLineNum = 492;BA.debugLine="Log(found3s.Size)";
Debug.ShouldStop(2048);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(BA.NumberToString(_found3s.runMethod(true,"getSize"))));
 BA.debugLineNum = 493;BA.debugLine="Log(found2s.Size)";
Debug.ShouldStop(4096);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(BA.NumberToString(_found2s.runMethod(true,"getSize"))));
 BA.debugLineNum = 494;BA.debugLine="Log(found1s.Size)";
Debug.ShouldStop(8192);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(BA.NumberToString(_found1s.runMethod(true,"getSize"))));
 BA.debugLineNum = 495;BA.debugLine="Log(found0s.Size)";
Debug.ShouldStop(16384);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(BA.NumberToString(_found0s.runMethod(true,"getSize"))));
 BA.debugLineNum = 497;BA.debugLine="TakeEasy3s(found3s, currPlayer)";
Debug.ShouldStop(65536);
_takeeasy3s(_found3s,_currplayer);
 BA.debugLineNum = 498;BA.debugLine="TakeDoubles";
Debug.ShouldStop(131072);
_takedoubles();
 BA.debugLineNum = 499;BA.debugLine="If found0s.Size > 0 Then";
Debug.ShouldStop(262144);
if (RemoteObject.solveBoolean(">",_found0s.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 500;BA.debugLine="TakeSingle(found0s)";
Debug.ShouldStop(524288);
_takesingle(_found0s);
 }else 
{ BA.debugLineNum = 501;BA.debugLine="Else If found1s.Size > 0 Then";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean(">",_found1s.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 502;BA.debugLine="TakeSingle(found1s)";
Debug.ShouldStop(2097152);
_takesingle(_found1s);
 }else {
 BA.debugLineNum = 504;BA.debugLine="TakeSingle(found2s)";
Debug.ShouldStop(8388608);
_takesingle(_found2s);
 }};
 BA.debugLineNum = 508;BA.debugLine="Dim numberClosed As Int = CloseCompletedSquares(currPlayer)";
Debug.ShouldStop(134217728);
_numberclosed = _closecompletedsquares(_currplayer);Debug.locals.put("numberClosed", _numberclosed);Debug.locals.put("numberClosed", _numberclosed);
 BA.debugLineNum = 509;BA.debugLine="currPlayer.Score = currPlayer.Score + numberClosed";
Debug.ShouldStop(268435456);
_currplayer.setFieldClass("pineysoft.squarepaddocks.player", "_score",RemoteObject.solve(new RemoteObject[] {_currplayer.getFieldClass("pineysoft.squarepaddocks.player", true,"_score"),_numberclosed}, "+",1, 1));
 BA.debugLineNum = 510;BA.debugLine="totalScore = totalScore + numberClosed";
Debug.ShouldStop(536870912);
main._totalscore = RemoteObject.solve(new RemoteObject[] {main._totalscore,_numberclosed}, "+",1, 1);
 BA.debugLineNum = 513;BA.debugLine="CheckAndDisplayWinnerScreen";
Debug.ShouldStop(1);
_checkanddisplaywinnerscreen();
 BA.debugLineNum = 514;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _markotherside(RemoteObject _currentsquare,RemoteObject _side,RemoteObject _marktaken) throws Exception{
try {
		Debug.PushSubsStack("MarkOtherSide (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("markotherside")) return main.remoteMe.runUserSub(false, "main","markotherside", _currentsquare, _side, _marktaken);
RemoteObject _foundcol = RemoteObject.createImmutable(0);
RemoteObject _foundrow = RemoteObject.createImmutable(0);
RemoteObject _updateside = RemoteObject.createImmutable(0);
Debug.locals.put("currentSquare", _currentsquare);
Debug.locals.put("side", _side);
Debug.locals.put("markTaken", _marktaken);
 BA.debugLineNum = 432;BA.debugLine="Public Sub MarkOtherSide(currentSquare As GameSquare, side As Int, markTaken As Boolean)";
Debug.ShouldStop(32768);
 BA.debugLineNum = 433;BA.debugLine="Dim foundCol As Int = -1";
Debug.ShouldStop(65536);
_foundcol = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundCol", _foundcol);Debug.locals.put("foundCol", _foundcol);
 BA.debugLineNum = 434;BA.debugLine="Dim foundRow As Int = -1";
Debug.ShouldStop(131072);
_foundrow = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundRow", _foundrow);Debug.locals.put("foundRow", _foundrow);
 BA.debugLineNum = 435;BA.debugLine="Dim updateSide As Int";
Debug.ShouldStop(262144);
_updateside = RemoteObject.createImmutable(0);Debug.locals.put("updateSide", _updateside);
 BA.debugLineNum = 437;BA.debugLine="foundRow = currentSquare.RowPos";
Debug.ShouldStop(1048576);
_foundrow = _currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos");Debug.locals.put("foundRow", _foundrow);
 BA.debugLineNum = 438;BA.debugLine="foundCol = currentSquare.ColPos";
Debug.ShouldStop(2097152);
_foundcol = _currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos");Debug.locals.put("foundCol", _foundcol);
 BA.debugLineNum = 441;BA.debugLine="Select side";
Debug.ShouldStop(16777216);
switch (BA.switchObjectToInt(_side,main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"),main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side"),main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side"),main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side"))) {
case 0:
 BA.debugLineNum = 443;BA.debugLine="If foundRow > 0 Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean(">",_foundrow,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 444;BA.debugLine="foundRow = foundRow - 1";
Debug.ShouldStop(134217728);
_foundrow = RemoteObject.solve(new RemoteObject[] {_foundrow,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("foundRow", _foundrow);
 BA.debugLineNum = 445;BA.debugLine="updateSide = SPConstants.BOTTOM_SIDE";
Debug.ShouldStop(268435456);
_updateside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side");Debug.locals.put("updateSide", _updateside);
 }else {
 BA.debugLineNum = 447;BA.debugLine="foundRow = -1";
Debug.ShouldStop(1073741824);
_foundrow = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundRow", _foundrow);
 };
 break;
case 1:
 BA.debugLineNum = 450;BA.debugLine="If foundCol < gameWidth - 1 Then";
Debug.ShouldStop(2);
if (RemoteObject.solveBoolean("<",_foundcol,BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1)))) { 
 BA.debugLineNum = 451;BA.debugLine="foundCol = foundCol + 1";
Debug.ShouldStop(4);
_foundcol = RemoteObject.solve(new RemoteObject[] {_foundcol,RemoteObject.createImmutable(1)}, "+",1, 1);Debug.locals.put("foundCol", _foundcol);
 BA.debugLineNum = 452;BA.debugLine="updateSide = SPConstants.LEFT_SIDE";
Debug.ShouldStop(8);
_updateside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side");Debug.locals.put("updateSide", _updateside);
 }else {
 BA.debugLineNum = 454;BA.debugLine="foundCol = -1";
Debug.ShouldStop(32);
_foundcol = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundCol", _foundcol);
 };
 break;
case 2:
 BA.debugLineNum = 457;BA.debugLine="If foundRow < gameHeight - 1 Then";
Debug.ShouldStop(256);
if (RemoteObject.solveBoolean("<",_foundrow,BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1)))) { 
 BA.debugLineNum = 458;BA.debugLine="foundRow = foundRow + 1";
Debug.ShouldStop(512);
_foundrow = RemoteObject.solve(new RemoteObject[] {_foundrow,RemoteObject.createImmutable(1)}, "+",1, 1);Debug.locals.put("foundRow", _foundrow);
 BA.debugLineNum = 459;BA.debugLine="updateSide = SPConstants.TOP_SIDE";
Debug.ShouldStop(1024);
_updateside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side");Debug.locals.put("updateSide", _updateside);
 }else {
 BA.debugLineNum = 461;BA.debugLine="foundRow = -1";
Debug.ShouldStop(4096);
_foundrow = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundRow", _foundrow);
 };
 break;
case 3:
 BA.debugLineNum = 464;BA.debugLine="If foundCol > 0 Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean(">",_foundcol,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 465;BA.debugLine="foundCol = foundCol - 1";
Debug.ShouldStop(65536);
_foundcol = RemoteObject.solve(new RemoteObject[] {_foundcol,RemoteObject.createImmutable(1)}, "-",1, 1);Debug.locals.put("foundCol", _foundcol);
 BA.debugLineNum = 466;BA.debugLine="updateSide = SPConstants.RIGHT_SIDE";
Debug.ShouldStop(131072);
_updateside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side");Debug.locals.put("updateSide", _updateside);
 }else {
 BA.debugLineNum = 468;BA.debugLine="foundCol = -1";
Debug.ShouldStop(524288);
_foundcol = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("foundCol", _foundcol);
 };
 break;
}
;
 BA.debugLineNum = 472;BA.debugLine="If foundRow <> -1 AND foundCol <> -1 Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean("!",_foundrow,BA.numberCast(double.class, -(double) (0 + 1))) && RemoteObject.solveBoolean("!",_foundcol,BA.numberCast(double.class, -(double) (0 + 1)))) { 
 BA.debugLineNum = 473;BA.debugLine="gameSquares(foundRow,foundCol).MarkSideTaken(updateSide, markTaken)";
Debug.ShouldStop(16777216);
main.mostCurrent._gamesquares.getArrayElement(false,_foundrow,_foundcol).runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_marksidetaken",(Object)(_updateside),(Object)(_marktaken));
 };
 BA.debugLineNum = 475;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _markotherside2(RemoteObject _currentsquare,RemoteObject _side) throws Exception{
try {
		Debug.PushSubsStack("MarkOtherSide2 (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("markotherside2")) return main.remoteMe.runUserSub(false, "main","markotherside2", _currentsquare, _side);
Debug.locals.put("currentSquare", _currentsquare);
Debug.locals.put("side", _side);
 BA.debugLineNum = 429;BA.debugLine="Public Sub MarkOtherSide2(currentSquare As GameSquare, side As Int)";
Debug.ShouldStop(4096);
 BA.debugLineNum = 430;BA.debugLine="MarkOtherSide(currentSquare, side, True)";
Debug.ShouldStop(8192);
_markotherside(_currentsquare,_side,main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 431;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _panel1_touch(RemoteObject _action,RemoteObject _x,RemoteObject _y) throws Exception{
try {
		Debug.PushSubsStack("Panel1_Touch (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("panel1_touch")) return main.remoteMe.runUserSub(false, "main","panel1_touch", _action, _x, _y);
Debug.locals.put("Action", _action);
Debug.locals.put("X", _x);
Debug.locals.put("Y", _y);
 BA.debugLineNum = 309;BA.debugLine="Sub Panel1_Touch (Action As Int, X As Float, Y As Float)";
Debug.ShouldStop(1048576);
 BA.debugLineNum = 310;BA.debugLine="Select Action";
Debug.ShouldStop(2097152);
switch (BA.switchObjectToInt(_action,main.mostCurrent._activity.getField(true,"ACTION_UP"))) {
case 0:
 BA.debugLineNum = 312;BA.debugLine="Log (\"X,Y = \" & X & \",\" & Y)";
Debug.ShouldStop(8388608);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("X,Y = "),_x,RemoteObject.createImmutable(","),_y)));
 BA.debugLineNum = 313;BA.debugLine="CalculateMove(X,Y)";
Debug.ShouldStop(16777216);
_calculatemove(BA.numberCast(int.class, _x),BA.numberCast(int.class, _y));
 BA.debugLineNum = 314;BA.debugLine="panel1.Invalidate";
Debug.ShouldStop(33554432);
main.mostCurrent._panel1.runVoidMethod ("Invalidate");
 break;
}
;
 BA.debugLineNum = 316;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 18;BA.debugLine="Private currentPlayer As Short";
main._currentplayer = RemoteObject.createImmutable((short)0);
 //BA.debugLineNum = 19;BA.debugLine="Private numberOfPlayers As Int";
main._numberofplayers = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 20;BA.debugLine="Private numberOfDroids As Int";
main._numberofdroids = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 21;BA.debugLine="Private playerColours As List ' List of Ints";
main._playercolours = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
 //BA.debugLineNum = 22;BA.debugLine="Private inGame As Boolean";
main._ingame = RemoteObject.createImmutable(false);
 //BA.debugLineNum = 23;BA.debugLine="Private giggleSound As Int";
main._gigglesound = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 24;BA.debugLine="Dim sounds As SoundPool";
main._sounds = RemoteObject.createNew ("anywheresoftware.b4a.audio.SoundPoolWrapper");
 //BA.debugLineNum = 25;BA.debugLine="Private totalScore As Int";
main._totalscore = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 26;BA.debugLine="Dim SPConstants As Constants";
main._spconstants = RemoteObject.createNew ("pineysoft.squarepaddocks.constants");
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _removeturn(RemoteObject _lastturn,RemoteObject _currplayer) throws Exception{
try {
		Debug.PushSubsStack("RemoveTurn (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("removeturn")) return main.remoteMe.runUserSub(false, "main","removeturn", _lastturn, _currplayer);
Debug.locals.put("lastTurn", _lastturn);
Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 861;BA.debugLine="Public Sub RemoveTurn(lastTurn As Turn, currPlayer As Player)";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 864;BA.debugLine="If lastTurn.Square.sidesTaken = 4 Then";
Debug.ShouldStop(-2147483648);
if (RemoteObject.solveBoolean("=",_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", false,"_square").getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 4))) { 
 BA.debugLineNum = 865;BA.debugLine="currPlayer.Score = currPlayer.Score - 1";
Debug.ShouldStop(1);
_currplayer.setFieldClass("pineysoft.squarepaddocks.player", "_score",RemoteObject.solve(new RemoteObject[] {_currplayer.getFieldClass("pineysoft.squarepaddocks.player", true,"_score"),RemoteObject.createImmutable(1)}, "-",1, 1));
 BA.debugLineNum = 866;BA.debugLine="EmptyTheSquare(lastTurn.Square)";
Debug.ShouldStop(2);
_emptythesquare(_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", false,"_square"));
 };
 BA.debugLineNum = 870;BA.debugLine="lastTurn.Square.RemoveSide(canv, lastTurn.Edge)";
Debug.ShouldStop(32);
_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", false,"_square").runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_removeside",(Object)(main.mostCurrent._canv),(Object)(_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", true,"_edge")));
 BA.debugLineNum = 871;BA.debugLine="MarkOtherSide(lastTurn.Square,lastTurn.Edge,False)";
Debug.ShouldStop(64);
_markotherside(_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", false,"_square"),_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", true,"_edge"),main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 874;BA.debugLine="gameTurns.RemoveAt(gameTurns.Size - 1)";
Debug.ShouldStop(512);
main.mostCurrent._gameturns.runVoidMethod ("RemoveAt",(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent._gameturns.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1)));
 BA.debugLineNum = 877;BA.debugLine="If gameTurns.Size > 0 Then";
Debug.ShouldStop(4096);
if (RemoteObject.solveBoolean(">",main.mostCurrent._gameturns.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 878;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
Debug.ShouldStop(8192);
_lastturn = (main.mostCurrent._gameturns.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent._gameturns.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1))));Debug.locals.put("lastTurn", _lastturn);
 BA.debugLineNum = 879;BA.debugLine="lastTurn.Square.RedrawSide(canv, lastTurn.Edge)";
Debug.ShouldStop(16384);
_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", false,"_square").runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_redrawside",(Object)(main.mostCurrent._canv),(Object)(_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", true,"_edge")));
 };
 BA.debugLineNum = 881;BA.debugLine="End Sub";
Debug.ShouldStop(65536);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _reverseanimate() throws Exception{
try {
		Debug.PushSubsStack("ReverseAnimate (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("reverseanimate")) return main.remoteMe.runUserSub(false, "main","reverseanimate");
 BA.debugLineNum = 142;BA.debugLine="Sub ReverseAnimate";
Debug.ShouldStop(8192);
 BA.debugLineNum = 150;BA.debugLine="anim1.InitializeTranslate(\"\", 350dip,100dip,-120dip,100dip)";
Debug.ShouldStop(2097152);
main.mostCurrent._anim1.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 350))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))),(Object)(BA.numberCast(float.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120))).<Integer>get().intValue()))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))));
 BA.debugLineNum = 151;BA.debugLine="anim1.Duration = 1000";
Debug.ShouldStop(4194304);
main.mostCurrent._anim1.runMethod(true,"setDuration",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 152;BA.debugLine="anim1.PersistAfter = True";
Debug.ShouldStop(8388608);
main.mostCurrent._anim1.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 153;BA.debugLine="anim1.Start(icon1)";
Debug.ShouldStop(16777216);
main.mostCurrent._anim1.runVoidMethod ("Start",(Object)((main.mostCurrent._icon1.getObject())));
 BA.debugLineNum = 154;BA.debugLine="anim2.InitializeTranslate(\"\", 150dip,200dip,100%x + 120dip,200dip)";
Debug.ShouldStop(33554432);
main.mostCurrent._anim2.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 150))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120)))}, "+",1, 1))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))));
 BA.debugLineNum = 155;BA.debugLine="anim2.Duration = 1000";
Debug.ShouldStop(67108864);
main.mostCurrent._anim2.runMethod(true,"setDuration",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 156;BA.debugLine="anim2.StartOffset = 150";
Debug.ShouldStop(134217728);
main.mostCurrent._anim2.runMethod(true,"setStartOffset",BA.numberCast(long.class, 150));
 BA.debugLineNum = 157;BA.debugLine="anim2.PersistAfter = True";
Debug.ShouldStop(268435456);
main.mostCurrent._anim2.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 158;BA.debugLine="anim2.Start(icon2)";
Debug.ShouldStop(536870912);
main.mostCurrent._anim2.runVoidMethod ("Start",(Object)((main.mostCurrent._icon2.getObject())));
 BA.debugLineNum = 159;BA.debugLine="anim3.InitializeTranslate(\"\", 250dip,100dip,-120dip,100dip)";
Debug.ShouldStop(1073741824);
main.mostCurrent._anim3.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))),(Object)(BA.numberCast(float.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120))).<Integer>get().intValue()))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))));
 BA.debugLineNum = 160;BA.debugLine="anim3.Duration = 1000";
Debug.ShouldStop(-2147483648);
main.mostCurrent._anim3.runMethod(true,"setDuration",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 161;BA.debugLine="anim3.StartOffset = 300";
Debug.ShouldStop(1);
main.mostCurrent._anim3.runMethod(true,"setStartOffset",BA.numberCast(long.class, 300));
 BA.debugLineNum = 162;BA.debugLine="anim3.PersistAfter = True";
Debug.ShouldStop(2);
main.mostCurrent._anim3.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 163;BA.debugLine="anim3.Start(icon3)";
Debug.ShouldStop(4);
main.mostCurrent._anim3.runVoidMethod ("Start",(Object)((main.mostCurrent._icon3.getObject())));
 BA.debugLineNum = 164;BA.debugLine="anim4.InitializeTranslate(\"\", 200dip,250dip,200dip,100%x + 120dip)";
Debug.ShouldStop(8);
main.mostCurrent._anim4.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120)))}, "+",1, 1))));
 BA.debugLineNum = 165;BA.debugLine="anim4.Duration = 1000";
Debug.ShouldStop(16);
main.mostCurrent._anim4.runMethod(true,"setDuration",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 166;BA.debugLine="anim4.StartOffset = 450";
Debug.ShouldStop(32);
main.mostCurrent._anim4.runMethod(true,"setStartOffset",BA.numberCast(long.class, 450));
 BA.debugLineNum = 167;BA.debugLine="anim4.PersistAfter	 = True";
Debug.ShouldStop(64);
main.mostCurrent._anim4.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 168;BA.debugLine="anim4.Start(icon4)";
Debug.ShouldStop(128);
main.mostCurrent._anim4.runVoidMethod ("Start",(Object)((main.mostCurrent._icon4.getObject())));
 BA.debugLineNum = 169;BA.debugLine="anim5.InitializeTranslate(\"\", 150dip,100dip,-120dip,100dip)";
Debug.ShouldStop(256);
main.mostCurrent._anim5.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 150))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))),(Object)(BA.numberCast(float.class, -(double) (0 + main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120))).<Integer>get().intValue()))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100))))));
 BA.debugLineNum = 170;BA.debugLine="anim5.Duration = 1000";
Debug.ShouldStop(512);
main.mostCurrent._anim5.runMethod(true,"setDuration",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 171;BA.debugLine="anim5.StartOffset = 600";
Debug.ShouldStop(1024);
main.mostCurrent._anim5.runMethod(true,"setStartOffset",BA.numberCast(long.class, 600));
 BA.debugLineNum = 172;BA.debugLine="anim5.PersistAfter = True";
Debug.ShouldStop(2048);
main.mostCurrent._anim5.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 173;BA.debugLine="anim5.Start(icon5)";
Debug.ShouldStop(4096);
main.mostCurrent._anim5.runVoidMethod ("Start",(Object)((main.mostCurrent._icon5.getObject())));
 BA.debugLineNum = 174;BA.debugLine="anim6.InitializeTranslate(\"anim6\", 200dip,350dip,200dip,100%x + 120dip)";
Debug.ShouldStop(8192);
main.mostCurrent._anim6.runVoidMethod ("InitializeTranslate",main.mostCurrent.activityBA,(Object)(BA.ObjectToString("anim6")),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 350))))),(Object)(BA.numberCast(float.class, main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200))))),(Object)(BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 120)))}, "+",1, 1))));
 BA.debugLineNum = 175;BA.debugLine="anim6.Duration = 1000";
Debug.ShouldStop(16384);
main.mostCurrent._anim6.runMethod(true,"setDuration",BA.numberCast(long.class, 1000));
 BA.debugLineNum = 176;BA.debugLine="anim6.StartOffset = 750";
Debug.ShouldStop(32768);
main.mostCurrent._anim6.runMethod(true,"setStartOffset",BA.numberCast(long.class, 750));
 BA.debugLineNum = 177;BA.debugLine="anim6.PersistAfter = True";
Debug.ShouldStop(65536);
main.mostCurrent._anim6.runMethod(true,"setPersistAfter",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 178;BA.debugLine="anim6.Start(icon6)";
Debug.ShouldStop(131072);
main.mostCurrent._anim6.runVoidMethod ("Start",(Object)((main.mostCurrent._icon6.getObject())));
 BA.debugLineNum = 179;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _sbcolumns_valuechanged(RemoteObject _value,RemoteObject _userchanged) throws Exception{
try {
		Debug.PushSubsStack("sbColumns_ValueChanged (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("sbcolumns_valuechanged")) return main.remoteMe.runUserSub(false, "main","sbcolumns_valuechanged", _value, _userchanged);
Debug.locals.put("Value", _value);
Debug.locals.put("UserChanged", _userchanged);
 BA.debugLineNum = 836;BA.debugLine="Sub sbColumns_ValueChanged (Value As Int, UserChanged As Boolean)";
Debug.ShouldStop(8);
 BA.debugLineNum = 837;BA.debugLine="If Value < 4 AND UserChanged = True Then";
Debug.ShouldStop(16);
if (RemoteObject.solveBoolean("<",_value,BA.numberCast(double.class, 4)) && RemoteObject.solveBoolean("=",_userchanged,main.mostCurrent.__c.getField(true,"True"))) { 
 BA.debugLineNum = 838;BA.debugLine="sbColumns.Value = 4";
Debug.ShouldStop(32);
main.mostCurrent._sbcolumns.runMethod(true,"setValue",BA.numberCast(int.class, 4));
 };
 BA.debugLineNum = 840;BA.debugLine="gameWidth = Value";
Debug.ShouldStop(128);
main._gamewidth = _value;
 BA.debugLineNum = 841;BA.debugLine="lblColumns.Text = \"Columns : \" & Value";
Debug.ShouldStop(256);
main.mostCurrent._lblcolumns.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Columns : "),_value)));
 BA.debugLineNum = 842;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _sbrows_valuechanged(RemoteObject _value,RemoteObject _userchanged) throws Exception{
try {
		Debug.PushSubsStack("sbRows_ValueChanged (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("sbrows_valuechanged")) return main.remoteMe.runUserSub(false, "main","sbrows_valuechanged", _value, _userchanged);
Debug.locals.put("Value", _value);
Debug.locals.put("UserChanged", _userchanged);
 BA.debugLineNum = 829;BA.debugLine="Sub sbRows_ValueChanged (Value As Int, UserChanged As Boolean)";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 830;BA.debugLine="If Value < 4 AND UserChanged = True Then";
Debug.ShouldStop(536870912);
if (RemoteObject.solveBoolean("<",_value,BA.numberCast(double.class, 4)) && RemoteObject.solveBoolean("=",_userchanged,main.mostCurrent.__c.getField(true,"True"))) { 
 BA.debugLineNum = 831;BA.debugLine="sbRows.Value = 4";
Debug.ShouldStop(1073741824);
main.mostCurrent._sbrows.runMethod(true,"setValue",BA.numberCast(int.class, 4));
 };
 BA.debugLineNum = 833;BA.debugLine="gameHeight = Value";
Debug.ShouldStop(1);
main._gameheight = _value;
 BA.debugLineNum = 834;BA.debugLine="lblRows.Text = \"Rows : \" & Value";
Debug.ShouldStop(2);
main.mostCurrent._lblrows.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Rows : "),_value)));
 BA.debugLineNum = 835;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _showcharacters() throws Exception{
try {
		Debug.PushSubsStack("ShowCharacters (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("showcharacters")) return main.remoteMe.runUserSub(false, "main","showcharacters");
 BA.debugLineNum = 189;BA.debugLine="Sub ShowCharacters";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 190;BA.debugLine="icon1.Left = Activity.Left + 250dip";
Debug.ShouldStop(536870912);
main.mostCurrent._icon1.runMethod(true,"setLeft",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getLeft"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250)))}, "+",1, 1));
 BA.debugLineNum = 191;BA.debugLine="icon1.Top = Activity.Top + 100dip";
Debug.ShouldStop(1073741824);
main.mostCurrent._icon1.runMethod(true,"setTop",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getTop"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100)))}, "+",1, 1));
 BA.debugLineNum = 192;BA.debugLine="icon2.Left = Activity.Left + 50dip";
Debug.ShouldStop(-2147483648);
main.mostCurrent._icon2.runMethod(true,"setLeft",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getLeft"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 50)))}, "+",1, 1));
 BA.debugLineNum = 193;BA.debugLine="icon2.Top = Activity.Top + 200dip";
Debug.ShouldStop(1);
main.mostCurrent._icon2.runMethod(true,"setTop",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getTop"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200)))}, "+",1, 1));
 BA.debugLineNum = 194;BA.debugLine="icon3.Left = Activity.Left + 150dip";
Debug.ShouldStop(2);
main.mostCurrent._icon3.runMethod(true,"setLeft",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getLeft"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 150)))}, "+",1, 1));
 BA.debugLineNum = 195;BA.debugLine="icon3.Top = Activity.Top +  100dip";
Debug.ShouldStop(4);
main.mostCurrent._icon3.runMethod(true,"setTop",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getTop"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100)))}, "+",1, 1));
 BA.debugLineNum = 196;BA.debugLine="icon4.Left = Activity.Left + 150dip";
Debug.ShouldStop(8);
main.mostCurrent._icon4.runMethod(true,"setLeft",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getLeft"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 150)))}, "+",1, 1));
 BA.debugLineNum = 197;BA.debugLine="icon4.Top = Activity.Top +  200dip";
Debug.ShouldStop(16);
main.mostCurrent._icon4.runMethod(true,"setTop",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getTop"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200)))}, "+",1, 1));
 BA.debugLineNum = 198;BA.debugLine="icon5.Left = Activity.Left + 50dip";
Debug.ShouldStop(32);
main.mostCurrent._icon5.runMethod(true,"setLeft",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getLeft"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 50)))}, "+",1, 1));
 BA.debugLineNum = 199;BA.debugLine="icon5.Top = Activity.Top +  100dip";
Debug.ShouldStop(64);
main.mostCurrent._icon5.runMethod(true,"setTop",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getTop"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 100)))}, "+",1, 1));
 BA.debugLineNum = 200;BA.debugLine="icon6.Left = Activity.Left + 250dip";
Debug.ShouldStop(128);
main.mostCurrent._icon6.runMethod(true,"setLeft",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getLeft"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 250)))}, "+",1, 1));
 BA.debugLineNum = 201;BA.debugLine="icon6.Top = Activity.Top +  200dip";
Debug.ShouldStop(256);
main.mostCurrent._icon6.runMethod(true,"setTop",RemoteObject.solve(new RemoteObject[] {main.mostCurrent._activity.runMethod(true,"getTop"),main.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 200)))}, "+",1, 1));
 BA.debugLineNum = 202;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _showsplashscreen() throws Exception{
try {
		Debug.PushSubsStack("ShowSplashScreen (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("showsplashscreen")) return main.remoteMe.runUserSub(false, "main","showsplashscreen");
 BA.debugLineNum = 102;BA.debugLine="Sub ShowSplashScreen";
Debug.ShouldStop(32);
 BA.debugLineNum = 103;BA.debugLine="UpdateLabels";
Debug.ShouldStop(64);
_updatelabels();
 BA.debugLineNum = 104;BA.debugLine="AnimateCharacters";
Debug.ShouldStop(128);
_animatecharacters();
 BA.debugLineNum = 105;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _spnplayers_itemclick(RemoteObject _position,RemoteObject _value) throws Exception{
try {
		Debug.PushSubsStack("spnPlayers_ItemClick (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("spnplayers_itemclick")) return main.remoteMe.runUserSub(false, "main","spnplayers_itemclick", _position, _value);
RemoteObject _iloop = RemoteObject.createImmutable(0);
Debug.locals.put("Position", _position);
Debug.locals.put("Value", _value);
 BA.debugLineNum = 812;BA.debugLine="Sub spnPlayers_ItemClick (Position As Int, Value As Object)";
Debug.ShouldStop(2048);
 BA.debugLineNum = 813;BA.debugLine="numberOfPlayers = Value";
Debug.ShouldStop(4096);
main._numberofplayers = BA.numberCast(int.class, _value);
 BA.debugLineNum = 814;BA.debugLine="spnDroids.Clear";
Debug.ShouldStop(8192);
main.mostCurrent._spndroids.runVoidMethod ("Clear");
 BA.debugLineNum = 815;BA.debugLine="Dim iLoop As Int";
Debug.ShouldStop(16384);
_iloop = RemoteObject.createImmutable(0);Debug.locals.put("iLoop", _iloop);
 BA.debugLineNum = 816;BA.debugLine="For iLoop = 0 To numberOfPlayers - 1";
Debug.ShouldStop(32768);
{
final int step662 = 1;
final int limit662 = RemoteObject.solve(new RemoteObject[] {main._numberofplayers,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
for (_iloop = BA.numberCast(int.class, 0); (step662 > 0 && _iloop.<Integer>get().intValue() <= limit662) || (step662 < 0 && _iloop.<Integer>get().intValue() >= limit662); _iloop = RemoteObject.createImmutable((int)(0 + _iloop.<Integer>get().intValue() + step662))) {
Debug.locals.put("iLoop", _iloop);
 BA.debugLineNum = 817;BA.debugLine="spnDroids.Add(iLoop)";
Debug.ShouldStop(65536);
main.mostCurrent._spndroids.runVoidMethod ("Add",(Object)(BA.NumberToString(_iloop)));
 }
}Debug.locals.put("iLoop", _iloop);
;
 BA.debugLineNum = 819;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _takedoubles() throws Exception{
try {
		Debug.PushSubsStack("TakeDoubles (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("takedoubles")) return main.remoteMe.runUserSub(false, "main","takedoubles");
RemoteObject _found3s = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _closeside = RemoteObject.createImmutable(0);
RemoteObject _currentsquare = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
 BA.debugLineNum = 555;BA.debugLine="Public Sub TakeDoubles";
Debug.ShouldStop(1024);
 BA.debugLineNum = 556;BA.debugLine="Dim found3s As List";
Debug.ShouldStop(2048);
_found3s = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");Debug.locals.put("found3s", _found3s);
 BA.debugLineNum = 557;BA.debugLine="Dim closeSide As Int = -1";
Debug.ShouldStop(4096);
_closeside = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("closeSide", _closeside);Debug.locals.put("closeSide", _closeside);
 BA.debugLineNum = 559;BA.debugLine="found3s = FindAllForSides(3)";
Debug.ShouldStop(16384);
_found3s = _findallforsides(BA.numberCast(int.class, 3));Debug.locals.put("found3s", _found3s);
 BA.debugLineNum = 561;BA.debugLine="For Each currentSquare As GameSquare In found3s";
Debug.ShouldStop(65536);
final RemoteObject group458 = _found3s;
final int groupLen458 = group458.runMethod(true,"getSize").<Integer>get();
for (int index458 = 0;index458 < groupLen458 ;index458++){
_currentsquare = (group458.runMethod(false,"Get",index458));Debug.locals.put("currentsquare", _currentsquare);
Debug.locals.put("currentsquare", _currentsquare);
 BA.debugLineNum = 562;BA.debugLine="If currentSquare.IsSideTaken(SPConstants.LEFT_SIDE) = False Then";
Debug.ShouldStop(131072);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 563;BA.debugLine="If currentSquare.ColPos = 0 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos - 1).sidesTaken = 2 Then";
Debug.ShouldStop(262144);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),BA.numberCast(double.class, 0)) || RemoteObject.solveBoolean("=",main.mostCurrent._gamesquares.getArrayElement(false,_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),RemoteObject.createImmutable(1)}, "-",1, 1)).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 564;BA.debugLine="closeSide = SPConstants.LEFT_SIDE";
Debug.ShouldStop(524288);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side");Debug.locals.put("closeSide", _closeside);
 };
 }else 
{ BA.debugLineNum = 566;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.RIGHT_SIDE) = False Then";
Debug.ShouldStop(2097152);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 567;BA.debugLine="If currentSquare.ColPos = gameWidth - 1 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos + 1).sidesTaken = 2 Then";
Debug.ShouldStop(4194304);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1))) || RemoteObject.solveBoolean("=",main.mostCurrent._gamesquares.getArrayElement(false,_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),RemoteObject.createImmutable(1)}, "+",1, 1)).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 568;BA.debugLine="closeSide = SPConstants.RIGHT_SIDE";
Debug.ShouldStop(8388608);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side");Debug.locals.put("closeSide", _closeside);
 };
 }else 
{ BA.debugLineNum = 570;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.TOP_SIDE) = False Then";
Debug.ShouldStop(33554432);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 571;BA.debugLine="If currentSquare.RowPos = 0 OR gameSquares(currentSquare.RowPos - 1, currentSquare.ColPos).sidesTaken = 2 Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),BA.numberCast(double.class, 0)) || RemoteObject.solveBoolean("=",main.mostCurrent._gamesquares.getArrayElement(false,RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.createImmutable(1)}, "-",1, 1),_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos")).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 572;BA.debugLine="closeSide = SPConstants.TOP_SIDE";
Debug.ShouldStop(134217728);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side");Debug.locals.put("closeSide", _closeside);
 };
 }else 
{ BA.debugLineNum = 574;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.BOTTOM_SIDE) = False Then";
Debug.ShouldStop(536870912);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 575;BA.debugLine="If currentSquare.RowPos = gameHeight - 1 OR gameSquares(currentSquare.RowPos + 1, currentSquare.ColPos).sidesTaken = 2 Then";
Debug.ShouldStop(1073741824);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1))) || RemoteObject.solveBoolean("=",main.mostCurrent._gamesquares.getArrayElement(false,RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.createImmutable(1)}, "+",1, 1),_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos")).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 576;BA.debugLine="closeSide = SPConstants.BOTTOM_SIDE";
Debug.ShouldStop(-2147483648);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side");Debug.locals.put("closeSide", _closeside);
 };
 }}}};
 BA.debugLineNum = 580;BA.debugLine="If closeSide = -1 Then Return";
Debug.ShouldStop(8);
if (RemoteObject.solveBoolean("=",_closeside,BA.numberCast(double.class, -(double) (0 + 1)))) { 
if (true) return RemoteObject.createImmutable("");};
 BA.debugLineNum = 583;BA.debugLine="UpdateTurn(canv, currentSquare, closeSide)";
Debug.ShouldStop(64);
_updateturn(main.mostCurrent._canv,_currentsquare,_closeside);
 BA.debugLineNum = 586;BA.debugLine="currentSquare.TakeSide(canv,closeSide)";
Debug.ShouldStop(512);
_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_takeside",(Object)(main.mostCurrent._canv),(Object)(_closeside));
 BA.debugLineNum = 589;BA.debugLine="MarkOtherSide2(currentSquare, closeSide)";
Debug.ShouldStop(4096);
_markotherside2(_currentsquare,_closeside);
 BA.debugLineNum = 592;BA.debugLine="TakeSecondSquare(currentSquare, closeSide)";
Debug.ShouldStop(32768);
_takesecondsquare(_currentsquare,_closeside);
 }
Debug.locals.put("currentsquare", _currentsquare);
;
 BA.debugLineNum = 596;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _takeeasy3s(RemoteObject _found3s,RemoteObject _currplayer) throws Exception{
try {
		Debug.PushSubsStack("TakeEasy3s (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("takeeasy3s")) return main.remoteMe.runUserSub(false, "main","takeeasy3s", _found3s, _currplayer);
RemoteObject _closeside = RemoteObject.createImmutable(0);
RemoteObject _currentsquare = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
Debug.locals.put("found3s", _found3s);
Debug.locals.put("currPlayer", _currplayer);
 BA.debugLineNum = 516;BA.debugLine="Public Sub TakeEasy3s(found3s As List, currPlayer As Player)";
Debug.ShouldStop(8);
 BA.debugLineNum = 517;BA.debugLine="Dim closeSide As Int = -1";
Debug.ShouldStop(16);
_closeside = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("closeSide", _closeside);Debug.locals.put("closeSide", _closeside);
 BA.debugLineNum = 519;BA.debugLine="Log(\"Checking Found 3's\")";
Debug.ShouldStop(64);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(BA.ObjectToString("Checking Found 3's")));
 BA.debugLineNum = 520;BA.debugLine="For Each currentSquare As GameSquare In found3s";
Debug.ShouldStop(128);
final RemoteObject group428 = _found3s;
final int groupLen428 = group428.runMethod(true,"getSize").<Integer>get();
for (int index428 = 0;index428 < groupLen428 ;index428++){
_currentsquare = (group428.runMethod(false,"Get",index428));Debug.locals.put("currentsquare", _currentsquare);
Debug.locals.put("currentsquare", _currentsquare);
 BA.debugLineNum = 521;BA.debugLine="closeSide = -1";
Debug.ShouldStop(256);
_closeside = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("closeSide", _closeside);
 BA.debugLineNum = 522;BA.debugLine="Log(\"Row: \" & currentSquare.RowPos & \" Column: \" & currentSquare.ColPos)";
Debug.ShouldStop(512);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Row: "),_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.createImmutable(" Column: "),_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"))));
 BA.debugLineNum = 523;BA.debugLine="If currentSquare.IsSideTaken(SPConstants.LEFT_SIDE) = False Then";
Debug.ShouldStop(1024);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 524;BA.debugLine="If currentSquare.ColPos = 0 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos - 1).sidesTaken <> 2 Then";
Debug.ShouldStop(2048);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),BA.numberCast(double.class, 0)) || RemoteObject.solveBoolean("!",main.mostCurrent._gamesquares.getArrayElement(false,_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),RemoteObject.createImmutable(1)}, "-",1, 1)).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 525;BA.debugLine="closeSide = SPConstants.LEFT_SIDE";
Debug.ShouldStop(4096);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side");Debug.locals.put("closeSide", _closeside);
 };
 }else 
{ BA.debugLineNum = 527;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.RIGHT_SIDE) = False Then";
Debug.ShouldStop(16384);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 528;BA.debugLine="If currentSquare.ColPos = gameWidth - 1 OR gameSquares(currentSquare.RowPos, currentSquare.ColPos + 1).sidesTaken <> 2 Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gamewidth,RemoteObject.createImmutable(1)}, "-",1, 1))) || RemoteObject.solveBoolean("!",main.mostCurrent._gamesquares.getArrayElement(false,_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),RemoteObject.createImmutable(1)}, "+",1, 1)).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 529;BA.debugLine="closeSide = SPConstants.RIGHT_SIDE";
Debug.ShouldStop(65536);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side");Debug.locals.put("closeSide", _closeside);
 };
 }else 
{ BA.debugLineNum = 531;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.TOP_SIDE) = False Then";
Debug.ShouldStop(262144);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 532;BA.debugLine="If currentSquare.RowPos = 0 OR gameSquares(currentSquare.RowPos - 1, currentSquare.ColPos).sidesTaken <> 2 Then";
Debug.ShouldStop(524288);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),BA.numberCast(double.class, 0)) || RemoteObject.solveBoolean("!",main.mostCurrent._gamesquares.getArrayElement(false,RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.createImmutable(1)}, "-",1, 1),_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos")).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 533;BA.debugLine="closeSide = SPConstants.TOP_SIDE";
Debug.ShouldStop(1048576);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side");Debug.locals.put("closeSide", _closeside);
 };
 }else 
{ BA.debugLineNum = 535;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.BOTTOM_SIDE) = False Then";
Debug.ShouldStop(4194304);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 536;BA.debugLine="If currentSquare.RowPos = gameHeight - 1 OR gameSquares(currentSquare.RowPos + 1, currentSquare.ColPos).sidesTaken <> 2 Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean("=",_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._gameheight,RemoteObject.createImmutable(1)}, "-",1, 1))) || RemoteObject.solveBoolean("!",main.mostCurrent._gamesquares.getArrayElement(false,RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),RemoteObject.createImmutable(1)}, "+",1, 1),_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos")).getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_sidestaken"),BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 537;BA.debugLine="closeSide = SPConstants.BOTTOM_SIDE";
Debug.ShouldStop(16777216);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side");Debug.locals.put("closeSide", _closeside);
 };
 }}}};
 BA.debugLineNum = 541;BA.debugLine="If closeSide = -1 Then Return";
Debug.ShouldStop(268435456);
if (RemoteObject.solveBoolean("=",_closeside,BA.numberCast(double.class, -(double) (0 + 1)))) { 
if (true) return RemoteObject.createImmutable("");};
 BA.debugLineNum = 544;BA.debugLine="UpdateTurn(canv, currentSquare, closeSide)";
Debug.ShouldStop(-2147483648);
_updateturn(main.mostCurrent._canv,_currentsquare,_closeside);
 BA.debugLineNum = 547;BA.debugLine="currentSquare.TakeSide(canv,closeSide)";
Debug.ShouldStop(4);
_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_takeside",(Object)(main.mostCurrent._canv),(Object)(_closeside));
 BA.debugLineNum = 550;BA.debugLine="MarkOtherSide2(currentSquare, closeSide)";
Debug.ShouldStop(32);
_markotherside2(_currentsquare,_closeside);
 }
Debug.locals.put("currentsquare", _currentsquare);
;
 BA.debugLineNum = 553;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _takesecondsquare(RemoteObject _currentsquare,RemoteObject _side) throws Exception{
try {
		Debug.PushSubsStack("TakeSecondSquare (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("takesecondsquare")) return main.remoteMe.runUserSub(false, "main","takesecondsquare", _currentsquare, _side);
RemoteObject _otherrow = RemoteObject.createImmutable(0);
RemoteObject _othercol = RemoteObject.createImmutable(0);
RemoteObject _closeside = RemoteObject.createImmutable(0);
RemoteObject _secondsquare = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
Debug.locals.put("currentSquare", _currentsquare);
Debug.locals.put("side", _side);
 BA.debugLineNum = 598;BA.debugLine="Sub TakeSecondSquare(currentSquare As GameSquare, side As Int)";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 599;BA.debugLine="Dim otherRow As Int";
Debug.ShouldStop(4194304);
_otherrow = RemoteObject.createImmutable(0);Debug.locals.put("otherRow", _otherrow);
 BA.debugLineNum = 600;BA.debugLine="Dim otherCol As Int";
Debug.ShouldStop(8388608);
_othercol = RemoteObject.createImmutable(0);Debug.locals.put("otherCol", _othercol);
 BA.debugLineNum = 601;BA.debugLine="Dim closeSide As Int";
Debug.ShouldStop(16777216);
_closeside = RemoteObject.createImmutable(0);Debug.locals.put("closeSide", _closeside);
 BA.debugLineNum = 603;BA.debugLine="Select side";
Debug.ShouldStop(67108864);
switch (BA.switchObjectToInt(_side,main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side"),main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side"),main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"),main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"))) {
case 0:
 BA.debugLineNum = 605;BA.debugLine="otherRow = 0";
Debug.ShouldStop(268435456);
_otherrow = BA.numberCast(int.class, 0);Debug.locals.put("otherRow", _otherrow);
 BA.debugLineNum = 606;BA.debugLine="otherCol = -1";
Debug.ShouldStop(536870912);
_othercol = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("otherCol", _othercol);
 break;
case 1:
 BA.debugLineNum = 608;BA.debugLine="otherRow = 0";
Debug.ShouldStop(-2147483648);
_otherrow = BA.numberCast(int.class, 0);Debug.locals.put("otherRow", _otherrow);
 BA.debugLineNum = 609;BA.debugLine="otherCol = 1";
Debug.ShouldStop(1);
_othercol = BA.numberCast(int.class, 1);Debug.locals.put("otherCol", _othercol);
 break;
case 2:
 BA.debugLineNum = 611;BA.debugLine="otherRow = -1";
Debug.ShouldStop(4);
_otherrow = BA.numberCast(int.class, -(double) (0 + 1));Debug.locals.put("otherRow", _otherrow);
 BA.debugLineNum = 612;BA.debugLine="otherCol = 0";
Debug.ShouldStop(8);
_othercol = BA.numberCast(int.class, 0);Debug.locals.put("otherCol", _othercol);
 break;
case 3:
 BA.debugLineNum = 614;BA.debugLine="otherRow = 1";
Debug.ShouldStop(32);
_otherrow = BA.numberCast(int.class, 1);Debug.locals.put("otherRow", _otherrow);
 BA.debugLineNum = 615;BA.debugLine="otherCol = 0";
Debug.ShouldStop(64);
_othercol = BA.numberCast(int.class, 0);Debug.locals.put("otherCol", _othercol);
 break;
}
;
 BA.debugLineNum = 618;BA.debugLine="Dim secondSquare As GameSquare = gameSquares(currentSquare.RowPos + otherRow, currentSquare.ColPos + otherCol)";
Debug.ShouldStop(512);
_secondsquare = main.mostCurrent._gamesquares.getArrayElement(false,RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_rowpos"),_otherrow}, "+",1, 1),RemoteObject.solve(new RemoteObject[] {_currentsquare.getFieldClass("pineysoft.squarepaddocks.gamesquare", true,"_colpos"),_othercol}, "+",1, 1));Debug.locals.put("secondSquare", _secondsquare);Debug.locals.put("secondSquare", _secondsquare);
 BA.debugLineNum = 620;BA.debugLine="If secondSquare.IsSideTaken(SPConstants.LEFT_SIDE) = False Then";
Debug.ShouldStop(2048);
if (RemoteObject.solveBoolean("=",_secondsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 621;BA.debugLine="closeSide = SPConstants.LEFT_SIDE";
Debug.ShouldStop(4096);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_left_side");Debug.locals.put("closeSide", _closeside);
 }else 
{ BA.debugLineNum = 622;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.RIGHT_SIDE) = False Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 623;BA.debugLine="closeSide = SPConstants.RIGHT_SIDE";
Debug.ShouldStop(16384);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_right_side");Debug.locals.put("closeSide", _closeside);
 }else 
{ BA.debugLineNum = 624;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.TOP_SIDE) = False Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 625;BA.debugLine="closeSide = SPConstants.TOP_SIDE";
Debug.ShouldStop(65536);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_top_side");Debug.locals.put("closeSide", _closeside);
 }else 
{ BA.debugLineNum = 626;BA.debugLine="Else If currentSquare.IsSideTaken(SPConstants.BOTTOM_SIDE) = False Then";
Debug.ShouldStop(131072);
if (RemoteObject.solveBoolean("=",_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side"))),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 627;BA.debugLine="closeSide = SPConstants.BOTTOM_SIDE";
Debug.ShouldStop(262144);
_closeside = main._spconstants.getFieldClass("pineysoft.squarepaddocks.constants", true,"_bottom_side");Debug.locals.put("closeSide", _closeside);
 }}}};
 BA.debugLineNum = 631;BA.debugLine="UpdateTurn(canv, secondSquare, closeSide)";
Debug.ShouldStop(4194304);
_updateturn(main.mostCurrent._canv,_secondsquare,_closeside);
 BA.debugLineNum = 634;BA.debugLine="currentSquare.TakeSide(canv,closeSide)";
Debug.ShouldStop(33554432);
_currentsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_takeside",(Object)(main.mostCurrent._canv),(Object)(_closeside));
 BA.debugLineNum = 637;BA.debugLine="MarkOtherSide2(secondSquare, closeSide)";
Debug.ShouldStop(268435456);
_markotherside2(_secondsquare,_closeside);
 BA.debugLineNum = 639;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _takesingle(RemoteObject _foundvalids) throws Exception{
try {
		Debug.PushSubsStack("TakeSingle (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("takesingle")) return main.remoteMe.runUserSub(false, "main","takesingle", _foundvalids);
RemoteObject _rndnum = RemoteObject.createImmutable(0);
RemoteObject _sideisavailable = RemoteObject.createImmutable(false);
RemoteObject _foundsquare = RemoteObject.declareNull("pineysoft.squarepaddocks.gamesquare");
RemoteObject _rndside = RemoteObject.createImmutable(0);
Debug.locals.put("foundValids", _foundvalids);
 BA.debugLineNum = 640;BA.debugLine="Sub TakeSingle(foundValids As List)";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 641;BA.debugLine="Dim rndnum As Int";
Debug.ShouldStop(1);
_rndnum = RemoteObject.createImmutable(0);Debug.locals.put("rndnum", _rndnum);
 BA.debugLineNum = 642;BA.debugLine="Dim sideIsAvailable As Boolean = False";
Debug.ShouldStop(2);
_sideisavailable = main.mostCurrent.__c.getField(true,"False");Debug.locals.put("sideIsAvailable", _sideisavailable);Debug.locals.put("sideIsAvailable", _sideisavailable);
 BA.debugLineNum = 644;BA.debugLine="If foundValids.Size > 0 Then";
Debug.ShouldStop(8);
if (RemoteObject.solveBoolean(">",_foundvalids.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 645;BA.debugLine="If foundValids.Size > 1 Then";
Debug.ShouldStop(16);
if (RemoteObject.solveBoolean(">",_foundvalids.runMethod(true,"getSize"),BA.numberCast(double.class, 1))) { 
 BA.debugLineNum = 646;BA.debugLine="rndnum = Rnd(1, foundValids.Size)";
Debug.ShouldStop(32);
_rndnum = main.mostCurrent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 1)),(Object)(_foundvalids.runMethod(true,"getSize")));Debug.locals.put("rndnum", _rndnum);
 }else {
 BA.debugLineNum = 648;BA.debugLine="rndnum = 1";
Debug.ShouldStop(128);
_rndnum = BA.numberCast(int.class, 1);Debug.locals.put("rndnum", _rndnum);
 };
 BA.debugLineNum = 651;BA.debugLine="Dim foundSquare As GameSquare = foundValids.Get(rndnum - 1)";
Debug.ShouldStop(1024);
_foundsquare = (_foundvalids.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_rndnum,RemoteObject.createImmutable(1)}, "-",1, 1))));Debug.locals.put("foundSquare", _foundsquare);Debug.locals.put("foundSquare", _foundsquare);
 BA.debugLineNum = 653;BA.debugLine="Dim rndSide As Int = Rnd(1,4)";
Debug.ShouldStop(4096);
_rndside = main.mostCurrent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 1)),(Object)(BA.numberCast(int.class, 4)));Debug.locals.put("rndSide", _rndside);Debug.locals.put("rndSide", _rndside);
 BA.debugLineNum = 655;BA.debugLine="Do While sideIsAvailable";
Debug.ShouldStop(16384);
while (_sideisavailable.<Boolean>get().booleanValue()) {
 BA.debugLineNum = 656;BA.debugLine="If foundSquare.IsSideTaken(rndSide) = False Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",_foundsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_issidetaken",(Object)(_rndside)),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 657;BA.debugLine="sideIsAvailable = True";
Debug.ShouldStop(65536);
_sideisavailable = main.mostCurrent.__c.getField(true,"True");Debug.locals.put("sideIsAvailable", _sideisavailable);
 };
 }
;
 BA.debugLineNum = 661;BA.debugLine="UpdateTurn(canv, foundSquare, rndSide)";
Debug.ShouldStop(1048576);
_updateturn(main.mostCurrent._canv,_foundsquare,_rndside);
 BA.debugLineNum = 663;BA.debugLine="foundSquare.TakeSide(canv, rndSide)";
Debug.ShouldStop(4194304);
_foundsquare.runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_takeside",(Object)(main.mostCurrent._canv),(Object)(_rndside));
 BA.debugLineNum = 665;BA.debugLine="MarkOtherSide2(foundSquare, rndSide)";
Debug.ShouldStop(16777216);
_markotherside2(_foundsquare,_rndside);
 };
 BA.debugLineNum = 668;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _updatelabels() throws Exception{
try {
		Debug.PushSubsStack("UpdateLabels (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("updatelabels")) return main.remoteMe.runUserSub(false, "main","updatelabels");
 BA.debugLineNum = 237;BA.debugLine="Sub UpdateLabels";
Debug.ShouldStop(4096);
 BA.debugLineNum = 238;BA.debugLine="lblRows.Text = \"Rows : \" & sbRows.Value";
Debug.ShouldStop(8192);
main.mostCurrent._lblrows.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Rows : "),main.mostCurrent._sbrows.runMethod(true,"getValue"))));
 BA.debugLineNum = 239;BA.debugLine="lblColumns.Text = \"Columns : \" & sbColumns.Value";
Debug.ShouldStop(16384);
main.mostCurrent._lblcolumns.runMethod(true,"setText",(RemoteObject.concat(RemoteObject.createImmutable("Columns : "),main.mostCurrent._sbcolumns.runMethod(true,"getValue"))));
 BA.debugLineNum = 240;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _updateplayernumber() throws Exception{
try {
		Debug.PushSubsStack("UpdatePlayerNumber (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("updateplayernumber")) return main.remoteMe.runUserSub(false, "main","updateplayernumber");
 BA.debugLineNum = 424;BA.debugLine="Sub UpdatePlayerNumber";
Debug.ShouldStop(128);
 BA.debugLineNum = 425;BA.debugLine="currentPlayer = currentPlayer + 1";
Debug.ShouldStop(256);
main._currentplayer = BA.numberCast(short.class, RemoteObject.solve(new RemoteObject[] {main._currentplayer,RemoteObject.createImmutable(1)}, "+",1, 1));
 BA.debugLineNum = 426;BA.debugLine="If currentPlayer > numberOfPlayers - 1 Then currentPlayer = 0";
Debug.ShouldStop(512);
if (RemoteObject.solveBoolean(">",main._currentplayer,BA.numberCast(double.class, RemoteObject.solve(new RemoteObject[] {main._numberofplayers,RemoteObject.createImmutable(1)}, "-",1, 1)))) { 
main._currentplayer = BA.numberCast(short.class, 0);};
 BA.debugLineNum = 427;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _updateturn(RemoteObject _cnv,RemoteObject _currentsquare,RemoteObject _chosenside) throws Exception{
try {
		Debug.PushSubsStack("UpdateTurn (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent);
if (RapidSub.canDelegate("updateturn")) return main.remoteMe.runUserSub(false, "main","updateturn", _cnv, _currentsquare, _chosenside);
RemoteObject _lastturn = RemoteObject.declareNull("pineysoft.squarepaddocks.turn");
RemoteObject _newturn = RemoteObject.declareNull("pineysoft.squarepaddocks.turn");
Debug.locals.put("cnv", _cnv);
Debug.locals.put("currentSquare", _currentsquare);
Debug.locals.put("chosenSide", _chosenside);
 BA.debugLineNum = 408;BA.debugLine="Sub UpdateTurn(cnv As Canvas, currentSquare As GameSquare, chosenSide As Int)";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 409;BA.debugLine="Dim lastTurn As Turn";
Debug.ShouldStop(16777216);
_lastturn = RemoteObject.createNew ("pineysoft.squarepaddocks.turn");Debug.locals.put("lastTurn", _lastturn);
 BA.debugLineNum = 410;BA.debugLine="Dim newTurn As Turn";
Debug.ShouldStop(33554432);
_newturn = RemoteObject.createNew ("pineysoft.squarepaddocks.turn");Debug.locals.put("newTurn", _newturn);
 BA.debugLineNum = 413;BA.debugLine="If gameTurns.Size > 0 Then";
Debug.ShouldStop(268435456);
if (RemoteObject.solveBoolean(">",main.mostCurrent._gameturns.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 414;BA.debugLine="lastTurn = gameTurns.Get(gameTurns.Size - 1)";
Debug.ShouldStop(536870912);
_lastturn = (main.mostCurrent._gameturns.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {main.mostCurrent._gameturns.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1))));Debug.locals.put("lastTurn", _lastturn);
 BA.debugLineNum = 415;BA.debugLine="lastTurn.Square.DrawEdge2(canv,lastTurn.Edge,Colors.LightGray)";
Debug.ShouldStop(1073741824);
_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", false,"_square").runClassMethod (pineysoft.squarepaddocks.gamesquare.class, "_drawedge2",(Object)(main.mostCurrent._canv),(Object)(_lastturn.getFieldClass("pineysoft.squarepaddocks.turn", true,"_edge")),(Object)(main.mostCurrent.__c.getField(false,"Colors").getField(true,"LightGray")));
 };
 BA.debugLineNum = 419;BA.debugLine="newTurn.Initialize(currentSquare, chosenSide, currentPlayer)";
Debug.ShouldStop(4);
_newturn.runClassMethod (pineysoft.squarepaddocks.turn.class, "_initialize",main.mostCurrent.activityBA,(Object)(_currentsquare),(Object)(_chosenside),(Object)(BA.numberCast(int.class, main._currentplayer)));
 BA.debugLineNum = 422;BA.debugLine="gameTurns.Add(newTurn)";
Debug.ShouldStop(32);
main.mostCurrent._gameturns.runVoidMethod ("Add",(Object)((_newturn)));
 BA.debugLineNum = 423;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
}