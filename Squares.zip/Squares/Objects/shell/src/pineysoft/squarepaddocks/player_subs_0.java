package pineysoft.squarepaddocks;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class player_subs_0 {


public static RemoteObject  _class_globals(RemoteObject __ref) throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Dim Name As String";
player._name = RemoteObject.createImmutable("");__ref.setFieldClass("pineysoft.squarepaddocks.player","_name",player._name);
 //BA.debugLineNum = 4;BA.debugLine="Dim Score As Int";
player._score = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.player","_score",player._score);
 //BA.debugLineNum = 5;BA.debugLine="Dim Colour As Int";
player._colour = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.player","_colour",player._colour);
 //BA.debugLineNum = 6;BA.debugLine="Dim PlayerImage As Bitmap";
player._playerimage = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");__ref.setFieldClass("pineysoft.squarepaddocks.player","_playerimage",player._playerimage);
 //BA.debugLineNum = 7;BA.debugLine="Dim PlayerType As Int ' 0 for human - 1 for droid";
player._playertype = RemoteObject.createImmutable(0);__ref.setFieldClass("pineysoft.squarepaddocks.player","_playertype",player._playertype);
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _initialize(RemoteObject __ref,RemoteObject _ba,RemoteObject _namein,RemoteObject _colourin) throws Exception{
try {
		Debug.PushSubsStack("Initialize (player) ","player",2,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("initialize")) return __ref.runUserSub(false, "player","initialize", __ref, _ba, _namein, _colourin);
__ref.runVoidMethodAndSync("innerInitializeHelper", _ba);
Debug.locals.put("ba", _ba);
Debug.locals.put("NameIn", _namein);
Debug.locals.put("ColourIn", _colourin);
 BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize(NameIn As String, ColourIn As Int)";
Debug.ShouldStop(1024);
 BA.debugLineNum = 12;BA.debugLine="Name = NameIn";
Debug.ShouldStop(2048);
__ref.setFieldClass("pineysoft.squarepaddocks.player", "_name",_namein);
 BA.debugLineNum = 13;BA.debugLine="Colour = ColourIn";
Debug.ShouldStop(4096);
__ref.setFieldClass("pineysoft.squarepaddocks.player", "_colour",_colourin);
 BA.debugLineNum = 14;BA.debugLine="End Sub";
Debug.ShouldStop(8192);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _initialize2(RemoteObject __ref,RemoteObject _namein,RemoteObject _colourin,RemoteObject _ptype) throws Exception{
try {
		Debug.PushSubsStack("Initialize2 (player) ","player",2,__ref.getField(false, "ba"),__ref);
if (RapidSub.canDelegate("initialize2")) return __ref.runUserSub(false, "player","initialize2", __ref, _namein, _colourin, _ptype);
Debug.locals.put("NameIn", _namein);
Debug.locals.put("ColourIn", _colourin);
Debug.locals.put("PType", _ptype);
 BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize2(NameIn As String, ColourIn As Int, PType As Int)";
Debug.ShouldStop(32768);
 BA.debugLineNum = 17;BA.debugLine="Name = NameIn";
Debug.ShouldStop(65536);
__ref.setFieldClass("pineysoft.squarepaddocks.player", "_name",_namein);
 BA.debugLineNum = 18;BA.debugLine="Colour = ColourIn";
Debug.ShouldStop(131072);
__ref.setFieldClass("pineysoft.squarepaddocks.player", "_colour",_colourin);
 BA.debugLineNum = 19;BA.debugLine="PlayerType = PType";
Debug.ShouldStop(262144);
__ref.setFieldClass("pineysoft.squarepaddocks.player", "_playertype",_ptype);
 BA.debugLineNum = 20;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			Debug.ErrorCaught(e);
			throw e;
		} 
finally {
			Debug.PopSubsStack();
		}}
}